# PETA PROFESI → ALAT KERJA → EFEK VISUAL (38 IDE KONTEN DEEPWATCH)

Format: profesi | alat kerja | efek/animasi per alat

## LUAR ANGKASA 11-25
11 Supervisor pipa metana Jupiter | gauge genggam + radio + tablet telemetri | jarum gauge bergetar halus, lampu radio kedip statis, grafik tablet merayap, kilat badai menyambar pelan di bawah dek, semburan uap metana dari flange
12 Teknisi antena (EVA) | kunci sok + spool kabel + torque gun | baut berputar pelan saat dikunci, kabel terulur dari spool, torque gun getar mikro, beacon kedip, bar O2 HUD menurun, kapal induk mengecil
13 Operator drone bor tambang | joystick ganda + konsol + mug kopi | joystick bergerak mikro, lampu konsol kedip tak beraturan, uap kopi naik, waveform telemetri bor, siluet di feed rongga
14 Teknisi kamar mayat krio | scanner krio + tablet + sarung termal | cahaya scanner menyapu pod kiri-kanan, layar EKG garis datar lalu melonjak, kabut pod meluber saat palka terbuka
15 Petugas pengisian bahan bakar | nozzle selang + meter aliran + klem grounding | selang bergoyang mengikuti arus, dial meter naik, kabut uap bahan bakar di lantai, siluet kru tampak ganda
16 Penyelam pipa pendingin fusi | obor kecil + kunci + lampu selam | arc lembut di ujung obor, gelembung uap naik, gauge masuk zona merah, cone lampu di pipa sempit
17 Teknisi evakuasi stasiun bio | senter + pemotong spesimen + radio | cone senter berayun, bayangan sulur bergeser di dinding, pod pecah menetes, statis radio
18 Awak pengumpul debu komet | selang vakum + nampan filter + swab kit | selang bergetar menyedot, partikel organik melayang masuk vent, lampu nampan kedip merah
19 Mekanik roda pendarat | kunci torsi + tensioner strap + grease gun | ratchet berputar klik-klik, strap menegang bergetar, glow panas reentry merambat naik, siluet di luar strut
20 Teknisi sensor gravitasi | dial kalibrasi + stylus scope + perekam | dial berputar pelan, garis scope menulis, grafik massa melonjak, bintang di viewport melengkung (lensing)
21 Petugas dek dekontaminasi | wand scanner + arch semprot + clipboard | cahaya wand menyapu badan, kabut semprot, lampu peringatan berputar pelan, bayangan "kembar" telat bergerak
22 Operator derek magnetik | tuas derek + indikator magnet + radio | tuas tertarik bergetar, beban puing berayun, lampu merah berputar, puing menempel-terlepas
23 Awak kabel antarbintang | splicer + spool kabel + lampu kerja | klik splicer, spool berputar mengulur, kabut melintas, siluet kru memudar satu-satu
24 Peneliti penggalian bulan asing | beliung + core sampler + floodlight | siklus angkat-ayun-hantam + serpihan + recoil, bor inti berputar pelan, gelombang suara dari lubang, kabut napas
25 Petugas pemeliharaan oksigen | kunci filter + gauge O2 + borescope duct | kunci memutar filter, jarum O2 berosilasi, debu berdenyut seperti napas, kipas duct berputar pelan

## LAUT 8-30
8 Penyelam gua blue hole | reel+line + torch selam + pisau | line terulur ke gelap, cone torch + backscatter, partikel arus tersedot ke dalam gua, ukiran berpendar samar
9 Penjaga mercusuar | radio + buku log + alat sumbu lampu | dial radio menyala sendiri, pena menulis di log, beam Fresnel menyapu dinding berputar
10 Teknisi pelampung sonar | reel hidrofon + headset + layar spektro | reel berputar pelan, ping biner berirama di spektro, pelampung mengangguk di ombak
11 Operator radar atol | dial radar + panel sakelar + kopi | sapuan radar berputar, lampu panel mati total (lights-out), pendar bioluminesensi naik dari laut
12 Teknisi stasiun seismik | pena log + drum seismograf + mug | kertas drum berputar, jarum stylus menulis garis yang SAMA berulang, uap kopi
13 Inspektur anjungan tua | senter + clipboard + kunci pipa | cone senter patroli, jejak kaki basah muncul bertahap, derek berderit berayun
14 Petugas pos tsunami | graf pasang + layar sensor + teropong | garis air laut MUNDUR perlahan di kejauhan, angka sensor turun, burung laut melintas menjauh
15 Teknisi otomasi mercusuar | keypad kode + engkol lensa | tombol menyala saat ditekan, lampu error kedip, beam berayun mengarah ke tebing
16 Analis hidrofon laut dalam | headset + reel pita + spektrogram | reel berputar pelan, waveform "baling-baling kayu" muncul, siluet kapal kayu di kedalaman
17 Ahli bioakustik paus | boom hidrofon + laptop waveform | klik paus di waveform membentuk pola mirip kata, gelembung naik jauh
18 Pilot selam pemulihan kotak hitam | joystick + reel CVR + lampu | reel menggulung, static 72 jam di layar, gauge kedalaman turun
19 Penjaga radio pantai | dial radio + pena peta koordinat | dial tuning bergerak, kedip morse SOS, tanda silang muncul di peta daratan tenggelam
20 Peneliti infrasonik | probe osiloskop + penyumbat telinga + perekam | riak frekuensi rendah bergetar di seluruh frame, ranjang kapal berayun, lampu berkedip pelan
21 Teknisi kamp es Antartika | bor es + geophone + lampu morse | bor berputar pelan menembus es, serpihan es, lampu morse balas mengetuk, salju melayang, riak dari bawah gletser
22 Penjaga radio suar | dial radio + speaker | waveform suara sintetik di layar kecil, display menyalakan nama, lampu dial berdenyut
23 Arkeolog bawah air bangkai kapal | lift bag + slate + torch | lift bag mengembang pelan, sedimen mengepul saat tersentuh, air hitam palka MENOLAK cahaya torch
24 Pilot ROV pemulihan satelit | joystick + lengan manipulator ROV + winch | lengan ROV memanjang menjepit, thruster bubble, biomassa mengembang membungkus kapsul
25 Ahli biologi autopsi cumi | pisau bedah + forceps + toples spesimen | irisan pelan, cairan menetes, kilau LOGAM di dalam daging, lampu meja berdengung
26 Penyelam kabel dasar laut | kunci cable plow + torch | rantai jangkar raksasa menjulang lalu turun ke palung, paralaks skala, backscatter torch
27 Awak kapal survei geomagnetik | kompas + peta bintang + kemudi | jarum kompas berputar liar, lampu tiang kedip, permukaan air hitam menyerap cahaya
28 Pilot ROV gerbang palung | lengan ROV + sonar | sapuan sonar melingkar, lampu DI DALAM gerbang berdenyut lembut, sedimen melayang
29 Awak kapal keruk | engkol winch + hook rantai + linggis | winch berputar mengangkat, peti baja berlumut menetes naik, tag peringatan bergoyang
30 Teknisi habitat | monitor umbilical + tas duffel + handset | grafik umbilical normal lalu TERPUTUS (layar glitch gelap), uap kopi, monolog host bubble
