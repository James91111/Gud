# RENCANA UPGRADE DEEPWATCH v2 — "LATAR MENGIKUTI CERITA + NARATOR HIDUP"

## I. DIAGNOSIS (kenapa latar terasa sama)
- Template episode (`hdeck`) mengunci **worksite + layout + palet** per episode;
  `plan_scene` di `hstage` hanya mengganti prop/pose/FX per kalimat — lingkungan
  (interior/eksterior) tidak pernah pindah. Maka dua video terasa "latar itu-itu saja".
- Sudah ada modal bagus: `draw_worker` (10 pose kerja + blend), `_narr_props`
  (20 pemicu objek dari narasi), `draw_ext_*` (eksterior kapal), `cam_crop` kalem,
  siluet makhluk, FX per domain. Upgrade = menambahkan **lapisan lokasi & narator**,
  bukan menulis ulang.

## II. DESAIN UPGRADE (ide Abang + saya)

### 1. LOCATION GRAMMAR (latar mengikuti narasi, per kalimat)
Kamus kata-kunci → LOKASI, tiap lokasi = palet + lapisan env + set furnitur + partikel:
- `seabed/trench`: pipa flange, katup, rantai jangkar, marine-snow, cahaya kolom air.
- `cave/bluehole`: dinding karang ukir, reel+line penyelam, gelap + cone senter.
- `deck/rig`: derek, kontainer, selang bakar, hujan/badai, karat.
- `control/sonar room`: konsol, spektrogram, logbook, kopi, lampu redup.
- `lab`: toples spesimen, mikroskop, meja baja.
- `cryo/medbay`: pod berkabut, monitor EKG.
- `airlock/decon`: gerbang semprot, hatch.
- `surface/alien moon`: dataran beku, lubang galian, floodlight, kabut napas.
- `EVA/vacuum`: bintang, tether, HUD O2, induk menjauh.
- `rov cockpit`: bingkai viewport + layar sonar + tuas (kendarai ROV).
Perpindahan lokasi = crossfade 0.4 dtk + **walk-in** (kalem, tanpa strobo).

### 2. HOST MODE (narator bicara ke penonton saat tak ada aksi)
Deteksi kalimat "tanpa aksi" (tiada kata kerja aksi & tiada ganti lokasi):
- Narator menghadap kamera: mulut sinkron TTS (sudah ada), kedip, siklus gestur
  tangan bercerita (3 gestur halus bergantian).
- Subtitle pindah ke **BUBBLE** di atas kepala (gelap semi-transparan, ekor ke mulut,
  ukuran baca nyaman); band bawah dipakai lagi saat mode aksi.

### 3. WALK-IN & LOCOMOTION (kaki benar-benar berjalan)
Saat lokasi berganti, narator masuk dari tepi frame dengan siklus jalan (pose jalan
sudah ada di draw_worker) menuju mark; varian gerak per lingkungan:
`walk` (koridor/dek), `swim` (bawah air: horizontal + gelembung), `rov` (mengendarai
ROV: badan kendaraan + cone lampu + thruster bubble; viewport menunjukkan turunnya
kedalaman), `eva` (drift jetpack + tether), `climb` (tangga vertikal).
Latar paralaks 2-3 lapis ikut bergeser (bukan diseret datar).

### 4. CAST & CONVERSATION GRAMMAR (tambahan Abang — bagian tersulit)
Deteksi "ada karakter lain" di lokasi tujuan:
- KATA BENDA ORANG: rekan, coworker, foreman, kapten, navigator, tim, kru, nama
  orang, "operator lain", "dua dari kami" → spawn 1-2 NPC.
- NPC idle sesuai profesi memakai pose kerja (welding, cranking, staring gauge,
  keying radio, menulis log, membawa alat) + pose baru: `carrying`, `writing`,
  `pointing`, `waving`.
- DETEKSI PERCAKAPAN (heuristik): dua kalimat berurutan memuat verba ucap
  (said/asked/shouted/replied/balas/tanya/seru/peringat) ATAU kata ganti orang kedua
  ("you", "kamu", "kataku padanya") ATAU tanda kutip → CONVO MODE: narator & NPC
  berhadapan, bubble bergantian kiri-kanan, anggukan kecil; mulut bergerak bergantian.
- Bila ragu, fallback: NPC bekerja diam (tanpa convo) — aman secara cerita.

### 4b. GRAMMAR "SIAPA" (level pembicara — wajib, bukan sekadar verba ucap)
Verba ucap saja TIDAK cukup membuktikan adegan percakapan. Deteksi dua lapis:
- L1 SPEAKER-ID: subjek di kalimat = nama orang / kata ganti (I, he, she, they,
  "dia", "saya", "kami") / peran ("kapten", "rekan saya", "operator kedua") →
  tiap verba ucap terikat ke SATU id pembicara (SPK_A = narator bila "saya/I",
  SPK_B/C = NPC yang sudah di-spawn atau "karakter tak dikenal" bila belum ada).
- L2 ARUS: kalimat ucap berurutan dengan subjek BERGANTIAN (A lalu B, atau B lalu A)
  = CONVO MODE (bubble kiri-kanan bergantian + label kecil per karakter, sesuai
  riset speaker-labeled captions). Subjek SAMA terus = MONOLOG (tetap host bubble).
- Arah ucapan: "to me / kepadaku / ke dia / berkata pada..." menentukan siapa lawan
  bicara → bubble muncul dari pembicara ke arah lawan bicara.
- Kutipan langsung ("...") = bukti terkuat convo; narasi tak langsung
  ("dia bilang bahwa...") = tetap satu bubble saja, tanpa mode dialog.

### 5. FURNITUR PROFESI per lokasi (contoh set)
- Pipa gas/metana: flange, roda katup, gauge getar, drone pengawas.
- Antena deep-space: dish, tangga gantry, kotak tool, beacon.
- Bor tambang: rig bor, layar telemetri, konveyor debu.
- Krio: barisan pod, panel suhu, troli medis.
- Bahan bakar: selang nozzle, tangki, meter aliran.
- Pipa pendingin fusi: pipa sempit, katup uap, termometer merah.
- dst. mengikuti tabel prediksi di bawah.

### 6. IDE TAMBAHAN SAYA (pelengkap horor-profesi)
- HUD diegetik mini saat EVA/dive/ROV (O2 / depth / battery) — tensi + autentik.
- FX tanda tangan per kluster: waveform hidrofon (kluster 3), kartu daftar aturan
  (rules-based), bioluminesensi (mode glow), morse dari bawah es, air "menolak cahaya".
- Slate "LOG ## — timestamp" diegetik pembuka per episode (format audio-log).
- Semua tetap KALEM: tanpa zoom pump, crossfade lembut, siluet makhluk parsial.

## III. PREDIKSI PER IDE (lokasi → furnitur/objek → gerak → NPC/percakapan → FX)

### LUAR ANGKASA 11-25
11 Pipa metana Jupiter — ROV cockpit → gantry luar badai; flange+gauge+radar badai;
   locomotion rov→walk magboot; host log; petir badai di bawah.
12 Antena ditinggal induk — EVA tether; dish+toolbag; drift jetpack; HUD O2 menipis;
   induk mengecil + beacon kedip.
13 Drone bor rongga — control room; konsol+telemetri; host di kursi; siluet di FEED
   (layar-dalam-layar).
14 Kamar mayat krio — aula pod; pod+kabut+EKG; walk lambat; pod terbuka sendiri.
15 Isi bahan bakar — dock+selang; tangki+nozzle+meter; walk; halusinasi = siluet ganda.
16 Penyelam pipa fusi — pipa sempit; swim coolant+gelembung uap; katup+termometer;
   framing klaustro.
17 Evakuasi bangkai bio — boarding EVA + lab rusak; pod pecah+sulur; senter; bayangan
   bergeser.
18 Debu komet ventilasi — kabin; filter+kolektor+vent; walk; partikel organik menyebar.
19 Roda pendarat — wheel bay luar saat reentry; roda+hidrolik; EVA pegangan; glow panas
   + entitas di luar.
20 Sensor gravitasi — pos sensor; antena+graf massa; stare; lensing bintang (massa
   tak terlihat).
21 Dek dekontaminasi — decon shower; gerbang semprot+scanner; NPC awak pulang →
   CONVO uncanny (suara/wajah beda).
22 Derek magnetik — cab derek; lengan+magnet+puing; tuas; pesan berdarah terbaca tahap.
23 Kabel antarbintang kabut — spool kabel luar; kabut; NPC kru hilang satu-satu
   (convo → kosong).
24 Bulan asing lubang galian — dataran beku; bor+core+floodlight; walk; suara manusia
   dari lubang (waveform) + kabut napas.
25 Saluran oksigen — duct crawl; kipas+filter+gauge O2; crawling; debu berdenyut
   "bernapas".

### LAUT 8-30
8 Gua blue hole — swim terowongan; reel+line+senter+ukiran karang; arus hisap partikel.
9 Suar lepas pantai — ruang lampu+radio; lensa Fresnel+radio; host membacakan KARTU
   6 ATURAN; radio hidup sendiri.
10 Pelampung sonar Point Nemo — platform+sonar room; array hidrofon+spektrogram;
   ping biner berirama.
11 Atol bioluminesensi — dek radar malam; radar+sakelar; protokol lampu mati; laut
   berpendar naik.
12 Stasiun seismik dasar laut — habitat; seismograf+logbook; read log; kalimat terakhir
   sama.
13 Anjungan tua — dek berkarat+control; derek+pipa; walk patroli; jejak air asin ke
   ruang kontrol.
14 Pos tsunami — deck observasi; tide gauge+graf; stare; garis air MUNDUR perlahan.
15 Mercusuar otomatis — ruang lampu+panel kode; lensa+keyboard; beam diarahkan ke tebing.
16 Hidrofon kapal abad 18 — ruang akustik+headset; reel+waveform; siluet kapal kayu
   di kedalaman.
17 Bioakustik paus — lab+layar sonar; spektrogram; klik membentuk kata manusia.
18 Kotak hitam Mariana — cabin selam+CVR; reel+depth gauge; static 72 jam.
19 Radio Alaska SOS — shack radio+peta; radio+chart koordinat; SOS dari daratan tenggelam.
20 Infrasonik halusinasi — mess/dokter kapal; osiloskop+ranjang; ri dengung rendah
   tengah malam.
21 Es Antartika morse — kamp es+geophone; core bor+lampu; ketukan morse bawah gletser.
22 Radio menyebut nama — radio mercusuar; dial+speaker; waveform sintetik + nama di
   display.
23 Palka kapal abad 16 — dive + wreck; lift bag+slate; kompartemen air menolak cahaya.
24 Satelit palung — ROV + kapsul; lengan ROV; zat biologis mengembang membungkus.
25 Autopsi cumi raksasa — lab pantai; meja baja+toples; bagian logam dalam daging.
26 Rantai jangkar raksasa — dive + cable; rantai menjulang ke palung; skala megalo.
27 Zona air tenang — dek kapal malam; kompas berputar+peta bintang; air hitam pekat.
28 Gerbang kedap palung — ROV cockpit; dinding palung + gerbang beton modern; lampu
   dalam gerbang.
29 Kapal keruk peti baja — dek keruk malam; derek+peti lumut+segel timah; tag larangan.
30 Habitat sebelum evakuasi — habitat+comms; monitor umbilical; HOST MONOLOG bubble;
   kabel terputus.

## IV. URUTAN EKSEKUSI BILA DISETUJUI
1) Location grammar + crossfade + paralaks (inti keluhan latar sama).
2) Host mode + bubble subtitle.
3) Walk-in + locomotion (walk/swim/rov/eva).
4) Cast & convo grammar + pose NPC baru.
5) Furnitur/objek per profesi (batch sesuai tabel).
6) QC trial-error per fitur + audit_dw diperluas + zip DeepWatch baru.

## V. LIVING PROPS — objek pendukung yang GERAK/BEREFEK (permintaan tambahan)
Modal yang sudah hidup: lampu koridor berdenyut, berkas cahaya laut berayun,
bintang viewport, siluet makhluk. Ditambahkan REGISTRY prop animasi per lokasi
(tiap adegan ambil 2-3 acak, gerak PELAN & kalem, tanpa strobo):
- Umum: kipas/vent berputar, kabel gantung berayun, gauge bergetar, neon flicker
  halus, uap/steam melintas, percikan las, tetesan kondensasi.
- Space: radar dish memutar pelan, beacon kedip, thruster ROV (bubble + propeler
  putar), roda kincir stasiun, tether berayun, HUD O2 berdetak, debu dalam sorot lampu.
- Sea: marine snow turun, gelembung naik, sirip ikan jauh, kelp/rumput laut berayun,
  lampu suar berputar (Fresnel beam sweep), sonar ping melingkar, hidrofon waveform
  berosilasi, rantai jangkar berderit bergeser, bioluminesensi berkedip pelan.
- Abu/salju/embun: partikel drift sesuai lokasi (abu vulkanik bulan, salju es,
  kabut dingin krio).
- Mesin: derek magnet berayun, konveyor bergetar, pompa naik-turun, seismograf
  drum berputar + jarum menulis, kopi mengepul (beat tenang host).
Aturan: semua animasi sekunder amplitude kecil (mata tetap ke narator/aksi),
kecepatan <= 1 Hz, dan konsisten antar-frame (seed per adegan).

## VI. RISET GAYA SUBTITLE NICHE HORROR-STORYTELLING (pola yang disukai penonton)

### A. Pola channel pembanding di niche ini
- MrBallen (raja niche): nyaris TANPA subtitle bakar; teks hanya sebagai label/konteks
  pada gambar; cerita disampaikan suara + gestur. Penontonnya menikmati "mendengar"
  dengan visual pendukung — subtitle ramai dianggap merusak atmosfer.
- Mr. Nightmare / Whispered Diaries / Chills: delivery kalem, tanpa sensasi, tanpa
  teks ramai — understated = autentik dan lebih seram. Subtitle berlebihan =
  terasa murahan dan keluar dari mood malam/horor.
- Dark5: dokumenter narrator-only, slow-burn, tanpa host on-screen — bukti penonton
  niche ini menerima narator "suara" penuh tanpa wajah, asalkan visualnya sinematik.
- Channel animasi horor (Wansee, 3AM): justru pakai SPEECH BUBBLE untuk dialog —
  bubble adalah format NATIF animasi, tapi hanya saat dialog, bukan narasi.
- Blueprint channel horor: audiens dewasa → tone dokumenter kalem; hard-coded
  caption direkomendasikan; horor ditonton malam/layar redup → subtitle band gelap
  menyatu dengan suasana.

### B. Standar teknis (riset 2025-2026, long-form 1080p)
- Gaya: FULL-LINE SUBTITLE BLOCKS = default long-form (word-by-word kinetic justru
  menghambat pemahaman kalimat panjang); satu gaya konsisten sepanjang video.
- Panjang: ≤40-42 karakter/baris, maks 2 baris; tampil 1-6 dtk; kecepatan baca
  15-20 CPS; sync ±0.5 dtk (drift ≤0.2 dtk); appear transition 0.1-0.15 dtk.
- Tipografi: sans-serif bold/semibold, putih di band gelap semi-transparan,
  kontras ≥4.5:1; posisi lower-center, safe zone ≥80px dari tepi; hindari dekoratif.
- Multi-speaker: WAJIB speaker label (nama/posisi/warna) agar penonton tidak
  kehilangan siapa yang bicara.
- Emphasis: highlight kata kunci (warna/blok) terbukti mengunci perhatian — tapi
  di niche horor dipakai jarang & kalem (bukan gaya MrBeast penuh layar).

### C. Keputusan desain subtitle DeepWatch v2 (hasil riset + kondisi kita 960×540)
1. STYLE NARRATION (default, gaya 0 sekarang): pertahankan band bawah-tengah
   putih-di-gelap — SUDAH sesuai riset. Perbaikan: wrap maks 42 karakter
   (kini bisa ±60) & font 26px dipertahankan (≈52px-equivalent di 1080p — sangat
   nyaman, jangan dikecilkan).
2. STYLE HOST BUBBLE (mode tanpa aksi): bubble rounded di atas kepala narator,
   ekor menunjuk ke mulut, teks tebal ≥26px, band gelap semi-transparan, muncul
   0.1 dtk sebelum audio; mulut+kedip+gestur jadi fokus, teks jadi pendukung.
3. STYLE CONVO BUBBLE (percakapan): bubble kiri untuk narator / kanan untuk NPC,
   + TAG NAMA kecil berwarna per karakter (speaker-label sesuai riset), maks 2 baris
   ≤42 karakter, bergantian mengikuti arus bicara; hanya aktif saat grammar 4b
   menyatakan CONVO.
4. EMPHASIS: blok berwarna di belakang kata penting (aturan lama) dipertahankan —
   gunakan maksimal 1 kata per kalimat, warna aksen palet episode, tanpa animasi
   memantul (kalem).
5. JANGAN: word-by-word kinetic (menghambat pemahaman long-form), emoji, font
   dekoratif, perpindahan gaya mendadak, teks menutupi objek utama.
6. Sync: timestamp dari SRT TTS sudah ±0.2 dtk; bubble memakai timestamp yang sama
   agar mulut & teks tetap terkunci.

## VII. URUTAN EKSEKUSI (diperbarui)
1) Location grammar + crossfade + paralaks.
2) Sistem subtitle 3-style (narration/host bubble/convo bubble) + wrap ≤42 char.
3) Host mode (mulut/kedip/gestur + bubble).
4) Walk-in + locomotion (walk/swim/rov/eva/climb).
5) Cast grammar "siapa" (4a+4b) + pose NPC baru.
6) Tool library (alat di tangan + animasi + cahaya) — bagian VIII.
7) Furnitur profesi + LIVING PROPS registry.
8) QC trial-error per fitur, audit_dw diperluas, zip DeepWatch baru.

## VIII. PERALATAN DI TANGAN + AKSI PROFESI (hand-held tools)
Status: weld/cut/drill sekarang hanya batang abu-abu bergetar; palu tambang &
kamera TIDAK ADA; spark FX terpisah dari ujung alat. Solusi:
- HAND ANCHOR: draw_worker sudah menghitung koordinat tangan (hx,hy) per pose —
  semua alat digambar menempel di anchor ini, otomatis ikut jitter/gestur tangan.
- TOOL LIBRARY (gambar + loop animasi + reaksi cahaya), dipicu kata kunci narasi:
  1. TORCH LAS — batang + nozzle; arc menyala-berkedip acak 0.5-1 Hz dari ujung
     nozzle (BUKAN strobo), percikan jatuh dari titik kontak, cahaya arc memantul
     lembut ke visor & permukaan sekitar; visor turun.
  2. PALU TAMBANG/ASTERIOD — pegangan dua tangan; siklus angkat → ayun → HANTAM:
     serpihan batu terbang + debu kecil + recoil badan halus saat benturan.
  3. KAMERA BAWAH AIR — bodi kotak + lensa + grip dua tangan; pan pelan mengikuti
     subjek; strobe flash tiap 3-4 dtk menerangi frame sekejap + backscatter
     partikel dalam sorot; gelembung halus dari regulator.
  4. BOR/INTI — mata bor garis berputar + debu/es halus + getaran mikro; untuk
     bor tambang & bor es (core).
  5. LAINNYA: kunci inggris, plasma cutter (semburat biru), boom hidrofon,
     clipboard log, gulungan kabel, jaring, alat biopsi, gunting kabel.
- Grammar: kata kunci narasi → alat + pose: "memotret/foto/footage" = kamera,
  "menambang/asteroid/bijih" = palu tambang, "mengelas/las/seam" = torch,
  "membor/core/ice drill" = bor, dst. Berlaku untuk narator DAN NPC pekerja.
- Aturan: alat tidak menutupi wajah narator (aturan depth lama); flicker ≤1 Hz
  dan amplitude kecil (tetap kalem); cahaya alat ikut mewarnai sekitar (cheap
  radial glow) supaya adegan terasa nyata.
