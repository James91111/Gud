# IDE NASKAH 38 EPISODE — SUSUNAN ADEGAN (LOKASI → ALAT → BEAT)
Pola baku tiap episode: HOOK host-bubble → KERJA (narator masuk + alat + fx) →
GANJIL (NPC/percakapan atau anomali pertama) → PAYOFF horor → CLOSING host-bubble.

## LUAR ANGKASA
11 Metana Jupiter: hook "audio log terakhir" → walk-in gantry, scanner gauge bergetar, kilat badai → NPC partner di radio jawabannya telat 2 detik → flange terbuka sendiri, uap menyembur → closing "jangan kirim tim kedua".
12 Antena ditinggal: hook angka "induk pergi 6 jam lalu" → EVA float, kunci sok putar baut, O2 turun → convo "Tunggu aku di airlock" - "Airlock yang mana?" → beacon induk kedip tapi makin kecil → closing "tetherku bergerak sendiri".
13 Drone bor: hook "rongga tak ada di peta" → control room, joystick + waveform → layar feed: bor berhenti sendiri, siluet berdiri di rongga → drill camera mati → closing "kamera terakhir merekam 4 jam setelah kami cabut".
14 Kamar mayat krio: hook "morgue dek 9" → walk-in aula pod, scanner menyapu → EKG datar melonjak serentak → pod 12 terbuka sendiri, kabut → closing "tidak ada yang terdaftar di pod 12".
15 Isi bahan bakar: hook "shift malam dermaga 4" → nozzle + meter naik → NPC rekan "kamu lihat aku dua kali?" → semua kru tampak ganda → closing "meter penuh, tapi tak ada yang memompa".
16 Pipa fusi: hook "aku benci pipa ini" → swim masuk pipa sempit, obor arc lembut → gauge merah, uap → suara ketukan dari arah katup yang sudah kulalui → closing "pipa ini tidak punya cabang".
17 Evakuasi bio: hook "alarm bukan untuk kebakaran" → boarding, senter berayun → sulur tumbuh menutup jalan, bayangan bergeser → NPC tim "jangan bawa sampelnya" → closing "sampelnya tidak ada di tas siapa pun".
18 Debu komet: hook "ventilasi tidak pernah kotor" → kabin, vakum menyedot → partikel organik melawan arah sedotan → pola di filter membentuk jari → closing "filternya penuh dari dalam".
19 Roda pendarat: hook "11 menit sampai atmosfer" → wheel bay, ratchet klik → glow panas merambat → tangan di luar strut, mengikuti gerakkanku → closing "tidak ada sarung tangan di luar sana".
20 Sensor gravitasi: hook "massa itu tak terlihat" → pos sensor, dial + scope → bintang melengkung → grafik menulis "ORBIT" berulang → closing "ia tidak mengorbit planet. ia mengorbit kami".
21 Dek dekon: hook "awak pulang lengkap, katanya" → arch semprot, wand menyapu → convo dekon "sebutkan namamu" - jawaban benar, suaranya salah → bayangan di cermin telat → closing "dekon meluluskan semua. termasuk yang bukan".
22 Derek magnet: hook "muatan hari ini: puing stasiun lama" → cab, tuas → puing berayun, pesan berdarah terbaca sepotong → magnet menolak melepas → closing "pesan itu menyebut namaku".
23 Kabel kabut: hook "kabut tak ada di ruang hampa" → spool kabel → convo "pegang ujungnya" → kabut lewat, ujung kabel di tangan kosong → closing "spool masih berputar, tak ada yang menarik".
24 Lubang galian bulan: hook "galiannya berbisik" → floodlight, beliung hantam → suara manusia dari lubang, waveform → core sampler menolak turun → closing "bisikannya menyebut shift berikutnya".
25 Saluran O2: hook "sistem napas tidak berisik" → crawl duct, kunci filter → debu berdenyut seirama → napas terdengar saat aku berhenti → closing "filter terakhir menghadap ke arahku".

## LAUT
8 Blue hole: hook "mulut gua itu menelan cahaya" → swim, reel line terulur → arus hisap menarik partikel ke dalam → ukiran berpendar saat torch lewat → closing "line-ku ditarik balik dari dalam".
9 Aturan penjaga: hook "enam aturan di kartu" → ruang lampu, beam menyapu, log → radio hidup sendiri menyebut shift-ku → aturan keenam tak pernah kutulis → closing "aturan keenam: jangan jawab radio".
10 Point Nemo: hook "titik paling sunyi" → platform, reel hidrofon → ping BINER berirama → spektrum membentuk pola berulang yang sama → closing "polanya menunggu jawaban".
11 Atol gelap: hook "lautnya menyala" → radar sweep → perintah lights-out, panel mati → pendar naik sampai sebatas dek → closing "lampu-lampu itu membalas kedipan kami".
12 Stasiun seismik: hook "pendahuluku hilang, lognya tidak" → habitat, stylus drum → kubaca: kalimat terakhirnya sama dengan yang kutulis tadi → drum terus menulis → closing "jarumnya menulis tanpa listrik".
13 Anjungan tua: hook "rig ini kosong sejak 1998" → dek, senter patroli → jejak basah baru, menuju ruang kontrol → radio ruang kontrol hangat → closing "jejaknya berhenti di depan pintuku".
14 Pos tsunami: hook "ombak mundur tanpa gempa" → graf pasang, teropong → garis air surut tak wajar → sensor diam semua → closing "laut sedang menarik napas".
15 Mercusuar pengkhianat: hook "lampu itu menuntun kapal ke tebing" → keypad, engkol lensa → beam melawan perintahku → log otomasi: perintah terakhir dari tangan manusia, 40 tahun lalu → closing "lensa itu berputar ke arahku".
16 Hidrofon abad 18: hook "baling-baling kayu di 4.000 meter" → headset, reel → waveform ketukan kayu teratur → siluet kapal layar di kedalaman → closing "irama itu mendekat".
17 Paus meniru: hook "klik paus itu bukan bahasa paus" → boom hidrofon → klik membentuk pola kata: nama-nama kapal → jeda panjang, lalu satu klik baru: namaku → closing "ia masih mendengarkan".
18 Kotak hitam Mariana: hook "rekaman itu kembali sendiri" → cabin, reel CVR → 72 jam kosong lalu suara kru lengkap → kapal kami tak pernah punya kru sebanyak itu → closing "rekamannya bertambah tiap diputar".
19 SOS daratan tenggelam: hook "koordinat itu tak ada di peta sejak 1958" → dial radio → morse SOS dari daratan yang tenggelam → peta: sinyalnya dari bawah laut → closing "sinyalnya menjawab saat kusebut tahunnya".
20 Infrasonik: hook "kami semua mendengar dengung yang sama" → osiloskop → riak rendah, semua berhalusinasi hal yang sama → frekuensi berhenti tepat tengah malam → closing "dengungnya pindah ke rekaman kami".
21 Morse bawah es: hook "es setebal dua kilometer mengetuk" → bor es pelan → geophone: morse rapi → kubalas, ia berhenti... lalu mengulang pesanku → closing "ia belajar alfabetnya dalam satu malam".
22 Radio tahu namaku: hook "radio itu menyebut jadwalku" → dial, speaker → suara sintetik membacakan nama & jam jaga → display menyala sendiri → closing "besok giliran jaga: namaku, dua kali".
23 Palka gelap: hook "air di palka itu menolak cahaya" → dive, lift bag, slate → torch mati di dekat palka → ukiran lambung: kapal ini tak pernah berlayar → closing "palkanya terbuka dari dalam".
24 Satelit membengkak: hook "kapsulnya masih memancarkan" → ROV, manipulator → biomassa mengembang membungkus kapsul → sinyal kapsul berubah jadi detak → closing "detaknya seirama jantung pilot".
25 Autopsi cumi: hook "cumi ini ditangkap di atas palung" → lab, pisau bedah → kilau logam dalam daging → bagian logamnya tersusun rapi → closing "benda di dalamnya masih hangat".
26 Rantai ke palung: hook "rantai itu tak punya kapal" → dive, torch → rantai raksasa menjulang turun ke gelap → tiap mata rantai ada ukiran → closing "ukiran terakhir: tanggal besok".
27 Zona tenang: hook "kompas menyerah di garis ini" → dek malam, kompas berputar → air hitam menyerap semua cahaya → bintang tak tercermin → closing "lautnya tidak memantulkan kami".
28 Gerbang palung: hook "dinding palung punya pintu" → ROV, sonar → gerbang beton tulangan modern → lampu berdenyut di baliknya → closing "sonar menunjukkan ruang di belakangnya... berisi air yang lebih tua".
29 Peti timah: hook "jaring mengangkat yang tak kami cari" → winch, hook → peti berlumut, segel timah, tag: JANGAN DIBUKA 1911 → tetesan dari peti naik ke atas → closing "segelnya dipasang dari dalam".
30 Habitat terakhir: hook "log terakhir teknisi habitat" → habitat, monitor umbilical → monolog host bubble → grafik umbilical putus, lampu redup → closing "jika kalian menemukan log ini, jangan sambungkan lagi kabelnya".
