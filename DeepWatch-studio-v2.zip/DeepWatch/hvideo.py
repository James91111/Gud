# -*- coding: utf-8 -*-
"""
hvideo.py — render video animasi stickman dari naskah narasi.
  python3 hvideo.py <file_naskah.txt> <nomor_template> [suara]
Contoh: python3 hvideo.py naskah.txt 7
Hasil : hasil/final_HD0007.mp4  (audio TTS + subtitle terbakar di frame)
"""
import os, re, sys, asyncio, subprocess, time
from PIL import Image

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import hdeck as hd
import hstage as st

FPS = 20
VOICE_DEFAULT = 'en-US-ChristopherNeural'   # sesuai script TTS pengguna
VOICE_RATE = '-7%'
VOICE_PITCH = '-6Hz'
PROG = ''
PCT = 0
TRACE = []

def set_prog(s, pct=None):
    """Progres hidup: teks tahap + persen + log ber-timestamp untuk UI."""
    global PROG, PCT
    PROG = s
    if pct is not None:
        PCT = 0 if pct == 0 else max(PCT, pct)
    TRACE.append('%s  %s' % (time.strftime('%H:%M:%S'), s))
    if len(TRACE) > 250:
        TRACE.pop(0)
INTRO = 0.0    # tanpa kartu logo pembuka (branding tertanam di adegan)
ESTAB = 2.6    # establishing shot kapal/stasiun (tanpa subtitle)
OUTRO = 0.0    # tanpa kartu logo penutup
MAX_CHARS = 270
MAX_SRT_CHARS = 45
MIN_SPLIT_SEC = 2.0

def split_text_smart(text, max_chars=MAX_CHARS):
    if len(text) <= max_chars:
        return [text.strip()]
    chunks, current = [], text
    while len(current) > max_chars:
        cut = -1
        for p2 in ['...', '. ', '? ', '! ', ' — ', ' -- ']:
            tp = current.rfind(p2, int(max_chars * 0.4), max_chars + 50)
            if tp != -1 and tp > cut:
                cut = tp + len(p2.strip())
        if cut == -1:
            for p2 in [', ', '; ', ': ']:
                tp = current.rfind(p2, max_chars - 60, max_chars + 30)
                if tp != -1:
                    cut = tp + 1
                    break
        if cut == -1:
            cut = current.rfind(' ', max_chars - 30, max_chars + 10)
            if cut == -1:
                cut = max_chars
        piece = current[:cut].strip()
        if piece:
            chunks.append(piece)
        current = current[cut:].strip()
    if current:
        chunks.append(current)
    return [c for c in chunks if c]

def pause_for(chunk):
    if chunk.endswith('...') or '...' in chunk[-5:]:
        return 0.9
    if chunk.endswith('—') or chunk.endswith('--'):
        return 0.7
    if chunk.endswith(('.', '?', '!')):
        return 1.1
    if chunk.endswith(','):
        return 0.4
    return 0.5

def wav_duration(path):
    import wave
    with wave.open(path) as w:
        return w.getnframes() / float(w.getframerate())

def mp3_duration(path):
    """Durasi AKTUAL mp3 via parsing frame MPEG — kunci anti-drift subtitle."""
    data = open(path, 'rb').read()
    i, n = 0, len(data)
    if n > 10 and data[:3] == b'ID3':
        i = 10 + ((data[6] << 21) | (data[7] << 14) | (data[8] << 7) | data[9])
    SR_T = {(3, 0): 44100, (3, 1): 48000, (3, 2): 32000,
            (2, 0): 22050, (2, 1): 24000, (2, 2): 16000}
    BR1 = {1: 32, 2: 40, 3: 48, 4: 56, 5: 64, 6: 80, 7: 96, 8: 112, 9: 128, 10: 160, 11: 192, 12: 224, 13: 256, 14: 320}
    BR2 = {1: 8, 2: 16, 3: 24, 4: 32, 5: 40, 6: 48, 7: 56, 8: 64, 9: 80, 10: 96, 11: 112, 12: 128, 13: 144, 14: 160}
    total = 0.0
    while i < n - 4:
        if data[i] == 0xFF and (data[i + 1] & 0xE0) == 0xE0:
            b1, b2 = data[i + 1], data[i + 2]
            ver = (b1 >> 3) & 3
            bri = (b2 >> 4) & 15
            sri = (b2 >> 2) & 3
            pad = (b2 >> 1) & 1
            if ver in (2, 3) and 0 < bri < 15 and sri < 3:
                sr = SR_T[(ver, sri)]
                br = (BR1 if ver == 3 else BR2)[bri] * 1000
                samples = 1152 if ver == 3 else 576
                flen = int((144 if ver == 3 else 72) * br / sr) + pad
                total += samples / sr
                i += max(1, flen)
                continue
        i += 1
    return total

def fmt_srt(sec):
    h = int(sec // 3600); m = int((sec % 3600) // 60); s = int(sec % 60)
    ms = int(round((sec % 1) * 1000))
    if ms > 999:
        ms = 999
    return '%02d:%02d:%02d,%03d' % (h, m, s, ms)

def tts_build(naskah, work):
    """TTS per chunk + jeda tanda baca + SRT proporsional (metode script pengguna)."""
    import edge_tts, imageio_ffmpeg, subprocess, textwrap
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    text = re.sub(r'[ \t]+', ' ', naskah.replace('\r\n', '\n'))
    chunks = split_text_smart(text.strip())
    entries, timeline = [], []
    async def one(ch, p):
        await edge_tts.Communicate(ch, VOICE_DEFAULT, rate=VOICE_RATE, pitch=VOICE_PITCH).save(p)
    work = os.path.abspath(work)
    for i, ch in enumerate(chunks):
        p = os.path.join(work, 'chunk_%05d.mp3' % (i + 1))
        if not os.path.exists(p):
            asyncio.run(one(ch, p))
        sm = os.path.join(work, 'smooth_%05d.wav' % (i + 1))
        if not os.path.exists(sm):                  # trim_clean: buang dead silence + micro-fade 15 ms
            subprocess.run([ff, '-y', '-i', p, '-af',
                            'silenceremove=start_periods=1:start_threshold=-40dB:start_duration=0.02,areverse,'
                            'silenceremove=start_periods=1:start_threshold=-40dB:start_duration=0.02,areverse,'
                            'afade=t=in:d=0.015,areverse,afade=t=in:d=0.015,areverse',
                            '-ar', '24000', '-ac', '1', '-c:a', 'pcm_s16le', sm],
                           check=True, capture_output=True)
        timeline.append((ch, wav_duration(sm)))
        entries.append("file '%s'" % sm)
        set_prog('[1/4] TTS chunk %d/%d (%d huruf)' % (i + 1, len(chunks), len(ch)),
                 2 + 28 * (i + 1) / len(chunks))
        if i < len(chunks) - 1:
            pz = pause_for(ch)
            sp = os.path.join(work, 'sil_%s.wav' % str(pz).replace('.', '_'))
            if not os.path.exists(sp):
                subprocess.run([ff, '-y', '-f', 'lavfi', '-t', str(pz), '-i', 'anullsrc=r=24000:cl=mono',
                                '-c:a', 'pcm_s16le', sp], check=True, capture_output=True)
            entries.append("file '%s'" % sp)
    lst = os.path.join(work, 'concat.txt')
    open(lst, 'w').write('\n'.join(entries))
    nar = os.path.join(work, 'narasi.wav')
    subprocess.run([ff, '-y', '-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', nar],
                   check=True, capture_output=True)
    srt = os.path.join(work, 'narasi.srt')
    cur = 0.0; idx = 1; blocks = []
    for j, (ch, dur) in enumerate(timeline):
        st0, en0 = cur, cur + dur
        if len(ch) <= MAX_SRT_CHARS or dur < MIN_SPLIT_SEC:
            blocks.append('%d\n%s --> %s\n%s\n' % (idx, fmt_srt(st0), fmt_srt(en0),
                          '\n'.join(textwrap.wrap(ch, width=MAX_SRT_CHARS))))
            idx += 1
        else:                                       # tampilan tetap <=45 karakter/baris
            subs = textwrap.wrap(ch, width=MAX_SRT_CHARS)
            tot = len(ch); s0 = st0
            for sb in subs:
                d2 = dur * len(sb) / tot
                blocks.append('%d\n%s --> %s\n%s\n' % (idx, fmt_srt(s0), fmt_srt(s0 + d2), sb))
                idx += 1; s0 += d2
        cur = en0 + (pause_for(ch) if j < len(timeline) - 1 else 0.0)
    open(srt, 'w', encoding='utf-8').write('\n'.join(blocks))
    return nar, srt, cur

def parse_srt(path):
    txt = open(path, encoding='utf-8').read()
    out = []
    for blk in re.split(r'\n\s*\n', txt):
        m = re.search(r'(\d+:\d+:\d+[.,]\d+)\s*-->\s*(\d+:\d+:\d+[.,]\d+)', blk)
        if not m:
            continue
        def sec(s):
            s = s.replace(',', '.')
            h, mi, s2 = s.split(':')
            return int(h) * 3600 + int(mi) * 60 + float(s2)
        lines = [l for l in blk.splitlines() if l.strip() and '-->' not in l and not l.strip().isdigit()]
        if lines:
            out.append((sec(m.group(1)), sec(m.group(2)), ' '.join(lines)))
    return out

def render_video(naskah, tn, voice=VOICE_DEFAULT, sound=None, vol=0.35):
    global PROG
    import imageio_ffmpeg, hashlib, glob
    tn = ((int(tn) - 1) % hd.N_TEMPLATES) + 1
    t = hd.get_template(tn)
    os.makedirs(os.path.join(BASE, 'hasil'), exist_ok=True)
    work = os.path.join(BASE, 'work')
    os.makedirs(work, exist_ok=True)
    hsh = hashlib.md5((naskah + voice + VOICE_RATE + VOICE_PITCH).encode()).hexdigest()
    tag = hsh + '-tn%d-ev7' % tn                 # cache: naskah + template + versi engine
    tp = os.path.join(work, 'rendertag')
    prev = open(tp).read() if os.path.exists(tp) else ''
    if prev != tag:                                # beda naskah/template -> semua cache frame/audio dibuang
        for old in glob.glob(os.path.join(work, 'chunk_*.mp3')) + glob.glob(os.path.join(work, 'smooth_*.wav')) + \
                glob.glob(os.path.join(work, 'sil_*.wav')) + glob.glob(os.path.join(work, 'seg_*.mp4')) + \
                [os.path.join(work, 'video_raw.mp4'), os.path.join(work, 'narasi.wav'),
                 os.path.join(work, 'narasi.srt'), os.path.join(work, 'narasi_pad.m4a')]:
            if os.path.exists(old):
                os.remove(old)
        for hf in glob.glob(os.path.join(work, 'hash_*')):
            os.remove(hf)
        open(tp, 'w').write(tag)
    set_prog('[1/4] TTS per chunk + jeda + subtitle proporsional...', 0)
    nar, srt, aud_dur = tts_build(naskah, work)
    subs = parse_srt(srt)
    if not subs:
        raise SystemExit('SRT kosong — cek koneksi TTS.')
    aud_len = aud_dur + 0.6
    total = INTRO + aud_len + OUTRO        # logo -> narasi (kapal melebur di kalimat 1) -> logo
    # SATU KALIMAT NARASI = SATU ADEGAN (fragmen SRT berbagi adegan, aksi berkelanjutan)
    def _ws(s):
        return re.sub(r'\s+', '', s)
    norm = re.sub(r'[ \t]+', ' ', naskah.replace('\r\n', '\n')).strip()
    sents = [s.strip() for s in re.findall(r'[^.!?…]+[.!?…]*', norm) if s.strip()]
    NW = _ws(norm)
    spans = []
    p = 0
    for s in sents:
        w = _ws(s)
        spans.append((p, p + len(w)))
        p += len(w)
    ptr = 0
    sid_of = []
    bounds = {}
    for i, (a, b, txt) in enumerate(subs):
        w = _ws(txt)
        i0 = NW.find(w, max(0, ptr - 1), ptr + len(w) + 2)
        if i0 < 0:
            i0 = ptr
        mid = i0 + len(w) // 2
        sid = len(spans) - 1
        for j, (s0, s1) in enumerate(spans):
            if s0 <= mid < s1:
                sid = j
                break
        sid_of.append(sid)
        if sid not in bounds:
            bounds[sid] = [a, b]
        else:
            bounds[sid][1] = b
        ptr = i0 + len(w)
    scene_of = {}
    st.reset_scene_state()                       # engine v2: baris dinamis + lokasi sticky
    beats = []                                          # r26: 1 panel per KALIMAT (bukan per chunk)
    for sid in sorted(bounds):
        a, b = bounds[sid]
        parts = [p.strip() for p in re.split(r'(?:(?<=[.!?])|(?<=[.?!]")|(?<=[.!?\u201d]))\s+(?=[A-Z"\u201c])', sents[sid].strip()) if p.strip()]
        tot = sum(len(p) for p in parts) or 1
        t0 = a
        for p in parts:
            t1 = b if p is parts[-1] else t0 + (b - a) * len(p) / tot
            r = st.plan_scene(p, sid, tn)
            if sid not in scene_of:
                scene_of[sid] = r
            beats.append({'a': t0, 'b': t1, 'row': r, 'txt': p, 'loc': st.get_loc()})
            t0 = t1
    st.set_beats(beats)
    scenes = [(scene_of[sid_of[i]], a, b, txt, bounds[sid_of[i]][0], bounds[sid_of[i]][1])
              for i, (a, b, txt) in enumerate(subs)]
    sub_style = tn % 6
    raw = os.path.join(BASE, 'work', 'video_raw.mp4')
    nFrames = int(total * FPS)
    est_mnt = max(1, int(nFrames * 0.12 / 60) + 1)
    set_prog('[2/4] %d kalimat subtitle, %.1f detik, gaya subtitle #%d | perkiraan ±%d menit'
             % (len(subs), aud_len, sub_style + 1, est_mnt), 31)
    import math as _m
    SEG = 12.0                                      # checkpoint per segmen: resume tidak dari nol
    nSeg = max(1, _m.ceil(total / SEG))
    set_prog('[3/4] render %d frame @%dfps (%d segmen checkpoint)...' % (nFrames, FPS, nSeg), 32)
    st.reset_xfade()
    seg_paths = []
    n = 0
    t0 = time.time()
    for s in range(nSeg):
        sp = os.path.join(work, 'seg_%03d.mp4' % s)
        seg_paths.append(sp)
        t0s = s * SEG
        nf = int(round((min(total, (s + 1) * SEG) - t0s) * FPS))
        if os.path.exists(sp) and os.path.getsize(sp) > 4000:      # sudah ada -> lewati (resume)
            n += nf
            continue
        w2 = imageio_ffmpeg.write_frames(sp, (st.W, st.H), fps=FPS,
                                         codec='libx264', pix_fmt_in='rgb24', pix_fmt_out='yuv420p',
                                         macro_block_size=1, output_params=['-crf', '26'])
        w2.send(None)
        for fi in range(nf):
            tt = t0s + fi / FPS
            ta = tt - INTRO
            cur = None
            for k, (si, a, b, txt, sa, sb) in enumerate(scenes):
                if a <= ta < b:
                    cur = (si, txt, ta - sa, sb - sa)
                    break
            if cur is None:
                si, txt, stt, dur = scenes[-1][0], '', 0, 1
            else:
                si, txt, stt, dur = cur
            fr = st.render_frame(tn, t['domain'], t['pal'], t['silhouette'], ta, si, txt, stt, dur, sub_style, tn)
            w2.send(fr.tobytes())
            n += 1
            if n % (FPS * 10) == 0:
                el = max(0.01, time.time() - t0)
                eta = int((nFrames - n) / (n / el))
                set_prog('[3/4] segmen %d/%d · %.0f%% (%d/%d frame) · sisa ±%d dtk'
                         % (s + 1, nSeg, 100.0 * n / nFrames, n, nFrames, eta), 32 + 62 * n / nFrames)
                print('   ...' + PROG)
        w2.close()
    lst2 = os.path.join(work, 'seglist.txt')
    open(lst2, 'w').write('\n'.join("file '%s'" % os.path.abspath(p) for p in seg_paths))
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-y', '-f', 'concat', '-safe', '0', '-i', lst2,
                    '-c', 'copy', raw], check=True, capture_output=True)
    out = os.path.join(BASE, 'hasil', 'final_HD%04d.mp4' % tn)
    set_prog('[4/4] gabung audio (sinkron kartu logo)...', 94)
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    pad = os.path.join(BASE, 'work', 'narasi_pad.m4a')
    args = [ff, '-y']
    if INTRO > 0:
        args += ['-f', 'lavfi', '-t', str(INTRO), '-i', 'anullsrc=r=24000:cl=mono']
    args += ['-i', nar]
    if OUTRO > 0:
        args += ['-f', 'lavfi', '-t', str(OUTRO), '-i', 'anullsrc=r=24000:cl=mono']
    n_in = (1 if INTRO > 0 else 0) + 1 + (1 if OUTRO > 0 else 0)
    args += ['-filter_complex', ''.join('[%d:a]' % i for i in range(n_in)) +
             'concat=n=%d:v=0:a=1[a]' % n_in, '-map', '[a]', '-c:a', 'aac', pad]
    subprocess.run(args, check=True, capture_output=True)
    if sound and os.path.exists(sound):                     # backsound: loop + volume + fade
        set_prog('[4/4] gabung audio + backsound (loop, vol %d%%)...' % int(vol * 100), 94)
        flt = ('[2:a]volume=%f,afade=t=in:d=2.5,afade=t=out:st=%f:d=3[bg];'
               '[1:a][bg]amix=inputs=2:duration=first:weights=1 0.85:normalize=0[a]' % (vol, max(3.0, total - 3)))
        subprocess.run([ff, '-y', '-i', raw, '-i', pad, '-stream_loop', '-1', '-i', sound,
                        '-filter_complex', flt, '-map', '0:v', '-map', '[a]',
                        '-c:v', 'copy', '-c:a', 'aac', '-shortest', out], check=True, capture_output=True)
    else:
        set_prog('[4/4] gabung audio (sinkron kartu logo)...', 94)
        subprocess.run([ff, '-y', '-i', raw, '-i', pad, '-c:v', 'copy', '-c:a', 'copy',
                        '-shortest', out], check=True, capture_output=True)
    set_prog('SELESAI: ' + os.path.basename(out), 100)
    print('SELESAI:', out)
    return out

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    txt = open(sys.argv[1], encoding='utf-8').read().strip()
    v = sys.argv[3] if len(sys.argv) > 3 else VOICE_DEFAULT
    render_video(txt, sys.argv[2], v)
