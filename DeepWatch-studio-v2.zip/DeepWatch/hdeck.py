# -*- coding: utf-8 -*-
"""
hdeck.py — 1000 SETTING KREATIF anti-repetitif untuk channel Deep Watch
500 DEEP SPACE (HD-001..500) + 500 DEEP SEA (HD-501..1000).
Injektif: (worksite, role) mengkode index -> 500/domain dijamin unik.
"""
import os, random
from PIL import Image, ImageDraw

BASE = os.path.dirname(os.path.abspath(__file__))
N_TEMPLATES = 1000

# ================= DEEP SPACE =================
WS_S = [
 "Reactor duct lattice, Sector Nine — crawlways behind the core",
 "Harrow's End salvage yard — dead ships cracked open for parts",
 "Beacon relay at the system's edge — last light before open space",
 "Comms array over Vesalia Minor — listening post for colony traffic",
 "Saturn nuclear waste depot — hot cargo buried on night shift",
 "Weld cradle 17 — hull seam work on the unfinished ring",
 "Helium-3 harvester, lunar far side — dust that never settles",
 "Enceladus ice mine — drills tapping the geyser fields",
 "Asteroid crusher plant — ore, grit and deafening shake",
 "Mars hydroponics dome — the only green for miles",
 "Solar wing maintenance gantry — a mile of panels to keep clean",
 "Deep relay post K-77 — automated station, skeleton crew",
 "Orbital drydock — ships that arrive with holds sealed",
 "Kuiper survey tug — months alone mapping ice rocks",
 "Lagrange greenhouse station — crops under thin glass",
 "Regolith brick factory — press line that never stops",
 "Phobos antenna farm — dishes pointed at home",
 "Zero-g foundry — molten metal handled in vacuum",
 "Cryofuel depot — slush hydrogen at twenty kelvin",
 "Mars dust-storm watchpost — weeks of red dark",
 "Gravity-wave listening post — silence as the instrument",
 "Ceres ore elevator — two-kilometer shaft straight down",
 "Plasma scoop station — skimming a planet's thin upper air",
 "Graveyard orbit — wrecks that still transmit",
 "Terraform seeding station — drones sowing the sky"]
ROLE_S = [
 "reactor duct tech|crawling the core vents with a borescope and a prayer",
 "salvage engineer|cutting dead ships open and inventorying what's inside",
 "beacon keeper|keeping the edge-of-system light honest",
 "satellite tech|swapping fried transponders over a colony world",
 "waste depot night monitor|logging hot cargo casks that must not move",
 "hull welder|sealing micro-cracks on the outer seam",
 "coolant flush operator|purging lines that run warmer than they should",
 "EVA patch specialist|walking the hull after micrometeorite season",
 "ore crane operator|swinging multi-ton rock in a glass cab",
 "hydroponics tender|keeping tomatoes alive where nothing else grows",
 "sensor calibrator|trusting nothing until the numbers repeat",
 "fuel line inspector|hunting leaks that freeze before you see them",
 "antenna rigger|torquing dish bolts above a billion-mile drop",
 "reactor scram tester|proving the kill switch still kills",
 "cargo manifest clerk|counting crates that don't count back right",
 "ice core driller|pulling frozen history out of a moon",
 "foundry ladle operator|pouring light into vacuum molds",
 "cryo valve mechanic|wrenching valves colder than space",
 "relay dish aligner|holding a whisper-steady aim at home",
 "survey laser mapper|painting ice rocks with light, mile by mile"]
CTYPE_S = [
 "Physical predator|heat and CO2 sense|stalks service corridors, tests seals|cannot cross a hard vacuum gap",
 "Tissue parasite|enters through cuts and vents|rewires its host to open doors|dies without a living host",
 "Acoustic mimic|learns voices and knocks|replays them to lure|cannot imitate what it has never heard",
 "Radiation eater|drawn to reactor and isotopes|drains power, grows bold in the dark|weakens near clean cold",
 "Hull-vacuum stalker|rides the outside skin|reads vibration through the hull|cannot follow into pressurized core"]
HUNT_S = [
 "It learns one crew voice per shift and uses it at the wrong doors",
 "It knocks in the rhythm of the station's own pumps, one beat late",
 "It nests where the heat map is blind, behind the insulation you replaced",
 "It follows CO2 plumes, so breathing fast is a beacon",
 "It eats power first: lights dim before anything moves",
 "It stores what it takes, and arranges it near the airlock",
 "It only moves when the duct fans spin up, hiding in the noise",
 "It mirrors your flashlight sweeps, three seconds behind",
 "It tests every seal once a cycle, weakest joint first",
 "It goes still when watched by camera, and moves between frames"]
STAKE = [
 "Last rotation before going home for good",
 "Disciplinary solo assignment at an automated station",
 "Just a maintenance worker trying to finish quota safely",
 "Independent research contract with a strict secrecy clause",
 "Promotion review hinges on this shift's report",
 "Covering for a coworker who vanished last rotation",
 "Final shift before a wedding back on Earth",
 "Probation contract — one incident ends the career",
 "Overtime pay that buys the family's passage home",
 "The only tech left who knows this machine by heart"]
CREW = [
 "Dale (shift lead)", "Priya (med tech)", "Owen (rookie)", "Marta (comms)",
 "Silas (veteran welder)", "June (survey)", "Ravi (cargo)", "Cole (night watch)",
 "Ana (biologist)", "Bo (crane)", "Lena (nav)", "Marcus (security)",
 "Ida (cook-tech)", "Theo (driller)", "Ruth (inspector)", "Gus (mechanic)",
 "Nia (ROV remote)", "Hank (salvage)", "Faye (clerk)", "Eli (chaplain-tech)"]
HW_S = [
 "duct pressure-seal protocol — seal, listen, cycle",
 "suit O2 budget rule — turn back at half, no exceptions",
 "beacon handshake code — three pulses, then silence",
 "reactor scram chain — two keys, two hands, one count",
 "coolant flush sequence — never flush a hot line alone",
 "hull knock checklist — count knocks, log the rhythm",
 "airlock cycling rule — one person in the chamber at a time",
 "comms blackout window — nine minutes of true silence",
 "rad badge log — dose tells you where it has been",
 "tether rule — two points of contact outside the hull",
 "borescope sweep pattern — left seam first, always",
 "cargo cask lockout — a moved cask means a breached bay",
 "fan-spin noise mask — work only when the fans scream",
 "cold-spot map — the thermal camera never lies twice",
 "voice-print door lock — doors obey only live voices",
 "backup battery cage — keep one cell untouched, always",
 "emergency vent valve — the station's last loud word",
 "laser trip grid — invisible lines that keep a diary",
 "hard-vacuum gap rule — the creature's one true wall",
 "manual override key — the only key that is never logged"]
TWIST_S = [
 "the duct hum drops half a tone at junction nine|the nest was junction nine all along; the hum was its breathing",
 "your voice memo plays one second longer than recorded|the mimic had been adding a reply",
 "the spare suit log shows a suit dried overnight|someone — or something — wore it outside",
 "junction bolts you tightened are found loosened from the inside|it practices opening what you close",
 "the thermal cam shows a cold spot shaped like a person|it is warm-blooded; the cold is its shadow",
 "old logs mention a 'second count' during scram drills|the reactor was never the target; the count was feeding it",
 "your partner complains the intercom echoes|the echo was the first copy of a voice",
 "dust settles in arcs near the vent|it breathes; the arcs are its tide marks",
 "the beacon skips one handshake pulse every cycle|it has learned the code and is answering for you",
 "weld seams show teeth marks too fine for tools|it tastes the metal where you sleep",
 "the cargo manifest gains a crate no one shipped|it builds a larder from your supplies",
 "your own handwriting appears in a log you never wrote|it watched you write, and practiced",
 "the fans spin up with no command|it needs the noise; the station is its hunting horn",
 "a family photo is found facing the wrong way|it studies what you love before it takes it",
 "the O2 scrubber clogs with gray silk|it has been nesting in the air you breathe",
 "the laser grid logs a crossing at eye height, no mass|it can thin itself through the gaps",
 "the dead ship's black box is warm|it wears wrecks like shells",
 "your tether shows a second clip mark|it walked your line while you slept",
 "the scrawled warning matches the rookie's handwriting — but he was never here|it collects hands like voices",
 "the station clock runs four seconds slow since shift one|it lives in those four seconds"]
COST = [
 "you leave with your partner's dog tags and their unfinished log",
 "you vent your own workshop — and your career — into space",
 "you survive deaf, because the only escape was the vent horn",
 "you are the only one who remembers the station as it was",
 "you burn the archive so no one else learns its patterns",
 "you stay behind to hold the manual override until the ship clears",
 "you return with a tremor in the hand that signed the report",
 "you trade your eyes' night vision for one good look at it",
 "you black-list yourself to keep the company from sending others",
 "you keep its knocked rhythm in your head, and it knows you do"]
OPEN_S = [
 "A|LINEAR SLOW-BURN: shift starts normal; instruments go wrong first",
 "B|INCIDENT LOG / DEPOSITION: post-evacuation recording, chronology untangled",
 "C|IN MEDIA RES (TIGHT): threat now, then 1-2 natural sentences back",
 "D|ROUTINE ANOMALY: boring part swap reveals the first biological trace"]
RULE_N = [4, 5, 8, 10, 12, 13, 14]

# ================= DEEP SEA =================
WS_D = [
 "Sirena Deep submersible dock — trench wall lights at 4,000 meters",
 "Talvera Deep cable repair yard — splice bay under 2,800 meters",
 "Mona Passage wreck field — salvage grid over a 1974 loss",
 "Aleutian cable ship — night watch above the line",
 "Trench monitoring station — it knocks where the crew sleeps",
 "Mariana descent corridor — a second light falls with you",
 "Bermuda survey line — the compass points down at 3:13",
 "Alaska hydrophone array — listening under the ice shelf",
 "Seafloor manifold camp — claw marks outside the window",
 "Brine pool research pontoon — a lake under the sea",
 "Hydrothermal vent farm — chimneys that breathe",
 "Polar under-ice lab — the frozen ceiling that hums",
 "Deep wreck lift — the winch drum that will not stop paying out",
 "Aleutian buoy grid — signals from beneath the seafloor",
 "Drilling rig mudline — the pipe that breathes back",
 "Abyssal mining crawler — boring the plain for nodules",
 "Saturation bell habitat — three weeks at pressure",
 "Observatory node 7 — cameras that see it before you do",
 "Whale-fall research site — a feast that draws the wrong guests",
 "Canyon wall survey line — cliffs that echo wrong",
 "Tsunami sensor grid — pressure spikes with no quake",
 "Submarine landslide post — ground that moves on its own",
 "Shelf aquifer pump station — fresh water in salt dark",
 "Seamount lighthouse relief — a tower on a drowned peak",
 "Abyssal protein farm — vats glowing faintly in the black"]
ROLE_D = [
 "pipeline welder|burning arc on a pipe that carries a continent's gas",
 "submersible pilot|flying a tin bubble along a trench wall",
 "cable splicer|joining glass threads thinner than a finger, blind by camera",
 "salvage diver|cutting into a wreck that never filed a manifest",
 "winch operator|feeling the drum like a pulse",
 "ROV monitor|watching a machine's eyes twelve hours a day",
 "hydrophone tech|tuning ears that hear a hundred miles",
 "saturation diver|living at pressure, breathing metal-tasting gas",
 "manifold mechanic|torquing valves where the light is yours alone",
 "buoy tender|keeping surface markers honest over a deep line",
 "sonar watch officer|reading the sea's wallpaper for new furniture",
 "bell diver|riding the bell down like an elevator to nowhere",
 "mudline driller|feeding pipe into a floor that should be dead",
 "vent biologist|sampling chimneys hotter than an oven",
 "pressure lab tech|keeping samples alive that want to explode",
 "compass watchkeeper|trusting a needle nobody else believes",
 "wreck rigger|strapping tons of dead ship for the lift",
 "sediment corer|pulling history from a floor that hides things",
 "pump mechanic|keeping fresh water moving in the salt dark",
 "night cable watch|alone with the hum of the line below"]
CTYPE_D = [
 "Benthic predator|vibration and pressure sense|ambushes worksites, tests viewports|cannot chase into open water column",
 "Colonial parasite|spreads through hull biofilm|opens valves from inside|dies if the hull is burned clean",
 "Acoustic mimic|copies sonar pings and voices|lures divers off the line|confused by randomized ping patterns",
 "Hydrothermal entity|mineral-armored, heat-driven|rides vent plumes between sites|slows in cold current",
 "Ancient pressure dweller|responds to mechanical vibration|surfaces when machines drill|sinks when all motion stops"]
HUNT_D = [
 "It circles under the hull at lamp-change hour, always the same radius",
 "It answers the sonar ping with your own ping, half a second late",
 "It wears the faces of the lost, but only in peripheral light",
 "It knocks on the hull where the bunks are, once per watch",
 "It learned the ROV light pattern and waits at the end of it",
 "It drags tools toward the trench, one per tide",
 "It hides in the bubble stream of the divers' exhaust",
 "It bites the cable where the current is loudest, masking the sound",
 "It presses against the viewport until the glass sings",
 "It follows the winch line down, hand over hand"]
HW_D = [
 "decompression schedule — the table is the law, no mercy",
 "ballast trim rule — the station lists before it floods",
 "sonar ping rotation — never the same interval twice",
 "umbilical management — slack is life, tension is a message",
 "bell door protocol — one diver counted, one door open",
 "viewport stress log — the glass keeps a diary of pressure",
 "thruster quiet-hour — silence is camouflage",
 "cable tension alarm — a bite reads as a shrug on the gauge",
 "saturation gas mix — the blend decides how you think",
 "emergency blow procedure — the station's one jump",
 "hull knock log — count, rhythm, depth",
 "light discipline — dark lamps during the circling hour",
 "ROV tether rule — never let it learn your pattern",
 "cold-water curtain — the vent creature's wall",
 "manual valve wheel — the only control with no electronics",
 "backup ballast pig — iron that never lies",
 "hydrophone array sweep — ears before eyes",
 "wreck line anchor — the lift depends on one honest knot",
 "pressure equalization ritual — slow is smooth, smooth is alive",
 "seafloor beacon code — three flashes, then black"]
TWIST_D = [
 "the valve wheel turns a quarter on its own every tide|it has been practicing the wheel, and tonight it finishes",
 "your dive computer logs a dive you never made|something wore your transponder",
 "the hydrophone records your partner's voice at 600 meters — he was topside|the sea keeps copies",
 "bite marks on the cable move against the current|it herds the line like a fence",
 "the compass needle points at the bell, not north|it is magnetic; it has been the needle's north",
 "the winch drum counts one extra turn|it rode the line down with you",
 "condensation on the inside of the viewport forms arcs|it breathes on your world from its side",
 "the old logbook mentions 'the second light' in 1974|it has been falling with every descent since",
 "the brine pool's edge shows boot prints facing out|something left the lake, not entered it",
 "your suit's O2 reads higher after the dark stretch|it was breathing for you, keeping you docile",
 "the sonar shows a wreck that matches your own station|it builds replicas to practice entry",
 "the sediment core contains modern cable insulation|it buries what it learns",
 "the bell's door seal shows teeth marks spaced like a human bite|it tries to be you",
 "the buoy transmits from under the seafloor|the buoy was taken; the signal is a lure",
 "the kelp-free plain shows a straight furrow behind the crawler|it plows; it farms; you are in the field",
 "the pressure spikes match the cook's knife rhythm|it listens through the hull like a drum",
 "the lighthouse lamp flashes a code no one sent|it answers ships that never arrived",
 "your partner's knot is tied left-handed now|it practices hands like voices",
 "the pump draws warm water at 3 a.m.|it nests in the intake, growing",
 "the whale-fall bones are arranged in a spiral|it decorates; it invites"]
PAL_S = [("nebula violet", "#2A1B4A", "#8E6BF0"), ("reactor teal", "#04222B", "#2EE6C8"),
         ("mars rust", "#2B0F0A", "#FF6B3D"), ("ice blue", "#071A2E", "#6FD3FF"),
         ("sodium amber", "#241503", "#FFB43D"), ("void green", "#03170D", "#4DFF9E"),
         ("alarm red", "#200608", "#FF4D5E"), ("lunar gray", "#101318", "#B8C4D8"),
         ("plasma pink", "#26081F", "#FF6BCB"), ("deep indigo", "#0A0E2A", "#5E7BFF")]
PAL_D = [("abyss teal", "#02131A", "#1FD3C0"), ("trench black", "#04070C", "#3E7CA6"),
         ("biolume green", "#03170F", "#57FFB0"), ("hydrothermal orange", "#1C0B04", "#FF8A3D"),
         ("polar cyan", "#06202B", "#7FE8FF"), ("brine purple", "#170A26", "#B07BFF"),
         ("sediment brown", "#170F08", "#D8A25E"), ("sonar lime", "#0A1403", "#C6FF4D"),
         ("warning red", "#1C0508", "#FF5560"), ("moonpool silver", "#0B1218", "#CFE2EE")]
SIL_S = ["duct worm", "pod cluster", "shadow sail", "tendril mass", "jaw wedge",
         "ring of lights", "filament web", "hunched mimic", "spindle swarm", "void maw"]
SIL_D = ["tentacle crown", "eel ribbon", "lantern cluster", "maw wedge", "crab spire",
         "jelly bell", "fin blades", "coil serpent", "angler lure", "colonial mat"]
LAY_S = ["viewport interior", "gantry exterior", "corridor crawl", "control room", "cargo bay"]
LAY_D = ["porthole interior", "dive bell exterior", "habitat corridor", "sonar room", "wet dock"]

# ---------- UNIVERS SUASANA / GERAK / AKSI / EFEK HORROR (stickman) ----------
MOODS = [
 "slow-burn dread — everything normal except one number",
 "false calm — quiet that feels watched",
 "claustrophobia — walls, ducts, gauges too close",
 "isolation — no reply on any channel",
 "paranoia — every sound gets a second reading",
 "panic sprint — procedure vs adrenaline",
 "grief — working beside what's left",
 "awe-terror — it is beautiful and it is eating the hull"]
CAM_MOVES = [
 "slow push-in on the gauge cluster",
 "static wide, character small in frame",
 "handheld micro-shake during the knock",
 "POV lamp sweep down the corridor",
 "tilt down from viewport to the floor",
 "dolly along the pipe run, lights passing",
 "rack focus glass-to-shadow",
 "crane up over the gantry as alarms start"]
ACT_WORKER = [
 "welding — sparks cone, visor down",
 "cranking a valve wheel, both hands",
 "crawling a duct with a borescope",
 "staring at one wrong gauge",
 "backing away, lamp raised",
 "running, tether trailing",
 "keying the radio, no answer",
 "sealing a hatch against the dark",
 "floating on tether outside the hull",
 "crouched behind a crate, breathing slow"]
ACT_POSE = {"welding": 0, "cranking": 1, "crawling": 2, "staring": 3, "backing": 4,
            "running": 4, "keying": 1, "sealing": 1, "floating": 5, "crouched": 2}
FX_SPACE = [
 "spark shower from a cut line",
 "vent steam crossing the frame",
 "lamp flicker on creature beats",
 "dust motes in the work light",
 "alarm strobe washing the wall",
 "debris drift in zero-g",
 "shadow pass across the viewport",
 "screen static burst on the monitor",
 "power dip — lights brown-out",
 "condensation beads freezing on glass"]
FX_SEA = [
 "bubble stream up the glass",
 "hairline crack spreading on the viewport",
 "condensation drips inside the bell",
 "silt cloud stirred outside",
 "bioluminescent pulse in the black",
 "hull groan shake — dust from seams",
 "lamp cone wobble in current",
 "marine snow thickening",
 "shadow outside the glass, then gone",
 "sonar ping ring expanding"]

# ---------------- pemetaan template ----------------
def get_template(n):
    n = ((int(n) - 1) % N_TEMPLATES) + 1
    space = n <= 500
    m = (n - 1) % 500
    WS, ROLE, CT, HUNT, HW, TW, PAL, SIL, LAY = (
        (WS_S, ROLE_S, CTYPE_S, HUNT_S, HW_S, TWIST_S, PAL_S, SIL_S, LAY_S) if space else
        (WS_D, ROLE_D, CTYPE_D, HUNT_D, HW_D, TWIST_D, PAL_D, SIL_D, LAY_D))
    ws, role = WS[m % 25], ROLE[(m // 25) % 20]
    t = dict(
        id=n, domain='SPACE' if space else 'SEA',
        worksite=ws.split(' — ')[0], flavor=ws.split(' — ')[1],
        role=role.split('|')[0], task=role.split('|')[1],
        creature=CT[m % 5], hunt=HUNT[(m * 3) % 10],
        stake=STAKE[(m * 7) % 10], crew=CREW[(m * 11) % 20],
        hardware=HW[(m * 13) % 20], twist=TW[(m * 17) % 20],
        cost=COST[(m * 19) % 10], opening=OPEN_S[(m * 23) % 4],
        rules=RULE_N[(m * 29) % 7],
        pal=PAL[m % 10], layout=LAY[(m // 10) % 5], silhouette=SIL[(m // 50) % 10],
        mood=MOODS[(m * 31) % 8], cam=CAM_MOVES[(m * 37) % 8],
        action=ACT_WORKER[(m * 41) % 10], fx=(FX_SPACE if space else FX_SEA)[(m * 43) % 10],
        bg='hd%04d' % n)
    return t

def visual_block(n):
    t = get_template(n)
    p = t['pal']
    return '\n'.join([
        '=== VISUAL DIRECTION (%s) ===' % t['domain'],
        'SETTING: %s — %s' % (t['worksite'], t['flavor']),
        'FRAMING: %s; palette "%s" (bg %s, accent %s)' % (t['layout'], p[0], p[1], p[2]),
        'MOOD: %s' % t['mood'],
        'CAMERA MOVE: %s' % t['cam'],
        'STICKMAN WORKER ACTION: %s' % t['action'],
        'HORROR FX OVERLAY: %s' % t['fx'],
        'CREATURE SILHOUETTE: %s — appear as shadow/partial only, never full-body before Part 3' % t['silhouette'],
        'HUD PROPS: gauge cluster, work lamp cone, checklist card, tether line',
        'MOTION PLAN: one hard cut per escalation; fx synced to creature beats; never repeat the same camera move twice in a row',
        'THUMBNAIL: worker silhouette + one accent-%s light source + creature hint at edge' % p[2].lower()])

def concept_block(n):
    t = get_template(n)
    foresh, twist = t['twist'].split('|')
    return '\n'.join([
        '=== EPISODE SETTINGS (%s) — follow ALL ===' % t['domain'],
        'WORKSITE & SECTOR: %s — %s' % (t['worksite'], t['flavor']),
        'WORKER ROLE & TASK: %s — %s' % (t['role'], t['task']),
        'OPENING STYLE: [%s]' % t['opening'],
        'CREATURE PROFILE: %s' % t['creature'],
        'CREATURE HUNTING LOGIC: %s' % t['hunt'],
        'CREATURE SENSORY ANCHOR: %s' % t['silhouette'],
        'PRIMARY PERSONAL STAKE: %s' % t['stake'],
        'KEY SUPPORTING CHARACTER: %s' % t['crew'],
        'HARDWARE / PROCEDURE ANCHOR: %s' % t['hardware'],
        'MOOD & ATMOSPHERE: %s' % t['mood'],
        'STATION RULES: %d explicit rules woven into Part 1-2' % t['rules'],
        'FORESHADOWING DETAIL (Part 1): %s' % foresh,
        'VALIDATED TWIST (Part 4): %s' % twist,
        'SURVIVAL PRICE / ENDING COST: %s' % t['cost']])

# ---------------- urutan penugasan acak-terjamin (anti pola berdekatan) ----
def order(k, dom='AUTO'):
    """k ke-1..N -> nomor template; permutasi (x211) supaya episode berurutan
    melompat acak di ruang 1000 setting (gcd(211,1000)=gcd(211,500)=1)."""
    k = int(k)
    if dom == 'SPACE':
        return ((k - 1) * 211) % 500 + 1
    if dom == 'SEA':
        return 500 + ((k - 1) * 211) % 500 + 1
    return ((k - 1) * 211) % N_TEMPLATES + 1

# ---------------- stickman + efek horor ----------------
def _stickman(d, x, y, s, pose, dom, accent):
    """stickman pekerja: x,y = titik pinggul; s = tinggi; pose 0..5"""
    suit = (210, 216, 228) if dom == 'SPACE' else (228, 178, 90)
    w = max(3, s // 22)
    hx, hy = x, y - int(s * 0.45)                 # kepala
    if pose == 2:                                 # merangkak: badan horizontal
        d.line([(x - s // 3, y), (x + s // 4, y - s // 8)], fill=suit, width=w)
        d.line([(x + s // 4, y - s // 8), (x + s // 2, y - s // 6)], fill=suit, width=w)
        d.line([(x - s // 3, y), (x - s // 2, y + s // 8)], fill=suit, width=w)
        d.line([(x - s // 3, y), (x - s // 5, y + s // 6)], fill=suit, width=w)
        hx, hy = x + s // 2 + 6, y - s // 5
    elif pose == 5:                               # melayang di tether
        d.line([(x, y - s // 3), (x + s // 6, y)], fill=suit, width=w)
        d.line([(x + s // 6, y), (x - s // 8, y + s // 3)], fill=suit, width=w)
        d.line([(x + s // 6, y), (x + s // 3, y + s // 3)], fill=suit, width=w)
        d.line([(x, y - s // 3), (x - s // 4, y - s // 2)], fill=suit, width=w)
        d.line([(x, y - s // 3), (x + s // 3, y - s // 2 - 6)], fill=suit, width=w)
        d.line([(x + s // 3, y - s // 2 - 6), (x + s // 2, y - s)], fill=(150, 160, 175), width=2)
    else:
        lean = {0: 2, 1: 4, 3: 0, 4: -5}[pose]
        d.line([(x, y - s // 3), (x + lean, y)], fill=suit, width=w)          # badan
        d.line([(x, y), (x - s // 6, y + s // 3)], fill=suit, width=w)        # kaki
        d.line([(x, y), (x + s // 5, y + s // 3)], fill=suit, width=w)
        if pose == 0:   # welding: lengan depan + percik
            d.line([(x + lean, y - s // 4), (x + s // 2, y - s // 5)], fill=suit, width=w)
            d.line([(x + lean, y - s // 4), (x + s // 6, y - s // 8)], fill=suit, width=w)
        elif pose == 1: # kedua tangan ke depan (valve/radio/hatch)
            d.line([(x + lean, y - s // 4), (x + s // 3, y - s // 6)], fill=suit, width=w)
            d.line([(x + lean, y - s // 4), (x + s // 3, y - s // 3)], fill=suit, width=w)
        elif pose == 4: # mundur/lari: lengan jaga jarak
            d.line([(x + lean, y - s // 4), (x + s // 3, y - s // 2)], fill=suit, width=w)
            d.line([(x + lean, y - s // 4), (x - s // 4, y - s // 6)], fill=suit, width=w)
        else:           # stare: lengan turun
            d.line([(x, y - s // 4), (x - s // 7, y - s // 10)], fill=suit, width=w)
            d.line([(x, y - s // 4), (x + s // 7, y - s // 10)], fill=suit, width=w)
        hx, hy = x + lean, y - s // 3 - 8
    r = max(5, s // 9)
    d.ellipse([hx - r, hy - r, hx + r, hy + r], fill=suit)
    if dom == 'SPACE':
        d.ellipse([hx - r + 2, hy - r + 2, hx + r - 1, hy + r - 2], fill=(20, 30, 48))
        d.arc([hx - r, hy - r, hx + r, hy + r], 200, 340, fill=accent, width=2)
    else:
        d.ellipse([hx - r // 2, hy - r // 2, hx + r // 2, hy + r // 2], fill=(30, 45, 60))
    d.line([(x - s // 5, y - s // 4), (x - s // 5, y - s // 12)], fill=(120, 128, 140), width=w)  # tank

def _fx(d, rng, dom, fx, W, H, accent, px=None, py=None):
    a = tuple(int(c * 0.55) for c in tuple(int(accent[i:i + 2], 16) for i in (1, 3, 5)))
    if 'spark' in fx and px is not None:
        for _ in range(26):
            d.line([(px, py), (px + rng.randrange(-26, 26), py + rng.randrange(-20, 14))],
                   fill=(255, rng.randrange(140, 220), 60), width=1)
    elif 'steam' in fx or 'silt' in fx:
        for _ in range(7):
            y0 = rng.randrange(120, 420)
            d.ellipse([rng.randrange(0, 700), y0, rng.randrange(760, 959), y0 + 46],
                      fill=(70, 76, 84) if dom == 'SPACE' else (72, 60, 44))
    elif 'flicker' in fx or 'wobble' in fx:
        for _ in range(3):
            y0 = rng.randrange(80, 460)
            d.rectangle([0, y0, W, y0 + rng.randrange(4, 14)], fill=(26, 32, 46))
    elif 'dust' in fx or 'snow' in fx:
        for _ in range(60):
            d.point((rng.randrange(W), rng.randrange(H)), fill=(190, 200, 210))
    elif 'strobe' in fx:
        d.rectangle([0, 0, W, H], fill=(60, 10, 16))
    elif 'debris' in fx:
        for _ in range(8):
            x0, y0 = rng.randrange(100, 860), rng.randrange(90, 440)
            d.rectangle([x0, y0, x0 + rng.randrange(4, 12), y0 + rng.randrange(3, 8)], fill=(90, 98, 112))
    elif 'shadow' in fx:
        d.ellipse([rng.randrange(200, 500), rng.randrange(120, 260),
                   rng.randrange(620, 880), rng.randrange(300, 420)], fill=(2, 3, 6))
    elif 'static' in fx:
        for _ in range(160):
            d.point((rng.randrange(W - 220, W - 40), rng.randrange(70, 200)), fill=(220, 226, 236))
    elif 'dip' in fx or 'groan' in fx:
        d.rectangle([0, 0, W, H], fill=(4, 5, 9))
    elif 'crack' in fx:
        x0, y0 = rng.randrange(100, 300), rng.randrange(100, 200)
        for _ in range(6):
            x1, y1 = x0 + rng.randrange(30, 90), y0 + rng.randrange(-10, 60)
            d.line([(x0, y0), (x1, y1)], fill=(220, 235, 245), width=1)
            x0, y0 = x1, y1
    elif 'bubble' in fx or 'drips' in fx or 'condensation' in fx:
        for i in range(10):
            x0 = rng.randrange(120, 840)
            y0 = rng.randrange(140, 460)
            if 'bubble' in fx:
                d.ellipse([x0, y0 - i * 6, x0 + 6, y0 + 6 - i * 6], outline=(170, 210, 230))
            else:
                d.line([(x0, y0), (x0, y0 + 8)], fill=(170, 210, 230), width=1)
    elif 'bioluminescent' in fx or 'ping' in fx:
        cx0, cy0 = rng.randrange(300, 700), rng.randrange(150, 350)
        for i in range(1, 5):
            d.ellipse([cx0 - i * 26, cy0 - i * 18, cx0 + i * 26, cy0 + i * 18], outline=a)
    elif 'alarm' in fx:
        d.ellipse([W - 90, 66, W - 70, 86], fill=(255, 60, 70))

# ---------------- latar pra-render ----------------
def _draw_space(n, pal, lay, sil, act, fx):
    W, H = 960, 540
    rng = random.Random(n * 7919)
    im = Image.new('RGB', (W, H)); d = ImageDraw.Draw(im)
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=(int(5 + 10 * k), int(8 + 6 * k), int(20 + 10 * k)))
    for _ in range(140):
        x, y, r = rng.randrange(W), rng.randrange(H), rng.choice([1, 1, 1, 2])
        d.ellipse([x, y, x + r, y + r], fill=(200 + rng.randrange(55),) * 3)
    px, py, pr = rng.randrange(200, 760), rng.randrange(430, 620), rng.randrange(260, 420)
    d.ellipse([px - pr, py - pr, px + pr, py + pr], fill=pal[1])
    d.arc([px - pr, py - pr, px + pr, py + pr], 190, 350, fill=pal[2], width=5)
    d.rectangle([0, 0, W, 60], fill=(6, 8, 14)); d.rectangle([0, H - 46, W, H], fill=(6, 8, 14))
    d.rectangle([0, 0, 26, H], fill=(6, 8, 14)); d.rectangle([W - 26, 0, W, H], fill=(6, 8, 14))
    for i in range(6):
        d.line([(140 + i * 130, 60), (140 + i * 130, 40)], fill=(30, 36, 52), width=4)
    if lay in ('gantry exterior', 'cargo bay'):
        d.rectangle([80, H - 130, 300, H - 46], fill=(10, 13, 22))
        d.line([(300, H - 130), (430, 70)], fill=(28, 34, 50), width=6)
    for i in range(5):
        d.rectangle([W - 210 + i * 26, 70, W - 196 + i * 26, 84], fill=pal[2] if i % 2 else (40, 46, 66))
    cx, cy = rng.randrange(300, 700), rng.randrange(140, 330)
    d.ellipse([cx - 60, cy - 18, cx + 60, cy + 18], fill=(8, 6, 16))
    for i in range(7):
        a = rng.randrange(-30, 30)
        d.line([(cx - 60 + i * 20, cy), (cx - 70 + i * 20, cy + 40 + a)], fill=(8, 6, 16), width=5)
    for i in range(3):
        d.ellipse([cx + 70 + i * 14, cy - 6, cx + 76 + i * 14, cy], fill=pal[2])
    sx, sy = rng.randrange(140, 330), H - 62
    _stickman(d, sx, sy, 96, ACT_POSE[act.split(' ')[0].rstrip(',-')], 'SPACE', pal[2])
    _fx(d, rng, 'SPACE', fx, W, H, pal[2], px=sx + 46, py=sy - 20)
    return im

def _draw_sea(n, pal, lay, sil, act, fx):
    W, H = 960, 540
    rng = random.Random(n * 104729)
    im = Image.new('RGB', (W, H)); d = ImageDraw.Draw(im)
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=(int(4 + 18 * (1 - k)), int(14 + 30 * (1 - k)), int(22 + 34 * (1 - k))))
    for i in range(4):
        x0 = rng.randrange(100, 800)
        d.polygon([(x0, 0), (x0 + 90, 0), (x0 + 210, H), (x0 + 60, H)], fill=(18, 40, 52))
    for _ in range(120):
        x, y = rng.randrange(W), rng.randrange(H)
        d.point((x, y), fill=(140 + rng.randrange(60),) * 3)
    d.rectangle([0, H - 70, W, H], fill=(5, 9, 13))
    d.rectangle([60, H - 150, 320, H - 70], fill=(9, 14, 20))
    for i in range(6):
        d.ellipse([80 + i * 40, H - 130, 96 + i * 40, H - 114], fill=pal[2])
    d.line([(320, H - 110), (520, H - 70)], fill=(20, 28, 36), width=6)
    cx, cy = rng.randrange(420, 820), rng.randrange(160, 360)
    d.ellipse([cx - 70, cy - 26, cx + 70, cy + 26], fill=(3, 6, 9))
    for i in range(6):
        a = rng.randrange(20, 60)
        d.line([(cx - 50 + i * 20, cy + 10), (cx - 60 + i * 20, cy + 10 + a)], fill=(3, 6, 9), width=6)
    for i in range(4):
        d.ellipse([cx - 30 + i * 22, cy - 8, cx - 24 + i * 22, cy - 2], fill=pal[2])
    for i in range(8):
        x = rng.randrange(cx - 60, cx + 80)
        d.ellipse([x, cy + 60 + i * 8, x + 5, cy + 66 + i * 8], outline=(150, 200, 220))
    sx, sy = rng.randrange(560, 780), H - 74
    _stickman(d, sx, sy, 92, ACT_POSE[act.split(' ')[0].rstrip(',-')], 'SEA', pal[2])
    _fx(d, rng, 'SEA', fx, W, H, pal[2], px=sx + 44, py=sy - 20)
    return im

def render_bg(n):
    t = get_template(n)
    if t['domain'] == 'SPACE':
        return _draw_space(n, t['pal'], t['layout'], t['silhouette'], t['action'], t['fx'])
    return _draw_sea(n, t['pal'], t['layout'], t['silhouette'], t['action'], t['fx'])

def ensure_bgpreviews():
    out = os.path.join(BASE, 'assets', 'hbg')
    os.makedirs(out, exist_ok=True)
    n = 0
    for i in range(1, N_TEMPLATES + 1):
        p = os.path.join(out, 'hd%04d.png' % i)
        if os.path.exists(p):
            continue
        render_bg(i).save(p)
        n += 1
    return n
