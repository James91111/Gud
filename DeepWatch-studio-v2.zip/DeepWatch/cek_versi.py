#!/usr/bin/env python3
# CEK VERSI ENGINE — jalankan di folder DeepWatch hasil ekstrak:
#   python3 cek_versi.py
# Kalau ada yang BUKAN v26, berarti folder ini MASIH CAMPUR file lama.
import os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
cek = [
    ('hstage.py', 'KANVAS MARATHON v4',        'marathon: satu kanvas panjang, dunia ditarik ke kiri'),
    ('hstage.py', 'r25: framing TETAP',        'kamera diam: tanpa zoom-in/zoom-out, tanpa lompatan'),
    ('hstage.py', 'def _narr_props',           'objek muncul saat narasi menyebutnya (20 pemicu)'),
    ('hvideo.py', 'r26: 1 panel per KALIMAT',  '1 panel per kalimat narasi (bukan per chunk)'),
    ('hvideo.py', "-tn%d-ev6' % tn",           'cache versi ev6 (cache lama otomatis tidak dipakai)'),
    ('horrorstudio.py', 'ENGINE r26-MARATHON', 'label versi di header UI'),
]
ok = True
for fn, mark, desc in cek:
    p = os.path.join(BASE, fn)
    ada = os.path.exists(p) and mark in open(p, encoding='utf-8', errors='ignore').read()
    ok = ok and ada
    print('[%s] %-22s %s' % ('BARU' if ada else 'LAMA!', fn, desc))
print()
if ok:
    print('HASIL: folder ini BENAR versi r26-MARATHON. Render dari folder ini.')
else:
    print('HASIL: folder ini MASIH ADA file lama!')
    print('Solusi: HAPUS TOTAL folder DeepWatch lama, lalu ekstrak zip baru ke folder BARU,')
    print('jangan menimpa folder lama. Pastikan cuma ada SATU folder DeepWatch di laptop.')
sys.exit(0 if ok else 1)
