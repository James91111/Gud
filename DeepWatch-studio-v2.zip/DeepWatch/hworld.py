# -*- coding: utf-8 -*-
"""
hworld.py — WORLD LAYER DeepWatch v2.
Lapisan baru di atas hstage: LATAR MENGIKUTI NARASI + NARATOR HIDUP.
 - LOCATION GRAMMAR : kata kunci kalimat -> lokasi (19 jenis), furnitur + living props.
 - HOST MODE        : tanpa aksi -> narator hadap kamera, mulut sync, kedip, gestur, bubble.
 - WALK-IN          : ganti lokasi -> narator berjalan (kaki bergerak) masuk ke set.
 - LOCOMOTION       : walk / swim / rov (kendaraan+thruster) / eva (tether).
 - TOOL LIBRARY     : alat di tangan (las arc, beliung, kamera flash, bor, dst) + efek cahaya.
 - CAST & CONVO     : NPC bekerja di lokasi; percakapan = bubble kiri/kanan + tag nama.
 - SUBTITLE V2      : bubble <=42 karakter/baris, maks 2 baris, sync dari SRT hvideo.
Semua digambar dari kode (tanpa file PNG), kalem (flicker <=1 Hz, easing halus).
"""
import math, random, re
from PIL import Image, ImageDraw, ImageFont

CW, CH = 1152, 648
W, H = 960, 540
GROUND = 545.0
MARK_X = 430.0

def _font(sz):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
              '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        try:
            return ImageFont.truetype(p, sz)
        except Exception:
            pass
    return ImageFont.load_default()

def _easeio(x):
    x = min(1.0, max(0.0, x))
    return 0.5 - 0.5 * math.cos(math.pi * x)

def _easeo(x):
    x = min(1.0, max(0.0, x))
    return 1.0 - (1.0 - x) ** 3

def _blink_on(t, period, duty=0.16, off=0.0):
    return ((t / period + off) % 1.0) < duty

def _h(k):                                    # hash deterministik utk partikel
    k = (k * 2654435761) & 0xFFFFFFFF
    return (k ^ (k >> 13)) / 4294967295.0

def _fall(d, t, seed, n, w, h, vy, vx, col, sz=2):
    for k in range(n):
        bx = _h(seed + k * 3) * w
        by = _h(seed + k * 7) * h
        x = int((bx + t * vx + k * 13) % w)
        y = int((by + t * vy) % h)
        d.rectangle([x, y, x + sz, y + sz], fill=col)

def _grad(d, w, h, top, bot, step=4):
    for y in range(0, h, step):
        k = y / h
        d.line([(0, y), (w, y)], fill=(int(top[0] + (bot[0] - top[0]) * k),
                                       int(top[1] + (bot[1] - top[1]) * k),
                                       int(top[2] + (bot[2] - top[2]) * k)))

def _stars(d, rng, n=70):
    for _ in range(n):
        x, y = rng.randrange(CW), rng.randrange(int(CH * 0.62))
        a = rng.randrange(140, 235)
        d.point((x, y), fill=(a, a, min(255, a + 20)))

def _brand(d):
    f = _font(12)
    d.text((26, CH - 30), 'DEEPWATCH', font=f, fill=(120, 128, 146, 150))

# ================= GRAMMAR: kata kunci -> dunia =================
_LOC = [
    ('cave', ['cave', 'blue hole', 'grotto', 'cenote', 'cavern', 'swim the tunnel']),
    ('rig', ['oil rig', 'platform', 'abandoned rig', 'derrick']),
    ('lighthouse', ['lighthouse', 'lamp room', 'keeper']),
    ('sonar', ['sonar', 'hydrophone', 'acoustic', 'listening post', 'underwater sound']),
    ('lab', ['lab', 'autopsy', 'dissect', 'specimen tank', 'examination table']),
    ('cryo', ['cryo', 'pod', 'morgue', 'freezer deck']),
    ('decon', ['decon', 'decontamination', 'shower arch']),
    ('rov', ['rov', 'submersible', 'manipulator arm']),
    ('eva', ['eva', 'tether', 'outside the hull', 'wheel bay', 'landing gear', 'strut']),
    ('moon', ['moon', 'excavation', 'dig site', 'regolith', 'landing field']),
    ('duct', ['duct', 'oxygen line', 'vent', 'airway', 'maintenance shaft']),
    ('ice', ['ice shelf', 'glacier', 'antarctic', 'ice camp', 'through the ice']),
    ('fuel', ['fuel dock', 'refuel', 'fuel line', 'tank farm', 'propellant']),
    ('gantry', ['gantry', 'antenna', 'comms array', 'dish', 'relay mast']),
    ('control', ['control room', 'console', 'bridge', 'monitoring bay']),
    ('deck', ['ship deck', 'survey ship', 'dredger', 'dredge', 'gunwale', 'mast']),
    ('habitat', ['habitat', 'undersea station', 'saturation', 'living module']),
    ('seabed', ['seafloor', 'seabed', 'trench', 'dive', 'underwater', 'kelp', 'reef', 'wreck']),
    ('corridor', ['corridor', 'bulkhead', 'passageway', 'airlock']),
]
_TOOL = [
    ('weld', ['weld', 'torch', 'seam', 'arc']),
    ('pick', ['mining', 'asteroid', 'pickaxe', 'ore', 'swing the pick']),
    ('camera', ['camera', 'photograph', 'filming', 'shoot the']),
    ('drill', ['drill', 'bore', 'core sample']),
    ('joystick', ['joystick', 'manipulator', 'piloting', 'console screen']),
    ('scalpel', ['scalpel', 'dissect', 'cut open', 'incision']),
    ('reel', ['reel', 'winch', 'spool', 'dredge line', 'cable']),
    ('headset', ['headphones', 'headset', 'listen to the recording']),
    ('radio', ['radio', 'hail', 'transmit', 'call the']),
    ('scanner', ['scan', 'sensor', 'gauge', 'readout', 'spectro', 'monitor the']),
    ('wrench', ['wrench', 'bolt', 'valve', 'crank', 'tighten']),
    ('torchlight', ['flashlight', 'lantern', 'lamp', 'light beam', 'torch']),
    ('log', ['logbook', 'log entry', 'write in', 'clipboard', 'checklist']),
    ('probe', ['probe', 'borescope', 'multitool', 'filter']),
]
LOC_DOM = {'cave': 'SEA', 'rig': 'SEA', 'lighthouse': 'SEA', 'sonar': 'SEA', 'deck': 'SEA',
           'habitat': 'SEA', 'ice': 'SEA', 'seabed': 'SEA',
           'moon': 'SPACE', 'eva': 'SPACE', 'gantry': 'SPACE'}   # lainnya netral (stasiun)

_SAY = ['said', 'asked', 'replied', 'shouted', 'whispered', 'answered', 'warned', 'told me']
_ACT = ['walk', 'run', 'crawl', 'climb', 'swim', 'float', 'carry', 'pull', 'turn', 'press',
        'open', 'seal', 'watch', 'stare', 'reach', 'lean', 'kneel', 'step', 'drift', 'descend']
_PERSON = [r'\bpartner\b', r'\bcaptain\b', r'\bcrew\b', r'\bforeman\b', r'\bpilot\b',
           r'\bkeeper\b', r'\bvoice\b', r'\bcoworker\b', r'\bhe\b', r'\bshe\b',
           r'\bthey\b', r'\boperator\b', r'\bengineer\b', r'\brelief\b', r'\bmy\s+tech\b']

def parse_world(low, dom=None):
    if not low:
        return None
    low = ' ' + low.strip().lower() + ' '
    wd = {'loc': None, 'tool': None, 'loco': 'walk', 'host': False, 'npc': None,
          'convo': None, 'hud': None, 'creature': False, 'bubble': False}
    for loc, kws in _LOC:
        if LOC_DOM.get(loc) and dom and LOC_DOM[loc] != dom:
            continue                                # episode SEA tak boleh dapat set SPACE, dst
        if any(k in low for k in kws):
            wd['loc'] = loc
            break
    for tool, kws in _TOOL:
        if any(k in low for k in kws):
            wd['tool'] = tool
            break
    if wd['loc'] in ('seabed', 'cave'):
        wd['loco'] = 'swim'
    elif wd['loc'] == 'rov':
        wd['loco'] = 'rov'
    elif wd['loc'] == 'eva':
        wd['loco'] = 'eva'
    if wd['loc'] in ('eva', 'rov', 'duct'):
        wd['hud'] = 'O2' if wd['loc'] != 'rov' else 'DEPTH'
    for v in _SAY:
        if v in low:
            q = re.search(r'["\u201c]([^"\u201d]{3,80})["\u201d]', low)
            who = 'B'
            pre = low.split(v)[0]
            if re.search(r'\bi\b', pre[-24:]) and not any(re.search(q2, pre) for q2 in (r'\bhe\b', r'\bshe\b', r'\bthey\b')):
                who = 'A'
            role = 'PARTNER'
            for p in ('captain', 'keeper', 'foreman', 'pilot', 'crew', 'voice', 'operator'):
                if p in low:
                    role = p.upper()
                    break
            wd['convo'] = {'who': who, 'quote': q.group(1) if q else None, 'role': role}
            wd['npc'] = role
            wd['bubble'] = True
            wd['band'] = True
            break
    if not wd['convo'] and any(re.search(p, low) for p in _PERSON):
        wd['npc'] = 'WORKER'
    if wd['loc'] is None and wd['tool'] is None and not any(a in low for a in _ACT):
        wd['host'] = True
        wd['bubble'] = True
    if any(s in low for s in ('shadow', 'silhouette', 'something out there', 'behind', 'creature')):
        wd['creature'] = True
    has_action = wd['tool'] or any(a in low for a in _ACT)
    if wd['loc'] is None:
        last = (_ST.get('last') or {}).get(dom)
        if last and (has_action or wd['host']):
            wd['loc'] = last                         # lanjut di set yang sama (per-domain)
        elif not wd['host']:
            return None                              # fallback mesin klasik hstage
        else:
            wd['loc'] = 'control'
    _ST.setdefault('last', {})[dom] = wd['loc']
    return wd

# ================= LINGKUNGAN (19 lokasi + living props) =================
def _env_corridor(im, d, t, pal, rng):
    _grad(d, CW, CH, (22, 27, 40), (12, 15, 24))
    for x in range(0, CW, 190):                       # rangka bulkhead
        d.rectangle([x, 80, x + 16, CH], fill=(30, 36, 52), outline=(52, 60, 80))
    for i, x in enumerate(range(90, CW, 190)):        # lampu berdenyut pelan
        on = _blink_on(t, 1.4, 0.55, i * 0.13)
        d.rectangle([x, 96, x + 44, 104], fill=(96, 108, 136) if on else (48, 54, 70))
    d.line([(0, GROUND + 18), (CW, GROUND + 18)], fill=(50, 58, 78), width=3)
    sw = math.sin(t * 0.7) * 8                        # kabel gantung berayun
    d.line([(700, 84), (700 + sw, 200)], fill=(60, 68, 88), width=2)
    d.ellipse([694 + sw, 196, 710 + sw, 212], fill=(80, 90, 112))

def _env_seabed(im, d, t, pal, rng):
    _grad(d, CW, CH, (10, 34, 48), (6, 16, 26))
    for i in range(3):                                # berkas cahaya berayun
        x0 = 150 + i * 340
        sw = math.sin(t * 0.3 + i) * 14
        d.polygon([(x0, 0), (x0 + 70, 0), (x0 + 190 + sw, CH), (x0 + 40 + sw, CH)], fill=(16, 40, 54))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(12, 22, 32))
    for x in range(0, CW, 90):                        # punggung pasir
        d.arc([x, int(GROUND - 6), x + 90, int(GROUND + 22)], 200, 340, fill=(30, 48, 60), width=2)
    d.rectangle([70, 360, 108, int(GROUND + 8)], fill=(40, 54, 68), outline=(70, 88, 104), width=2)
    d.ellipse([64, 330, 114, 368], fill=(52, 68, 84), outline=(86, 104, 120))   # hidrofon
    for k in range(4):                                # kelp berayun
        kx = 880 + (k % 2) * 46
        sw = math.sin(t * 0.8 + k) * 10
        d.line([(kx, GROUND + 6), (kx + sw, GROUND - 70 - k * 12)], fill=(26, 58, 60), width=4)
    d.rectangle([640, int(GROUND - 26), 1120, int(GROUND + 2)], fill=(48, 62, 76), outline=(78, 94, 110), width=2)
    for fx0 in (700, 880, 1060):
        d.rectangle([fx0 - 6, int(GROUND - 34), fx0 + 6, int(GROUND + 10)], fill=(60, 76, 92))
    _fall(d, t, 11, 36, CW, CH, 9, 2, (150, 180, 200), 2)                       # marine snow

def _env_cave(im, d, t, pal, rng):
    _grad(d, CW, CH, (6, 12, 18), (2, 4, 8))
    for i in range(5):                                # dinding karang membulat
        x = i * 260
        d.ellipse([x - 90, -190 - (i % 3) * 40, x + 190, 150 + (i % 3) * 46], fill=(13, 20, 28))
        d.ellipse([x - 70, CH - 120 + (i % 2) * 40, x + 210, CH + 190], fill=(11, 17, 25))
        d.arc([x + 30, 60, x + 170, 240], 200, 340, fill=(24, 34, 44), width=3)
    for k in range(5):                                # ukiran berpendar samar
        gx, gy = 700 + (k % 3) * 40, 300 + (k // 3) * 46
        a = int(30 + 22 * math.sin(t * 0.5 + k))
        d.arc([gx, gy, gx + 26, gy + 26], 30, 300, fill=(90 + a, 150 + a, 160 + a), width=2)
    for k in range(14):                               # partikel tersedot ke dalam gua
        px = (CW - (int(t * 40) + k * 90) % CW)
        py = 120 + (k * 67) % 380
        d.point((px, py), fill=(120, 150, 170))

def _env_rig(im, d, t, pal, rng):
    _grad(d, CW, CH, (26, 30, 38), (14, 16, 22))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(34, 32, 30))
    for x in range(0, CW, 130):                       # pelat dek berkarat
        d.rectangle([x + 6, int(GROUND + 8), x + 124, CH], outline=(58, 52, 44))
    d.polygon([(150, 90), (210, 90), (230, GROUND), (130, GROUND)], fill=(40, 38, 36), outline=(70, 62, 52))
    sw = math.sin(t * 0.6) * 6                        # derek berderit berayun
    d.line([(230, 90), (430 + sw, 140)], fill=(70, 62, 52), width=3)
    d.line([(430 + sw, 140), (430 + sw, 260)], fill=(90, 82, 68), width=2)
    d.rectangle([760, 380, 900, GROUND + 8], fill=(48, 42, 36), outline=(80, 70, 56))
    if _blink_on(t, 1.1, 0.2):                        # lampu tiang kedip
        d.ellipse([208, 70, 224, 86], fill=(255, 190, 90))
    d.rectangle([196, 60, 236, 70], fill=(60, 54, 46))

def _env_lighthouse(im, d, t, pal, rng):
    _grad(d, CW, CH, (24, 28, 40), (12, 14, 22))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(40, 38, 34))
    cx, cy = 260, 300                                 # lensa Fresnel
    for r in range(34, 110, 16):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(120, 130, 150), width=2)
    ang = (t * 0.5) % (math.pi * 2)                   # beam menyapu berputar
    bx = math.cos(ang) * 900
    by = math.sin(ang) * 260
    d.polygon([(cx, cy), (cx + bx, cy + by - 60), (cx + bx, cy + by + 60)], fill=(70, 66, 40))
    d.rectangle([640, 380, 900, GROUND + 8], fill=(36, 34, 30), outline=(70, 64, 54))
    d.rectangle([680, 340, 780, 380], fill=(22, 24, 32), outline=(60, 64, 76))   # radio
    if _blink_on(t, 1.3, 0.3):
        d.ellipse([700, 352, 712, 364], fill=(255, 120, 80))
    d.line([(860, 340), (860, 300)], fill=(90, 90, 96), width=2)

def _env_sonar(im, d, t, pal, rng):
    _grad(d, CW, CH, (14, 20, 30), (8, 10, 16))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(20, 24, 32))
    d.rectangle([560, 350, 1060, GROUND + 8], fill=(28, 34, 46), outline=(58, 68, 88))
    for k in range(3):                                # layar konsol
        sx = 600 + k * 150
        d.rectangle([sx, 260, sx + 120, 348], fill=(8, 14, 20), outline=(70, 84, 104), width=2)
        for xx in range(0, 112, 8):                   # waveform berosilasi
            yy = int(14 * math.sin(t * (1.6 + k * 0.7) + xx * 0.25))
            d.line([(sx + 4 + xx, 304 + yy), (sx + 12 + xx, 304 - yy)], fill=(90, 200, 170), width=1)
        if _blink_on(t, 1.0, 0.25, k * 0.3):
            d.rectangle([sx + 104, 334, sx + 112, 342], fill=(255, 170, 80))
    sw = math.sin(t * 0.5) * 10                       # kabel atas berayun
    d.line([(200, 60), (200 + sw, 210)], fill=(50, 58, 74), width=2)
    r = int((t * 30) % 70)                            # ping sonar melingkar
    d.arc([800 - r, 120 - r, 800 + r, 120 + r], 0, 360, fill=(90, 170, 190), width=1)

def _env_lab(im, d, t, pal, rng):
    _grad(d, CW, CH, (30, 34, 42), (16, 18, 24))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(38, 40, 46))
    d.rectangle([560, 400, 1080, 420], fill=(70, 76, 88), outline=(100, 106, 118))
    d.line([(590, 420), (590, GROUND + 8)], fill=(60, 66, 78), width=4)
    d.line([(1050, 420), (1050, GROUND + 8)], fill=(60, 66, 78), width=4)
    for k in range(3):                                # toples spesimen
        jx = 620 + k * 90
        d.rectangle([jx, 330, jx + 52, 400], fill=(40, 60, 66), outline=(110, 140, 150))
        d.ellipse([jx + 14, 350, jx + 38, 384], fill=(70, 96, 96))
    d.line([(880, 330), (880, 400)], fill=(150, 156, 168), width=3)            # lampu meja
    d.ellipse([866, 316, 894, 332], fill=(220, 210, 160) if _blink_on(t, 2.4, 0.85) else (90, 86, 70))
    dy = (t * 26) % 70                                # tetesan cairan
    d.point((760, int(400 + dy)), fill=(140, 180, 190))

def _env_cryo(im, d, t, pal, rng):
    _grad(d, CW, CH, (16, 22, 34), (8, 10, 18))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(24, 28, 38))
    for k in range(4):                                # barisan pod
        px = 90 + k * 150
        d.rounded_rectangle([px, 260, px + 110, GROUND + 4], 26, fill=(34, 42, 58), outline=(80, 96, 120), width=2)
        d.rounded_rectangle([px + 18, 300, px + 92, 420], 16, fill=(16, 24, 36), outline=(60, 74, 96))
        fo = int(10 * math.sin(t * 0.4 + k))          # kabut meluber pelan
        d.ellipse([px + 8, 412 + fo, px + 104, 448 + fo], fill=(60, 72, 92))
        if _blink_on(t, 1.5, 0.2, k * 0.22):
            d.rectangle([px + 44, 270, px + 56, 280], fill=(120, 220, 170))
    d.rectangle([760, 300, 900, 380], fill=(10, 14, 22), outline=(60, 72, 92))  # EKG
    pts = []
    for xx in range(0, 130, 6):                       # garis EKG
        yy = 340 - (26 if int((t * 3 + xx / 22)) % 6 == 0 else 0)
        pts.append((766 + xx, yy))
    d.line(pts, fill=(110, 230, 170), width=2)

def _env_decon(im, d, t, pal, rng):
    _grad(d, CW, CH, (22, 26, 36), (12, 14, 20))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(26, 30, 40))
    d.rectangle([560, 140, 600, GROUND + 8], fill=(44, 50, 64), outline=(76, 84, 102))
    d.rectangle([860, 140, 900, GROUND + 8], fill=(44, 50, 64), outline=(76, 84, 102))
    for k in range(4):                                # kabut semprot melayang
        my = 230 + k * 68
        mx = int(((t * 22 + k * 60) % 160) - 80)
        d.ellipse([660 + mx, my, 790 + mx, my + 16], fill=(58, 70, 88))
        d.ellipse([700 - mx, my + 8, 800 - mx, my + 20], fill=(50, 62, 80))
    ang = (t * 0.8) % (math.pi * 2)                   # lampu peringatan berputar
    d.ellipse([180, 180, 216, 216], fill=(60, 30, 26))
    d.polygon([(198, 198), (198 + math.cos(ang) * 90, 198 + math.sin(ang) * 40),
               (198 + math.cos(ang + 0.3) * 90, 198 + math.sin(ang + 0.3) * 40)], fill=(150, 70, 50))

def _env_moon(im, d, t, pal, rng):
    _grad(d, CW, CH, (6, 8, 14), (2, 3, 6))
    _stars(d, rng)
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(36, 34, 34))
    for x in range(0, CW, 140):
        d.arc([x, int(GROUND - 4), x + 140, int(GROUND + 26)], 200, 340, fill=(54, 52, 50), width=2)
    d.polygon([(700, 0), (760, 0), (980, GROUND), (620, GROUND)], fill=(30, 30, 26))  # cone floodlight
    d.ellipse([820, 430, 960, 500], fill=(4, 5, 8), outline=(60, 58, 56))       # lubang galian
    a = int(24 + 16 * math.sin(t * 0.6))
    d.ellipse([846, 446, 934, 486], fill=(20 + a, 18 + a, 26 + a))              # glow dasar lubang
    d.line([(150, GROUND), (150, 300)], fill=(70, 70, 72), width=3)             # tripod bor
    d.line([(110, 320), (190, 320)], fill=(70, 70, 72), width=3)
    _fall(d, t, 5, 20, CW, CH, 5, 8, (120, 118, 116), 2)                        # debu drift

def _env_eva(im, d, t, pal, rng):
    _grad(d, CW, CH, (3, 4, 10), (1, 2, 5))
    _stars(d, rng, 110)
    d.arc([-300, CH - 240, CW + 300, CH + 560], 200, 340, fill=(52, 60, 84), width=26)  # lengkung planet
    sx = int(CW - 120 - (t * 2) % 40)                   # kapal induk mengecil
    d.polygon([(sx, 120), (sx + 60, 128), (sx + 60, 140), (sx, 148)], fill=(70, 76, 92))
    if _blink_on(t, 1.2, 0.18):
        d.point((sx + 64, 134), fill=(255, 120, 90))
    d.line([(0, int(GROUND + 8)), (CW, int(GROUND + 8))], fill=(30, 34, 46), width=2)
    for x in range(0, CW, 120):                         # dek magnetik
        d.rectangle([x, int(GROUND + 8), x + 8, CH], fill=(26, 30, 42))

def _env_rov(im, d, t, pal, rng):
    _grad(d, CW, CH, (8, 26, 38), (4, 12, 20))
    _fall(d, t, 21, 40, CW, CH, -26, 0, (150, 180, 200), 2)                     # salju naik (turun)
    d.rectangle([0, int(GROUND + 40), CW, CH], fill=(10, 18, 28))
    for x in range(0, CW, 110):
        d.arc([x, int(GROUND + 34), x + 110, int(GROUND + 60)], 200, 340, fill=(26, 42, 54), width=2)

def _env_duct(im, d, t, pal, rng):
    _grad(d, CW, CH, (24, 26, 32), (10, 12, 16))
    for x in range(80, CW, 200):                      # rangka terowongan
        d.line([(x, GROUND + 10), (x, 180)], fill=(48, 52, 62), width=8)
        d.arc([x - 90, 90, x + 90, 420], 180, 360, fill=(48, 52, 62), width=8)
        d.line([(x, 180), (x + 40, 150)], fill=(40, 44, 54), width=4)
    cx, cy = 930, 400                                 # vent kipas di dinding, tinggi badan
    d.rectangle([cx - 78, cy - 78, cx + 78, cy + 78], outline=(58, 64, 76), width=4)
    d.ellipse([cx - 64, cy - 64, cx + 64, cy + 64], outline=(70, 76, 88), width=4)
    for k in range(3):
        a = t * 1.1 + k * 2.094
        d.line([(cx, cy), (cx + math.cos(a) * 54, cy + math.sin(a) * 54)], fill=(84, 90, 104), width=6)
    d.ellipse([cx - 6, cy - 6, cx + 6, cy + 6], fill=(100, 106, 120))
    d.line([(cx - 64, cy), (cx + 64, cy)], fill=(58, 64, 76), width=2)   # gril vent
    d.line([(cx, cy - 64), (cx, cy + 64)], fill=(58, 64, 76), width=2)
    _fall(d, t, 9, 26, CW, CH, 4, 14, (150, 150, 160), 2)                       # debu

def _env_control(im, d, t, pal, rng):
    _grad(d, CW, CH, (18, 22, 34), (10, 12, 20))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(22, 26, 36))
    wx0, wy0, wx1, wy1 = 560, 120, 1040, 360          # viewport besar
    win = Image.new('RGB', (wx1 - wx0, wy1 - wy0), (3, 5, 10))
    wd2 = ImageDraw.Draw(win)
    r2 = random.Random(7)
    for _ in range(50):
        wd2.point((r2.randrange(win.width - 4), r2.randrange(win.height - 4)), fill=(200, 206, 220))
    im.paste(win, (wx0, wy0))
    d.rectangle([wx0, wy0, wx1, wy1], outline=(56, 66, 88), width=5)
    d.rectangle([540, 400, 1080, GROUND + 8], fill=(30, 36, 50), outline=(60, 70, 92))
    for k in range(5):                                # lampu konsol kedip
        if _blink_on(t, 0.9 + k * 0.17, 0.3, k * 0.19):
            d.rectangle([580 + k * 96, 420, 596 + k * 96, 434], fill=pal[2] if k % 2 else (255, 180, 90))
    for k in range(3):
        yy = int(6 * math.sin(t * 2.2 + k))
        d.line([(600 + k * 150, 470 + yy), (680 + k * 150, 470 - yy)], fill=(90, 190, 170), width=1)

def _env_deck(im, d, t, pal, rng):
    _grad(d, CW, CH, (10, 14, 22), (5, 7, 12))
    sea = int(GROUND - 60)
    d.rectangle([0, sea, CW, int(GROUND + 8)], fill=(8, 16, 26))
    for k in range(6):                                # gelombang bergerak
        wx = (int(t * 26) + k * 210) % (CW + 200) - 100
        d.arc([wx, sea - 6, wx + 160, sea + 12], 200, 340, fill=(28, 44, 60), width=2)
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(30, 32, 38))
    for x in range(40, CW, 90):                       # pagar
        d.line([(x, GROUND + 8), (x, GROUND - 44)], fill=(52, 56, 66), width=2)
    d.line([(40, GROUND - 44), (CW, GROUND - 44)], fill=(52, 56, 66), width=2)
    d.line([(980, GROUND + 8), (980, 160)], fill=(60, 64, 74), width=4)        # tiang
    if _blink_on(t, 1.6, 0.2):
        d.ellipse([972, 146, 990, 164], fill=(240, 200, 110))

def _env_habitat(im, d, t, pal, rng):
    _grad(d, CW, CH, (24, 28, 38), (12, 14, 20))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(28, 32, 42))
    for x in range(60, CW, 220):                      # rangka lengkung habitat
        d.arc([x - 90, 70, x + 170, CH + 140], 220, 320, fill=(46, 52, 66), width=6)
    d.ellipse([120, 240, 300, 420], outline=(70, 84, 104), width=6)             # porthole
    d.ellipse([136, 256, 284, 404], fill=(10, 20, 30))
    d.rectangle([700, 420, 950, GROUND + 8], fill=(36, 40, 52), outline=(64, 72, 88))
    d.rectangle([730, 360, 810, 420], fill=(14, 18, 26), outline=(60, 70, 88))  # monitor
    yy = int(5 * math.sin(t * 1.8))                   # grafik umbilical
    d.line([(738, 390 + yy), (802, 388 - yy)], fill=(110, 200, 160), width=1)
    sw = math.sin(t * 2.4) * 2                        # uap mug
    d.rectangle([880, 400, 902, 420], fill=(90, 96, 108))
    d.line([(888 + sw, 398), (892, 380)], fill=(130, 136, 150), width=2)

def _env_gantry(im, d, t, pal, rng):
    _grad(d, CW, CH, (4, 6, 12), (1, 2, 5))
    _stars(d, rng, 90)
    for x in range(0, CW, 240):                       # rangka truss
        d.line([(x, 100), (x + 120, CH)], fill=(44, 50, 64), width=3)
        d.line([(x + 120, 100), (x, CH)], fill=(44, 50, 64), width=3)
    d.line([(0, 100), (CW, 100)], fill=(54, 60, 76), width=4)
    d.line([(0, int(GROUND + 8)), (CW, int(GROUND + 8))], fill=(40, 46, 60), width=3)
    cx, cy = 860, 250                                 # dish memutar pelan
    a = t * 0.25
    d.ellipse([cx - 70, cy - 46, cx + 70, cy + 46], outline=(110, 118, 138), width=4)
    d.line([(cx, cy), (cx + math.cos(a) * 66, cy + math.sin(a) * 30)], fill=(130, 138, 158), width=3)
    if _blink_on(t, 1.3, 0.2):                        # beacon kedip
        d.ellipse([150, 84, 166, 100], fill=(255, 110, 90))

def _env_fuel(im, d, t, pal, rng):
    _grad(d, CW, CH, (20, 24, 32), (10, 12, 18))
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(24, 26, 32))
    for k in range(2):                                # tangki
        tx = 640 + k * 220
        d.rounded_rectangle([tx, 220, tx + 160, GROUND + 8], 30, fill=(44, 48, 58), outline=(78, 84, 98), width=3)
    vy = int(20 + 14 * math.sin(t * 0.5))             # dial meter naik-turun
    d.ellipse([180, 300, 260, 380], fill=(16, 20, 28), outline=(80, 88, 104), width=3)
    d.line([(220, 340), (220 + math.cos(vy) * 30, 340 + math.sin(vy) * 30)], fill=(230, 190, 100), width=2)
    for k in range(5):                                # kabut uap
        fx = (int(t * 18) + k * 160) % CW
        d.ellipse([fx, GROUND - 16, fx + 120, GROUND + 8], fill=(46, 52, 62))

def _env_ice(im, d, t, pal, rng):
    _grad(d, CW, CH, (26, 34, 46), (12, 16, 24))
    _stars(d, rng, 40)
    d.rectangle([0, int(GROUND + 8), CW, CH], fill=(70, 82, 96))
    for x in range(0, CW, 160):
        d.line([(x, GROUND + 8), (x + 80, GROUND + 26)], fill=(90, 102, 116), width=2)
    d.polygon([(820, GROUND + 8), (840, 260), (900, 260), (920, GROUND + 8)], fill=(40, 46, 58), outline=(80, 90, 106))
    a = t * 1.4                                       # bor es pelan
    d.line([(870, 300), (870, 430)], fill=(110, 118, 130), width=4)
    d.line([(858, int(300 + (a % 1) * 30)), (882, int(308 + (a % 1) * 30))], fill=(140, 148, 160), width=2)
    _fall(d, t, 17, 30, CW, CH, 14, 20, (210, 220, 232), 2)                     # salju melayang
    if _blink_on(t, 0.9, 0.14):                       # lampu morse dari lubang
        d.ellipse([858, 470, 884, 486], fill=(150, 220, 250))

_ENVS = dict(corridor=_env_corridor, seabed=_env_seabed, cave=_env_cave, rig=_env_rig,
             lighthouse=_env_lighthouse, sonar=_env_sonar, lab=_env_lab, cryo=_env_cryo,
             decon=_env_decon, moon=_env_moon, eva=_env_eva, rov=_env_rov, duct=_env_duct,
             control=_env_control, deck=_env_deck, habitat=_env_habitat, gantry=_env_gantry,
             fuel=_env_fuel, ice=_env_ice)

# ================= FIGUR =================
def _blink_eyes(d, cx, cy, s, t, col=(20, 24, 34)):
    closed = ((t + 0.7) % 3.7) < 0.14
    if closed:
        d.line([(cx - s * 0.05, cy), (cx - s * 0.015, cy)], fill=col, width=2)
        d.line([(cx + s * 0.015, cy), (cx + s * 0.05, cy)], fill=col, width=2)
    else:
        d.ellipse([cx - s * 0.05, cy - 2, cx - s * 0.02, cy + 2], fill=col)
        d.ellipse([cx + s * 0.02, cy - 2, cx + s * 0.05, cy + 2], fill=col)

def fig_host(d, x, y, s, t, suit, accent, talk=1.0):
    """Narator hadap kamera: mulut sync + kedip + gestur tangan + napas."""
    br = math.sin(t * 1.4) * s * 0.008
    hip = (x, y - s * 0.42 + br)
    neck = (x, y - s * 0.86 + br)
    hc = (x, y - s * 1.0 + br)
    r = s * 0.115
    for lx, ph in ((-1, 0), (1, math.pi)):            # kaki + berat badan
        d.line([hip, (x + lx * s * 0.14, y)], fill=suit, width=5)
    d.line([hip, neck], fill=suit, width=6)
    d.line([(x, y - s * 0.84 + br), (x, y - s * 0.80 + br)], fill=accent, width=6)
    d.ellipse([hc[0] - r, hc[1] - r, hc[0] + r, hc[1] + r], fill=(226, 208, 190), outline=suit, width=3)
    _blink_eyes(d, hc[0], hc[1] - r * 0.15, s, t)
    if talk > 0:                                      # mulut sinkron bicara
        op = (abs(math.sin(t * 8.2)) + abs(math.sin(t * 12.7))) * 0.5 * talk
        d.ellipse([hc[0] - r * 0.28, hc[1] + r * 0.28, hc[0] + r * 0.28,
                   hc[1] + r * 0.28 + max(2.0, op * r * 0.6)], fill=(90, 50, 48))
    else:
        d.line([(hc[0] - r * 0.22, hc[1] + r * 0.42), (hc[0] + r * 0.22, hc[1] + r * 0.42)],
               fill=(90, 50, 48), width=2)
    g = int((t / 2.8) % 3)                            # siklus 3 gestur tangan
    k = _easeio(((t / 2.8) % 1.0) if ((t / 2.8) % 1.0) > 0.82 else 0)
    sh = (x, y - s * 0.78 + br)
    def arm(a1, a2):
        ex = sh[0] + math.cos(a1) * s * 0.22
        ey = sh[1] + math.sin(a1) * s * 0.16
        hx = ex + math.cos(a2) * s * 0.24
        hy = ey + math.sin(a2) * s * 0.2
        d.line([sh, (ex, ey)], fill=suit, width=5)
        d.line([(ex, ey), (hx, hy)], fill=suit, width=5)
        return (hx, hy)
    swy = math.sin(t * 2.2) * 0.12
    if g == 0:
        hr = arm(-0.5 - swy, 0.9 + swy); hl = arm(math.pi + 0.5 + swy, math.pi - 0.9 - swy)
    elif g == 1:
        hr = arm(-1.2, -0.4 + swy); hl = arm(math.pi + 0.4, math.pi - 1.0)
    else:
        hr = arm(-0.35, 1.35 + swy); hl = arm(math.pi + 0.35, math.pi - 1.35 - swy)
    return hr, hl, hc, r

def fig_walk(d, x, y, s, t, suit, accent, speed=7.0):
    """Siklus jalan: kaki bergantian, lengan antiphase, badan naik-turun halus."""
    bob = abs(math.sin(t * speed)) * s * 0.03
    hip = (x, y - s * 0.44 - bob)
    neck = (x + s * 0.03, y - s * 0.88 - bob)
    hc = (x + s * 0.04, y - s * 1.02 - bob)
    r = s * 0.11
    for lx, ph in ((1, 0), (-1, math.pi)):
        a = math.sin(t * speed + ph) * 0.5
        kx = hip[0] + math.sin(a) * s * 0.16
        ky = hip[1] + s * 0.22
        fx = kx + math.sin(a + 0.5) * s * 0.2 * lx * lx
        d.line([hip, (kx, ky)], fill=suit, width=5)
        d.line([(kx, ky), (hip[0] + math.sin(a) * s * 0.34, y - max(0.0, math.sin(t * speed + ph)) * s * 0.1)], fill=suit, width=5)
    d.line([hip, neck], fill=suit, width=6)
    d.ellipse([hc[0] - r, hc[1] - r, hc[0] + r, hc[1] + r], fill=(226, 208, 190), outline=suit, width=3)
    d.ellipse([hc[0] + r * 0.1, hc[1] - r * 0.2, hc[0] + r * 0.45, hc[1] + r * 0.1], fill=(20, 24, 34))
    a2 = math.sin(t * speed + math.pi) * 0.45
    sh = (x, y - s * 0.8 - bob)
    d.line([sh, (sh[0] + math.sin(a2) * s * 0.2, sh[1] + s * 0.22)], fill=suit, width=5)
    return hc, r

def fig_side(d, x, y, s, t, suit, accent, work=0.0):
    """Figur samping utk kerja dg alat; mengembalikan posisi tangan kanan."""
    br = math.sin(t * 1.3) * s * 0.006
    hip = (x, y - s * 0.42 + br)
    neck = (x + s * 0.04, y - s * 0.86 + br)
    hc = (x + s * 0.05, y - s * 1.0 + br)
    r = s * 0.11
    d.line([hip, (x - s * 0.12, y)], fill=suit, width=5)
    d.line([hip, (x + s * 0.14, y)], fill=suit, width=5)
    d.line([hip, neck], fill=suit, width=6)
    d.ellipse([hc[0] - r, hc[1] - r, hc[0] + r, hc[1] + r], fill=(226, 208, 190), outline=suit, width=3)
    if ((t + 1.9) % 4.1) < 0.14:
        d.line([(hc[0] + r * 0.1, hc[1] - r * 0.15), (hc[0] + r * 0.5, hc[1] - r * 0.15)], fill=(20, 24, 34), width=2)
    else:
        d.ellipse([hc[0] + r * 0.12, hc[1] - r * 0.24, hc[0] + r * 0.5, hc[1] - r * 0.02], fill=(20, 24, 34))
    sh = (x + s * 0.02, y - s * 0.78 + br)
    wa = math.sin(t * (2.0 + work * 6.0)) * (0.08 + work * 0.3)
    ex = sh[0] + s * 0.2
    ey = sh[1] + s * 0.1 + wa * s * 0.2
    hx = ex + s * 0.22
    hy = ey + s * 0.06 + wa * s * 0.3
    d.line([sh, (ex, ey)], fill=suit, width=5)
    d.line([(ex, ey), (hx, hy)], fill=suit, width=5)
    d.line([sh, (sh[0] + s * 0.1, sh[1] + s * 0.24)], fill=suit, width=5)
    return (hx, hy), hc, r

def fig_swim(d, x, y, s, t, suit, accent):
    """Renang horizontal: badan miring, kaki fin, gelembung."""
    bob = math.sin(t * 1.6) * 6
    cx, cy = x, y + bob
    d.line([(cx - s * 0.5, cy), (cx + s * 0.28, cy - s * 0.06)], fill=suit, width=7)
    hc = (cx + s * 0.4, cy - s * 0.1)
    r = s * 0.1
    d.ellipse([hc[0] - r, hc[1] - r, hc[0] + r, hc[1] + r], fill=(226, 208, 190), outline=suit, width=3)
    for k, ph in ((0, 0), (1, math.pi)):
        a = math.sin(t * 3.2 + ph) * 0.35
        kx = cx - s * 0.5 - math.cos(a) * s * 0.24
        ky = cy + math.sin(a) * s * 0.2
        d.line([(cx - s * 0.5, cy), (kx, ky)], fill=suit, width=5)
        d.polygon([(kx, ky), (kx - s * 0.16, ky - s * 0.06), (kx - s * 0.16, ky + s * 0.08)], fill=accent)
    aa = math.sin(t * 2.6) * 0.3
    d.line([(cx, cy - s * 0.02), (cx + s * 0.2, cy - s * 0.2 + aa * s * 0.2)], fill=suit, width=5)
    for k in range(4):
        bx = hc[0] + r + (int(t * 26) + k * 22) % 90
        by = hc[1] - ((int(t * 30) + k * 26) % 70)
        d.ellipse([bx, by, bx + 5, by + 5], outline=(170, 210, 230))
    return hc, r

# ================= ALAT DI TANGAN =================
def tool_weld(d, hx, hy, t, s, pal, im):
    d.line([(hx, hy), (hx + s * 0.2, hy + s * 0.08)], fill=(150, 158, 172), width=4)
    d.line([(hx + s * 0.2, hy + s * 0.08), (hx + s * 0.26, hy + s * 0.11)], fill=(90, 98, 112), width=5)
    tx, ty = hx + s * 0.28, hy + s * 0.12
    arc = 0.5 + 0.5 * math.sin(t * 9.0) * math.sin(t * 13.7 + 1.3)   # kedip lembut acak
    if arc > 0.15:
        for rr, al in ((11, 40), (6, 90), (3, 150)):
            d.ellipse([tx - rr, ty - rr, tx + rr, ty + rr], fill=(255, 240, 200, int(al * arc)))
        d.ellipse([tx - 2, ty - 2, tx + 2, ty + 2], fill=(170, 210, 255, int(160 * arc)))
        for k in range(7):                              # percikan jatuh
            p = (t * 1.7 + k * 0.14) % 1.0
            d.point((int(tx + math.sin(k * 2.4) * 26 * p), int(ty + p * p * 90)),
                    fill=(255, 190 + k * 8, 90))
    return tx, ty

def tool_pick(d, hx, hy, t, s, pal, im):
    p = (t % 1.7) / 1.7                                 # siklus angkat-ayun-hantam
    if p < 0.5:
        a = -0.9 + _easeio(p / 0.5) * 0.5               # angkat
        hit = False
    elif p < 0.62:
        a = -0.4 + (p - 0.5) / 0.12 * 1.5               # ayun cepat
        hit = p > 0.6
    else:
        a = 1.1 - _easeio((p - 0.62) / 0.38) * 0.4
        hit = False
    L = s * 0.55
    ex = hx + math.cos(a) * L
    ey = hy + math.sin(a) * L
    d.line([(hx, hy), (ex, ey)], fill=(178, 148, 102), width=4)
    pa = a + math.pi / 2
    d.line([(ex - math.cos(pa) * 16, ey - math.sin(pa) * 16),
            (ex + math.cos(pa) * 16, ey + math.sin(pa) * 16)], fill=(200, 208, 222), width=5)
    if hit:                                             # serpihan + debu saat benturan
        seed = int(t // 1.7)
        for k in range(8):
            p2 = (t % 1.7 - 0.6) / 0.4
            if p2 < 0 or p2 > 0.5:
                continue
            d.point((int(ex + math.sin(seed + k * 3) * 40 * p2), int(ey - 30 * p2 + 60 * p2 * p2)),
                    fill=(150, 140, 120))
    return ex, ey

def tool_camera(d, hx, hy, t, s, pal, im):
    sw = math.sin(t * 0.8) * s * 0.05                   # pan pelan
    bx, by = hx + s * 0.1 + sw, hy - s * 0.06
    d.rectangle([bx - s * 0.14, by - s * 0.1, bx + s * 0.16, by + s * 0.12], fill=(40, 46, 58), outline=(96, 106, 124), width=2)
    d.ellipse([bx + s * 0.08, by - s * 0.05, bx + s * 0.2, by + s * 0.07], fill=(20, 26, 38), outline=(130, 140, 158))
    if _blink_on(t, 1.0, 0.5):
        d.rectangle([bx - s * 0.12, by - s * 0.14, bx - s * 0.06, by - s * 0.1], fill=(255, 90, 80))
    return bx, by

def tool_drill(d, hx, hy, t, s, pal, im):
    d.rectangle([hx - 6, hy - 10, hx + 26, hy + 12], fill=(60, 66, 80), outline=(100, 108, 124))
    ex, ey = hx + 26, hy
    d.line([(ex, ey), (ex + s * 0.3, ey)], fill=(140, 148, 162), width=4)
    for k in range(3):                                  # mata bor berputar
        ph = (t * 6 + k) % 1.0
        d.line([(ex + ph * s * 0.3, ey - 3), (ex + ph * s * 0.3 + 4, ey + 3)], fill=(190, 198, 212), width=1)
    for k in range(5):
        p = (t * 2 + k * 0.2) % 1.0
        d.point((int(ex + s * 0.3 + 8 + p * 26), int(ey + math.sin(k * 5) * 14 * p + 10 * p)), fill=(160, 160, 170))
    return ex + s * 0.3, ey

def tool_generic(d, hx, hy, t, s, pal, kind):
    if kind == 'wrench':
        a = math.sin(t * 1.8) * 0.3
        d.line([(hx, hy), (hx + math.cos(a) * s * 0.24, hy + math.sin(a) * s * 0.24)], fill=(150, 158, 172), width=5)
        d.ellipse([hx + math.cos(a) * s * 0.24 - 5, hy + math.sin(a) * s * 0.24 - 5,
                   hx + math.cos(a) * s * 0.24 + 5, hy + math.sin(a) * s * 0.24 + 5], outline=(170, 178, 192), width=2)
    elif kind == 'scanner':
        d.line([(hx, hy), (hx + s * 0.2, hy - s * 0.1)], fill=(120, 128, 142), width=4)
        r = int((t * 40) % 60)
        d.arc([hx + s * 0.2 - r, hy - s * 0.1 - r, hx + s * 0.2 + r, hy - s * 0.1 + r], -40, 60, fill=(110, 220, 190), width=2)
    elif kind == 'radio':
        d.rectangle([hx - 4, hy - 16, hx + 12, hy + 8], fill=(50, 56, 70), outline=(96, 104, 120))
        if _blink_on(t, 0.8, 0.3):
            d.rectangle([hx, hy - 12, hx + 8, hy - 6], fill=(120, 230, 160))
        d.line([(hx + 10, hy - 16), (hx + 14, hy - 30)], fill=(120, 128, 142), width=2)
    elif kind == 'torchlight':
        d.line([(hx, hy), (hx + s * 0.18, hy - s * 0.06)], fill=(70, 76, 90), width=6)
    elif kind == 'log':
        d.rectangle([hx - 4, hy - 20, hx + 22, hy + 6], fill=(214, 218, 224), outline=(110, 116, 128))
        px = int((t * 14) % 20)
        d.line([(hx, hy - 14), (hx + px, hy - 14)], fill=(80, 86, 100), width=2)
    elif kind == 'reel':
        d.ellipse([hx - 12, hy - 12, hx + 12, hy + 12], outline=(140, 148, 162), width=3)
        a = t * 2.2
        d.line([(hx, hy), (hx + math.cos(a) * 10, hy + math.sin(a) * 10)], fill=(160, 168, 182), width=2)
    elif kind == 'scalpel':
        d.line([(hx, hy), (hx + 18, hy + 6)], fill=(190, 198, 210), width=3)
    elif kind == 'joystick':
        d.rectangle([hx - 8, hy - 4, hx + 14, hy + 10], fill=(40, 46, 60), outline=(86, 94, 110))
        jx = math.sin(t * 1.7) * 3
        d.line([(hx + 3 + jx, hy - 4), (hx + 3 + jx, hy - 16)], fill=(130, 138, 152), width=3)
    elif kind == 'headset':
        d.arc([hx - 10, hy - 14, hx + 12, hy + 8], 180, 360, fill=(90, 98, 114), width=3)
    elif kind == 'probe':
        d.line([(hx, hy), (hx + 26, hy - 10)], fill=(140, 148, 162), width=3)
        d.ellipse([hx + 24, hy - 16, hx + 34, hy - 6], outline=(170, 180, 194), width=2)
    elif kind == 'weld':
        d.line([(hx, hy), (hx + s * 0.2, hy + s * 0.08)], fill=(150, 158, 172), width=3)
        arc = 0.5 + 0.5 * math.sin(t * 8.0 + 2.0) * math.sin(t * 12.3)
        if arc > 0.2:
            d.ellipse([hx + s * 0.2 - 5, hy + s * 0.08 - 5, hx + s * 0.2 + 5, hy + s * 0.08 + 5],
                      fill=(255, 236, 190, int(110 * arc)))
    return hx + s * 0.2, hy

def flash_camera(d, im, t):
    if (t % 3.6) < 0.10:
        ov = Image.new('RGBA', im.size, (225, 235, 248, 64))
        im.alpha_composite(ov)
        d2 = ImageDraw.Draw(im)
        r2 = random.Random(int(t // 3.6))
        for _ in range(36):
            d2.point((r2.randrange(CW), r2.randrange(CH)), fill=(200, 214, 228))
        return True
    return False

# ================= ROV / KENDARAAN =================
def draw_rov(im, d, t, pal):
    x = 560 + math.sin(t * 0.5) * 30
    y = 330 + math.sin(t * 0.9) * 12
    d.rounded_rectangle([x, y, x + 190, y + 84], 18, fill=(58, 66, 82), outline=(110, 120, 140), width=3)
    d.ellipse([x + 130, y + 18, x + 178, y + 66], fill=(20, 30, 44), outline=(120, 140, 160), width=3)
    d.line([(x + 40, y), (x + 40, y - 26)], fill=(90, 98, 116), width=3)
    d.ellipse([x + 34, y - 38, x + 46, y - 26], fill=(255, 190, 90) if _blink_on(t, 1.4, 0.25) else (90, 80, 60))
    for tx, ty in ((x - 8, y + 16), (x - 8, y + 50)):   # thruster: baling-baling putar
        d.ellipse([tx - 14, ty - 12, tx + 4, ty + 12], outline=(120, 130, 150), width=2)
        a = t * 9
        d.line([(tx - 10, ty - math.sin(a) * 9), (tx, ty + math.sin(a) * 9)], fill=(150, 160, 180), width=2)
        for k in range(3):
            bx = tx - 18 - ((int(t * 40) + k * 18) % 60)
            d.ellipse([bx, ty - 4 + k, bx + 5, ty + 1 + k], outline=(160, 200, 220))
    d.polygon([(x + 178, y + 30), (x + 560, y - 60), (x + 560, y + 140), (x + 178, y + 56)],
              fill=(36, 66, 80))                          # cone lampu
    return x, y

# ================= HUD =================
def draw_hud(d, kind, t, accent):
    f = _font(13)
    d.rectangle([CW - 190, 26, CW - 26, 74], fill=(6, 10, 16, 200), outline=(70, 80, 100))
    if kind == 'O2':
        lvl = max(0.08, 0.9 - (t % 40) * 0.02)
        d.text((CW - 180, 32), 'O2', font=f, fill=(180, 190, 206))
        d.rectangle([CW - 148, 34, CW - 40, 48], outline=(90, 100, 120))
        d.rectangle([CW - 146, 36, CW - 42 - int(102 * (1 - lvl)), 46],
                    fill=(120, 220, 160) if lvl > 0.3 else (255, 120, 90))
    else:
        depth = 1180 + int((t * 6) % 900)
        d.text((CW - 180, 32), 'DEPTH %d m' % depth, font=f, fill=(150, 210, 235))
        d.text((CW - 180, 50), 'DESCENT', font=f, fill=(110, 130, 150))

# ================= BUBBLE =================
def _wrap42(d, text, f, maxw, maxlines=2):
    words = text.split()
    lines, cur = [], ''
    for w in words:
        trial = (cur + ' ' + w).strip()
        if d.textlength(trial, font=f) <= maxw:
            cur = trial
        else:
            lines.append(cur)
            cur = w
        if len(lines) == maxlines and cur and d.textlength(cur + ' ...', font=f) > maxw:
            cur = cur + ' ...'
            break
    if cur:
        lines.append(cur)
    return lines[:maxlines]

def draw_bubble(d, text, ax, ay, maxw, tag=None, tagcol=(120, 220, 190), above=True):
    f = _font(22)
    lines = _wrap42(d, text, f, maxw - 36)
    lh = 28
    bw = min(maxw, int(max(d.textlength(l, font=f) for l in lines)) + 40)
    bh = len(lines) * lh + 22
    x0 = max(20, min(CW - bw - 20, ax - bw // 2))
    y0 = ay - bh - 16 if above else ay + 16
    d.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], 14, fill=(10, 14, 22, 235), outline=(96, 110, 138), width=2)
    if above:
        d.polygon([(ax - 9, y0 + bh - 1), (ax + 9, y0 + bh - 1), (ax, y0 + bh + 14)], fill=(10, 14, 22, 235))
    else:
        d.polygon([(ax - 9, y0 + 1), (ax + 9, y0 + 1), (ax, y0 - 14)], fill=(10, 14, 22, 235))
    if tag:
        tf = _font(14)
        d.text((x0 + 14, y0 - 20), tag, font=tf, fill=tagcol)
    for i, ln in enumerate(lines):
        d.text((x0 + 20, y0 + 12 + i * lh), ln, font=f, fill=(238, 242, 250))
    return (x0, y0, x0 + bw, y0 + bh)

# ================= STATE =================
_ST = {'loc': None}

def world_reset():
    _ST['loc'] = None
    _ST['last'] = {}

# ================= PERAKITAN FRAME DUNIA =================
def render_world(tn, dom, pal, sil, t, wd, seed, sub_t, text):
    rng = random.Random(seed + tn * 31)
    im = Image.new('RGBA', (CW, CH), (0, 0, 0, 255))
    d = ImageDraw.Draw(im)
    suit = (176, 184, 202) if dom == 'SPACE' else (168, 178, 148)
    suit_npc = (150, 160, 176) if dom == 'SPACE' else (146, 156, 122)
    accent = pal[2]
    _ENVS.get(wd['loc'], _env_corridor)(im, d, t, pal, rng)
    _brand(d)
    if wd['hud']:
        draw_hud(d, wd['hud'], t, accent)

    # ---- walk-in: masuk lokasi baru dengan kaki berjalan ----
    walking = False
    if wd['loc'] != _ST['loc']:
        k = min(1.0, sub_t / 1.4)
        if wd['loco'] == 'walk' and k < 1.0:
            walking = True
            xw = -70 + (MARK_X + 70) * _easeo(k)
        _ST['loc'] = wd['loc']
    xw = MARK_X if not walking else xw

    if wd['creature']:                                 # siluet jauh drift pelan
        cx = CW - 200 + math.sin(t * 0.2) * 30
        if wd['loco'] == 'swim' or wd['loc'] in ('seabed', 'cave'):
            for k in range(4):
                d.arc([cx + k * 14, 160, cx + 40 + k * 14, 300], 200, 340, fill=(8, 14, 20), width=7)
        else:
            d.polygon([(cx, 200), (cx + 90, 240), (cx + 70, 300), (cx - 10, 260)], fill=(10, 12, 20))

    if wd['loco'] == 'rov':
        draw_rov(im, d, t, pal)
        if wd['tool'] == 'camera':
            flash_camera(d, im, t)
        return im

    if wd['npc'] and wd['loco'] == 'swim':
        hp2 = fig_side(d, 810, GROUND, 118, t + 2.1, suit_npc, accent, 0.6)[0]
        tool_generic(d, hp2[0], hp2[1], t + 1.3, 118, pal, 'weld')

    if wd['loco'] == 'swim':
        hc, r = fig_swim(d, xw + 60, 360, 130, t, suit, accent)
        if wd['loc'] == 'cave':                       # guideline: patong anchor -> reel pinggang
            ax, ay = 152, 158
            d.line([(ax - 6, ay + 10), (ax + 6, ay + 10)], fill=(120, 130, 146), width=3)
            d.ellipse([ax - 3, ay - 4, ax + 3, ay + 4], fill=(150, 160, 176))
            wx0, wy0 = xw + 6, 366
            d.ellipse([wx0 - 6, wy0 - 6, wx0 + 6, wy0 + 6], outline=(200, 208, 220), width=2)
            mx, my = (ax + wx0) / 2, (ay + wy0) / 2 + 26 + math.sin(t * 0.9) * 3
            d.line([(ax, ay), (mx, my)], fill=(190, 200, 210), width=1)
            d.line([(mx, my), (wx0, wy0)], fill=(190, 200, 210), width=1)
        if wd['tool'] == 'camera':
            tool_camera(d, xw + 120, 350, t, 130, pal, im)
            flash_camera(d, im, t)
        elif wd['tool'] == 'torchlight':
            d.polygon([(xw + 150, 342), (xw + 430, 288), (xw + 430, 402)], fill=(24, 48, 60))
        if wd['convo'] and wd['convo'].get('quote'):
            q = wd['convo']['quote']
            role = wd['convo']['role']
            if wd['convo']['who'] == 'A':
                draw_bubble(d, q, int(hc[0]), int(hc[1] - r - 6), 460, tag='ME')
            else:
                hp2 = fig_side(d, 810, GROUND, 118, t + 2.1, suit_npc, accent, 0.4)[0]
                draw_bubble(d, q, 810, 250, 380, tag=role, tagcol=(255, 190, 110))
        elif wd['bubble']:
            draw_bubble(d, text, int(hc[0]), int(hc[1] - r - 6), 480, tag='ME')
        return im

    if wd['loco'] == 'eva':
        fl = math.sin(t * 0.7) * 10
        ax0, ay0 = 170, GROUND - 6                       # anchor klem di lambung
        d.rectangle([ax0 - 10, ay0 - 8, ax0 + 10, ay0 + 8], fill=(52, 58, 74), outline=(90, 98, 116), width=2)
        d.ellipse([ax0 - 5, ay0 - 14, ax0 + 5, ay0 - 4], outline=(130, 138, 156), width=2)
        hx0, hy0 = xw + 10, 330 + fl + 46                # pinggul narator
        sag = 60 + math.sin(t * 0.7) * 8                 # tali kendur (catenary) berayun
        px, py = ax0, ay0 - 10
        for k in range(1, 13):
            u = k / 12.0
            nx0 = ax0 + (hx0 - ax0) * u
            ny0 = (ay0 - 10) + (hy0 - (ay0 - 10)) * u + math.sin(math.pi * u) * sag
            d.line([(px, py), (nx0, ny0)], fill=(120, 128, 144), width=2)
            px, py = nx0, ny0
        d.ellipse([hx0 - 4, hy0 - 4, hx0 + 4, hy0 + 4], outline=(150, 158, 176), width=2)
        hc, r = fig_swim(d, xw + 40, 330 + fl, 130, t, suit, accent)             # drift
        if wd['tool'] == 'wrench':
            tool_generic(d, xw + 110, 330 + fl, t, 130, pal, 'wrench')
        if wd['convo'] and wd['convo'].get('quote'):
            q = wd['convo']['quote']
            if wd['convo']['who'] == 'A':
                draw_bubble(d, q, int(hc[0]), int(hc[1] - r - 6), 460, tag='ME')
            else:
                f2 = math.sin(t * 0.7 + 1.7) * 10
                fig_swim(d, 810, 330 + f2, 118, t + 2.1, suit_npc, accent)
                draw_bubble(d, q, 810, 250, 380, tag=wd['convo']['role'], tagcol=(255, 190, 110))
        elif wd['bubble']:
            draw_bubble(d, text, int(hc[0]), int(hc[1] - r - 6), 480, tag='ME')
        return im

    # ---- NPC dulu (belakang narator) ----
    if wd['npc']:
        nx = 780
        if wd['convo']:
            fig_side(d, nx, GROUND, 118, t + 2.1, suit_npc, accent, 0.0)
        else:
            hp2 = fig_side(d, nx, GROUND, 118, t + 2.1, suit_npc, accent, 0.5)[0]
            tool_generic(d, hp2[0], hp2[1], t + 1.3, 118, pal, wd['tool'] or 'wrench')

    # ---- narator ----
    if wd['host']:
        hr, hl, hc, r = fig_host(d, xw, GROUND, 132, t, suit, accent, 1.0)
        if wd['bubble'] and text:
            draw_bubble(d, text, int(hc[0]), int(hc[1] - r - 6), 500, tag='ME')
    elif walking:
        fig_walk(d, xw, GROUND, 130, t, suit, accent)
    else:
        hp, hc, r = fig_side(d, xw, GROUND, 130, t, suit, accent, 1.0 if wd['tool'] else 0.0)
        if wd['tool'] == 'weld':
            tx, ty = tool_weld(d, hp[0], hp[1], t, 130, pal, im)
        elif wd['tool'] == 'pick':
            tool_pick(d, hp[0], hp[1], t, 130, pal, im)
        elif wd['tool'] == 'camera':
            tool_camera(d, hp[0], hp[1], t, 130, pal, im)
            flash_camera(d, im, t)
        elif wd['tool'] == 'drill':
            tool_drill(d, hp[0], hp[1], t, 130, pal, im)
        elif wd['tool'] == 'torchlight':
            tool_generic(d, hp[0], hp[1], t, 130, pal, 'torchlight')
            d.polygon([(hp[0] + 18, hp[1] - 6), (hp[0] + 320, hp[1] - 62), (hp[0] + 320, hp[1] + 50)],
                      fill=(46, 52, 40) if dom == 'SPACE' else (22, 44, 54))
        elif wd['tool']:
            tool_generic(d, hp[0], hp[1], t, 130, pal, wd['tool'])

    # ---- percakapan: bubble kiri/kanan + tag nama ----
    if wd['convo'] and text:
        q = wd['convo']['quote']
        role = wd['convo']['role']
        if q and wd['convo']['who'] == 'A':
            draw_bubble(d, q, 380, 250, 430, tag='ME')
        elif q:
            draw_bubble(d, q, 800, 250, 380, tag=role, tagcol=(255, 190, 110))

    return im
