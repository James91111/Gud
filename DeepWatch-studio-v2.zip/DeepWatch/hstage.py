# -*- coding: utf-8 -*-
"""
hstage.py v3 — mesin film animasi stickman DEEP WATCH ("universe" adegan).
Rumus adegan: 48 arketipe x 24 varian = 1152 komposisi unik, jadi SETIAP
kalimat narasi (sampai film 12.000 kata / ~1000 kalimat) dapat adegan sendiri.

Rumus gerak ditanam dari riset:
  EASING      : ease-in-out sinus/kubik utk semua perpindahan (slow-in/slow-out).
  ANTICIPATION: windup kecil sebelum aksi besar (mundur dulu, lalu maju).
  FOLLOW-THRU : sisa gerak teredam e^(-3t)*sin setelah aksi selesai.
  SECONDARY   : napas, berat badan bergeser, mata berkedip, debu/plankton,
                jarum gauge jitter, lampu berdenyut — dunia terasa hidup.
  ARCS        : lintasan tangan/alat mengikuti busur, bukan garis kaku.
  SQUASH      : sedikit kompresi badan saat jongkok/mendarat (tetap kalem).
  SHOT GRAMMAR: wide -> medium -> close bergantian per kalimat (coverage film).
Bug gerak diperbaiki: crossfade antar adegan (tanpa cut kasar), monster muncul
perlahan (ease), kamera tidak snap (zoom ease-in), pekerja di-clamp zona aman,
pose bertransisi halus (blend dua pose saat ganti).
"""
import math, random
from PIL import Image, ImageDraw, ImageFont
import hworld

W, H = 960, 540
CW, CH = 1152, 648

def font(sz, bold=True):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
              '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        try:
            return ImageFont.truetype(p, sz)
        except Exception:
            pass
    return ImageFont.load_default()

# ================= RUMUS EASING (slow-in / slow-out) =================
def _clamp01(x):
    return 0.0 if x < 0 else (1.0 if x > 1 else x)

def ease_io_sine(p):                       # perpindahan kalem
    return 0.5 - 0.5 * math.cos(math.pi * _clamp01(p))

def ease_out_cubic(p):                     # muncul / sampai
    p = _clamp01(p)
    return 1 - (1 - p) ** 3

def ease_in_cubic(p):                      # berangkat
    p = _clamp01(p)
    return p * p * p

def ant_f(p, pre=0.18):                    # ANTICIPATION: mundur dulu
    if p < pre:
        return -0.12 * math.sin(p / pre * math.pi)
    return ease_io_sine((p - pre) / max(1e-6, 1 - pre))

def follow(u):                             # FOLLOW-THROUGH teredam
    return 0.0 if u <= 0 else math.exp(-3 * u) * math.sin(6 * u)

def phase_t(t, pre, dur, post=0.9):        # waktu aksi lokal + ekor follow-thu
    if t < pre:
        return -(pre - t) / pre * 0.12, 0.0
    u = (t - pre) / max(0.1, dur)
    return ant_f(u), max(0.0, u - 1.0) * post

# ================= LOGO DEEP WATCH (originalitas) =================
_LOGO = None
_LOGO_W = None

def make_logo():
    global _LOGO
    if _LOGO is not None:
        return _LOGO
    im = Image.new('RGBA', (360, 360), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    cx, cy = 180, 150
    d.ellipse([cx - 118, cy - 118, cx + 118, cy + 118], outline=(46, 230, 200, 235), width=7)
    d.ellipse([cx - 96, cy - 96, cx + 96, cy + 96], outline=(70, 90, 120, 150), width=2)
    for r, a in ((40, 130), (66, 90), (90, 60)):            # gelang sonar
        d.arc([cx - r, cy - r, cx + r, cy + r], -35, 155, fill=(46, 230, 200, a), width=3)
    d.ellipse([cx - 26, cy - 26, cx + 26, cy + 26], fill=(10, 22, 34, 255), outline=(46, 230, 200, 235), width=3)
    d.ellipse([cx - 9, cy - 9, cx + 9, cy + 9], fill=(46, 230, 200, 255))
    d.line([(cx + 20, cy - 20), (cx + 58, cy - 58)], fill=(46, 230, 200, 200), width=4)
    fb = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 46)
    fs = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 17)
    t1 = 'DEEP WATCH'
    w1 = d.textlength(t1, font=fb)
    d.text((cx - w1 / 2, 284), t1, font=fb, fill=(232, 240, 252, 255))
    t2 = 'EVERY SHIFT HAS ITS RULES'
    w2 = d.textlength(t2, font=fs)
    d.text((cx - w2 / 2, 336), t2, font=fs, fill=(140, 160, 190, 220))
    _LOGO = im
    return im

def logo_card(tn, dom, kind, tc, dur):
    """Kartu pembuka/penutup film: logo fade-in/out kalem."""
    im = Image.new('RGB', (CW, CH), (3, 6, 11))
    d = ImageDraw.Draw(im)
    if kind == 'intro':
        a = ease_out_cubic(tc / 1.2) * (1.0 if tc < dur - 0.5 else 1 - ease_in_cubic((tc - (dur - 0.5)) / 0.5))
    else:
        a = ease_out_cubic(tc / 1.0)
    a = max(0.0, min(1.0, a))
    lg = make_logo().resize((400, 400)).copy()
    lg.putalpha((lg.getchannel('A').point(lambda v: int(v * a))))
    im.paste(lg, (CW // 2 - 200, CH // 2 - 230), lg)
    fs = font(20, bold=False)
    sub = ('DEEP SPACE SERIES' if dom == 'SPACE' else 'DEEP SEA SERIES') + '  ·  FILE HD-%04d' % tn
    d.text(((CW - d.textlength(sub, font=fs)) / 2, CH - 96), sub, font=fs,
           fill=tuple(int(c * a) for c in ((46, 230, 200) if dom == 'SPACE' else (90, 190, 230))))
    return im.resize((W, H), Image.Resampling.LANCZOS)

def make_logo_wm():
    global _LOGO_W
    if _LOGO_W is None:
        _LOGO_W = make_logo().resize((116, 116))
    return _LOGO_W

# ================= MONSTER MATEMATIKA =================
def creature_params(seed, sil):
    rng = random.Random(seed * 613 + hash(sil) % 997)
    P = {'tent': rng.randrange(3, 8), 'spike': rng.random() < 0.5,
         'eyes': rng.randrange(1, 6), 'r0': rng.randrange(46, 80),
         'h1': (rng.randrange(2, 5), rng.random() * 6.28, 0.16 + rng.random() * 0.12),
         'h2': (rng.randrange(6, 10), rng.random() * 6.28, 0.07 + rng.random() * 0.08),
         'h3': (rng.randrange(11, 15), rng.random() * 6.28, 0.04 + rng.random() * 0.06)}
    if any(k in sil for k in ('worm', 'eel', 'coil')):
        P['tent'] = 0; P['long'] = True
    if any(k in sil for k in ('wedge', 'maw', 'jaw')):
        P['jaw'] = True
    return P

def _creature_poly(P, cx, cy, R, t):
    pts = []
    for k in range(40):
        th = k / 40.0 * 2 * math.pi
        r = R
        for (kk, ph, amp) in (P['h1'], P['h2'], P['h3']):
            r *= 1 + amp * math.sin(kk * th + ph + t * 0.8)
        if P['spike'] and k % 5 == 0:
            r *= 1.3
        pts.append((cx + r * math.cos(th), cy + r * math.sin(th)))
    return pts

def draw_creature(d, cx, cy, P, t, scale, accent):
    R = P['r0'] * (0.4 + max(0.02, scale))
    body_c = (26, 32, 46)
    rim = tuple(min(255, int(c * 0.8) + 40) for c in tuple(int(accent[i:i + 2], 16) for i in (1, 3, 5)))
    hx, hy = cx, cy
    if P.get('long'):
        pts = []
        for i in range(26):
            s = i / 25.0
            x = cx - R * 2.2 + s * R * 4.4
            y = cy + math.sin(s * 6 + t * 1.4) * R * 0.5 * (0.4 + s)
            pts.append((x, y))
        for i in range(25):
            wdt = max(2, int((1 - i / 26.0) * R * 0.5))
            d.line([pts[i], pts[i + 1]], fill=body_c, width=wdt)
        d.line([pts[0], pts[-1]], fill=rim, width=1)
        hx, hy = pts[-1]
    else:
        body = _creature_poly(P, cx, cy, R, t)
        d.polygon(body, fill=body_c, outline=rim)
        for i in range(P['tent']):
            a0 = i / P['tent'] * 2 * math.pi + 0.4
            x, y = cx + R * 0.8 * math.cos(a0), cy + R * 0.8 * math.sin(a0)
            pts = [(x, y)]
            for s in range(1, 9):                    # tentakel = overlapping action
                ss = s / 8.0
                ln = R * 1.5 * ss
                wob = math.sin(ss * 5 + t * 1.8 + i) * R * 0.3 * ss * (1 + 0.3 * math.sin(t * 0.7 + s))
                pts.append((x + math.cos(a0) * ln - math.sin(a0) * wob,
                            y + math.sin(a0) * ln + math.cos(a0) * wob))
            for s in range(8):
                d.line([pts[s], pts[s + 1]], fill=body_c, width=max(2, int(R * 0.15 * (1 - s / 9))))
            d.line([pts[0], pts[-1]], fill=rim, width=1)
    if P.get('jaw'):
        op = (math.sin(t * 1.6) + 1) / 2
        d.polygon([(hx - R * 0.5, hy), (hx + R * 0.7, hy - R * 0.4 * op - 4), (hx + R * 0.55, hy)], fill=(40, 10, 16))
        d.polygon([(hx - R * 0.5, hy + 4), (hx + R * 0.7, hy + R * 0.4 * op + 6), (hx + R * 0.55, hy + 4)], fill=(40, 10, 16))
        for i in range(5):
            tx = hx - R * 0.35 + i * R * 0.24
            d.polygon([(tx, hy - 2), (tx + 6, hy - R * 0.26 * op - 4), (tx + 12, hy - 2)], fill=(226, 232, 240))
    if int(t * 0.9) % 6 != 4:
        for i in range(P['eyes']):
            ex = hx + (i - P['eyes'] / 2) * R * 0.22 + R * 0.1
            ey = hy - R * 0.15 + (i % 2) * R * 0.12
            rr = max(2, int(R * 0.07))
            d.ellipse([ex - rr - 2, ey - rr - 2, ex + rr + 2, ey + rr + 2], fill=(60, 20, 26))
            d.ellipse([ex - rr, ey - rr, ex + rr, ey + rr], fill=accent)
            d.point((ex, ey), fill=(255, 255, 255))

# ================= STICKMAN (rumus gerak baru) =================
def draw_worker(d, x, y, s, pose, t, dom, accent, suit=None, face=1, headset=False):
    suit = suit or ((216, 222, 234) if dom == 'SPACE' else (232, 182, 94))
    w = max(3, s // 20)
    if pose not in ('lie', 'crawl', 'float'):        # bayangan grounding biar pose terbaca
        d.ellipse([x - s // 3, y + s // 3 - 1, x + s // 3, y + s // 3 + 5], fill=(8, 11, 17))
    # ========== MOTION ENGINE v3 (baru 100%): skeleton prosedural ala kartun ==========
    # Sudut ruas diukur dari arah lurus-bawah (rad); positif = ke depan (+x).
    # Semua gerak = siklus kontinu (jalan/lari/merangkak) atau pose kunci + idle breath.
    def seg(a, b, wd=w, col=suit):
        d.line([(int(a[0]), int(a[1])), (int(b[0]), int(b[1]))], fill=col, width=wd)

    def bone(px, py, a1, l1, a2, l2, wd=w, floor=None):
        mx, my = px + math.sin(a1) * l1, py + math.cos(a1) * l1
        ex, ey = mx + math.sin(a1 + a2) * l2, my + math.cos(a1 + a2) * l2
        if floor is not None:
            my = min(my, floor); ey = min(ey, floor)
        seg((px, py), (mx, my), wd); seg((mx, my), (ex, ey), wd)
        return ex, ey

    def leg(hp, a1, bend):
        return bone(hp[0], hp[1], a1, s * 0.26, bend, s * 0.25, floor=y + 2)

    def arm(shp, a1, bend):
        return bone(shp[0], shp[1], a1, s * 0.21, bend, s * 0.19)

    def torso(hp, lean, ln=s * 0.37):
        sp2 = (hp[0] + math.sin(lean) * ln, hp[1] - math.cos(lean) * ln)
        seg(hp, sp2, wd=w + 1)
        return sp2

    br = math.sin(t * 1.8) * s * 0.008                 # napas idle sangat halus
    hx, hy = x, y - s * 0.47

    if pose in ('walk', 'run'):
        run = pose == 'run'
        sp = t * (9.5 if run else 5.8)
        amp = 0.85 if run else 0.48
        lean = 0.30 if run else 0.09
        bob = abs(math.cos(sp)) * (s * 0.035 if run else s * 0.016)
        hip = (x, y - s * 0.44 + bob)
        sho = torso(hip, lean)
        for ph in (0.0, math.pi):
            leg(hip, math.sin(sp + ph) * amp, 0.22 + (0.95 if run else 0.42) * max(0.0, math.cos(sp + ph)))
        for ph in (math.pi, 0.0):
            arm(sho, math.sin(sp + ph) * (1.0 if run else 0.38), 1.9 if run else 0.5)
        hx, hy = sho[0] + math.sin(lean) * s * 0.17, sho[1] - s * 0.15
    elif pose == 'crawl':
        sp = t * 6.2
        und = math.sin(sp) * s * 0.02
        hip = (x - s * 0.16, y - s * 0.24 + und)
        sho = torso(hip, 1.25, ln=s * 0.34)             # punggung hampir horizontal
        for ph in (0.0, math.pi):                       # lengan diagonal bergantian
            hxx = sho[0] + s * 0.08 + math.sin(sp + ph) * s * 0.10
            seg(sho, (hxx, y - 2)); seg((hxx, y - 2), (hxx + s * 0.06, y - 2))
        for ph in (math.pi, 0.0):                       # lutut + kering bergantian
            kx = hip[0] + math.sin(sp + ph) * s * 0.07
            seg(hip, (kx, y - 1)); seg((kx, y - 1), (kx - s * 0.17, y - 3))
        hx, hy = sho[0] + s * 0.13, sho[1] - s * 0.12 - und
    elif pose == 'back':                                # mundur tersandung, tangan menangkis
        sp = t * 8.0
        bob = abs(math.cos(sp)) * s * 0.02
        hip = (x, y - s * 0.42 + bob)
        sho = torso(hip, -0.24)
        for ph in (0.0, math.pi):
            leg(hip, math.sin(sp + ph) * 0.42, 0.5 * max(0.0, math.cos(sp + ph)) + 0.15)
        arm(sho, 2.2 + math.sin(t * 9) * 0.12, 0.5)
        arm(sho, 2.5 + math.cos(t * 9) * 0.12, 0.4)
        hx, hy = sho[0] - s * 0.10, sho[1] - s * 0.13
    elif pose == 'climb':
        sp = t * 5.0
        hip = (x, y - s * 0.50)
        sho = torso(hip, 0.10)
        for ph in (0.0, math.pi):
            leg(hip, 0.5 + math.sin(sp + ph) * 0.5, 1.6)
        for ph in (math.pi, 0.0):
            arm(sho, 2.9 + math.sin(sp + ph) * 0.35, 0.2)
        hx, hy = sho[0] + s * 0.05, sho[1] - s * 0.15
    elif pose == 'float':
        rot = math.sin(t * 0.8) * 0.22
        hip = (x, y - s * 0.42)
        sho = torso(hip, rot)
        leg(hip, 0.5 + rot, 0.7); leg(hip, -0.3 + rot, 0.5)
        arm(sho, 1.1 + rot, 0.3); arm(sho, -0.9 + rot, 0.3)
        d.line([(sho[0], sho[1]), (sho[0] + s * 0.3, sho[1] - s * 0.6)], fill=(150, 160, 175), width=2)
        hx, hy = sho[0] + math.sin(rot) * s * 0.15, sho[1] - s * 0.15
    elif pose == 'sit':
        hip = (x, y - s * 0.24 + br)
        sho = torso(hip, 0.10)
        leg(hip, 1.35, -1.45); leg(hip, 1.25, -1.35)
        arm(sho, 0.7 + br * 4, 1.1); arm(sho, 0.5 - br * 4, 1.2)
        hx, hy = sho[0] + s * 0.04, sho[1] - s * 0.15
    elif pose == 'lie':
        hip = (x - s * 0.18, y - s * 0.07)
        sho = torso(hip, 1.45, ln=s * 0.36)
        leg(hip, 1.3, 0.35); leg(hip, 1.45, 0.5)
        arm(sho, 1.2, 0.4); arm(sho, -0.4, 0.6)
        hx, hy = sho[0] + s * 0.12, sho[1] - s * 0.10
    elif pose == 'kneel':
        hip = (x, y - s * 0.26 + br)
        sho = torso(hip, 0.16)
        bone(hip[0], hip[1], 0.15, s * 0.26, -1.9, s * 0.25, floor=y + 2)   # lutut belakang di tanah
        leg(hip, 1.15, -1.5)                                                # kaki depan menapak
        arm(sho, 0.8 + br * 4, 0.9); arm(sho, 0.5, 1.1)
        hx, hy = sho[0] + s * 0.06, sho[1] - s * 0.15
    elif pose == 'crouch':
        hip = (x, y - s * 0.24 + br)
        sho = torso(hip, 0.45)
        leg(hip, 0.9, -1.7); leg(hip, 1.05, -1.8)
        arm(sho, 0.9, 0.8); arm(sho, 0.6, 1.0)
        hx, hy = sho[0] + s * 0.10, sho[1] - s * 0.13
    elif pose in ('seal', 'lever'):
        vib = math.sin(t * (10 if pose == 'seal' else 2.4)) * (0.06 if pose == 'seal' else 0.30)
        hip = (x, y - s * 0.42)
        sho = torso(hip, 0.22)
        leg(hip, -0.15, 0.1); leg(hip, 0.35, 0.15)
        arm(sho, 1.25 + vib, 0.25); arm(sho, 1.05 + vib, 0.35)
        hx, hy = sho[0] + s * 0.08, sho[1] - s * 0.15
    elif pose in ('crank', 'winch' if False else 'crank'):
        a = t * 2.6
        hip = (x, y - s * 0.42)
        sho = torso(hip, 0.18)
        leg(hip, -0.12, 0.08); leg(hip, 0.3, 0.12)
        wx, wy = x + s * 0.42, y - s * 0.28
        seg(sho, (wx + math.cos(a) * 9, wy + math.sin(a) * 9))
        seg(sho, (wx + math.cos(a + 2.6) * 9, wy + math.sin(a + 2.6) * 9))
        hx, hy = sho[0] + s * 0.07, sho[1] - s * 0.15
    elif pose in ('weld', 'cut', 'drill'):
        j = math.sin(t * (9 if pose == 'weld' else 14)) * s * 0.015
        hip = (x, y - s * 0.40)
        sho = torso(hip, 0.35)
        leg(hip, -0.2, 0.12); leg(hip, 0.45, 0.2)
        arm(sho, 1.15, 0.35 + j * 0.02); arm(sho, 1.0, 0.5)
        d.line([(sho[0] + s * 0.3, sho[1] + s * 0.1 + j), (sho[0] + s * 0.5, sho[1] + s * 0.05 + j)],
               fill=(150, 160, 175), width=3)
        hx, hy = sho[0] + s * 0.10, sho[1] - s * 0.14
    elif pose in ('wipe', 'scrub'):
        a = t * (2.4 if pose == 'wipe' else 6.0)
        hip = (x, y - s * 0.42)
        sho = torso(hip, 0.15)
        leg(hip, -0.12, 0.08); leg(hip, 0.25, 0.1)
        arm(sho, 0.9 + math.cos(a) * 0.45, 0.3 + math.sin(a) * 0.25)
        arm(sho, -0.3, 0.5)
        hx, hy = sho[0] + s * 0.06, sho[1] - s * 0.15
    elif pose == 'carry':
        hip = (x, y - s * 0.43)
        sho = torso(hip, 0.14)
        leg(hip, math.sin(t * 5.8) * 0.4, 0.3); leg(hip, math.sin(t * 5.8 + math.pi) * 0.4, 0.3)
        h1 = arm(sho, 0.9, 1.5); h2 = arm(sho, 0.8, 1.6)
        d.rectangle([h1[0] - s * 0.12, h1[1] - s * 0.06, h1[0] + s * 0.14, h1[1] + s * 0.14],
                    fill=(120, 100, 70), outline=(70, 58, 40))
        hx, hy = sho[0] + s * 0.05, sho[1] - s * 0.15
    elif pose == 'clip':
        hip = (x, y - s * 0.44 + br)
        sho = torso(hip, 0.12)
        leg(hip, -0.1, 0.06); leg(hip, 0.18, 0.08)
        arm(sho, 0.9, 1.7)
        tk = 1 if int(t * 2) % 2 else 0
        arm(sho, 0.7, 1.2 - tk * 0.15)
        d.rectangle([x + s * 0.16, y - s * 0.42, x + s * 0.34, y - s * 0.20],
                    fill=(220, 226, 236), outline=(90, 100, 120))
        hx, hy = sho[0] + s * 0.04, sho[1] - s * 0.15
    elif pose == 'mug':
        hip = (x, y - s * 0.44 + br)
        sho = torso(hip, 0.06)
        leg(hip, -0.1, 0.06); leg(hip, 0.16, 0.08)
        arm(sho, 0.8, 1.9)
        d.rectangle([x + s * 0.24, y - s * 0.62, x + s * 0.36, y - s * 0.50], fill=(180, 90, 60))
        arm(sho, -0.25, 0.5)
        hx, hy = sho[0] + s * 0.03, sho[1] - s * 0.15
    elif pose == 'radio':
        hip = (x, y - s * 0.44 + br)
        sho = torso(hip, 0.05)
        leg(hip, -0.1, 0.06); leg(hip, 0.16, 0.08)
        arm(sho, 0.35, 2.3)                              # tangan ke headset
        g = math.sin(t * 2.6) * 0.15
        arm(sho, 0.8 + g, 0.9)                           # tangan isyarat bicara
        hx, hy = sho[0] + s * 0.02, sho[1] - s * 0.15
    elif pose == 'listen':
        hip = (x, y - s * 0.44)
        sho = torso(hip, 0.10)
        leg(hip, -0.1, 0.06); leg(hip, 0.2, 0.08)
        arm(sho, 1.5, 0.1)                               # telapak ke dinding
        arm(sho, 0.3, 2.4)                               # tangan ke headset
        hx, hy = sho[0] + s * 0.05, sho[1] - s * 0.15
    elif pose == 'reach':
        hip = (x, y - s * 0.44)
        sho = torso(hip, 0.12)
        leg(hip, -0.12, 0.08); leg(hip, 0.28, 0.1)
        arm(sho, 2.5 + math.sin(t * 2.0) * 0.08, 0.15)    # menjulang ke depan-atas
        arm(sho, -0.2, 0.4)
        hx, hy = sho[0] + s * 0.06, sho[1] - s * 0.15
    elif pose == 'hang':
        sw2 = math.sin(t * 2.0) * 0.12
        d.line([(x - s * 0.22, y - s * 0.95), (x + s * 0.22, y - s * 0.95)], fill=(110, 120, 140), width=4)
        hip = (x + sw2 * s, y - s * 0.46)
        sho = torso(hip, sw2)
        arm(sho, 3.05 + sw2, 0.1); arm(sho, 3.25 + sw2, 0.1)
        leg(hip, 0.15 + sw2, 0.2); leg(hip, -0.1 + sw2, 0.25)
        hx, hy = sho[0], sho[1] - s * 0.15
    elif pose == 'hose':
        hip = (x, y - s * 0.43)
        sho = torso(hip, 0.15)
        leg(hip, -0.15, 0.1); leg(hip, 0.3, 0.12)
        arm(sho, 1.3, 0.2); arm(sho, 1.1, 0.4)
        d.arc([x - s, y - s * 0.25, x + s * 0.5, y + s * 0.5], 20, 120, fill=(110, 120, 140), width=3)
        hx, hy = sho[0] + s * 0.06, sho[1] - s * 0.15
    elif pose == 'spray':
        hip = (x, y - s * 0.44)
        sho = torso(hip, 0.08)
        leg(hip, -0.1, 0.06); leg(hip, 0.2, 0.08)
        arm(sho, 1.9, 0.2)
        d.rectangle([x + s * 0.28, y - s * 0.72, x + s * 0.36, y - s * 0.60], fill=(150, 160, 175))
        arm(sho, -0.25, 0.5)
        hx, hy = sho[0] + s * 0.04, sho[1] - s * 0.15
    elif pose == 'scoop':
        hip = (x, y - s * 0.26 + br)
        sho = torso(hip, 0.3)
        bone(hip[0], hip[1], 0.15, s * 0.26, -1.9, s * 0.25, floor=y + 2)
        leg(hip, 1.15, -1.5)
        arm(sho, 1.1, 0.5)
        d.rectangle([x + s * 0.3, y - s * 0.1, x + s * 0.42, y - s * 0.02], fill=(200, 206, 216))
        hx, hy = sho[0] + s * 0.08, sho[1] - s * 0.14
    elif pose == 'laugh':
        bb = math.sin(t * 8) * s * 0.012
        hip = (x, y - s * 0.43)
        sho = torso(hip, -0.08)
        leg(hip, -0.12, 0.08); leg(hip, 0.18, 0.08)
        arm(sho, 0.9, 1.6); arm(sho, -0.9, 1.6)          # pegang perut
        hx, hy = sho[0], sho[1] - s * 0.14 + bb
    elif pose == 'cry':
        hip = (x, y - s * 0.42)
        sho = torso(hip, 0.25)
        leg(hip, -0.12, 0.08); leg(hip, 0.18, 0.08)
        arm(sho, 0.5, 2.6); arm(sho, 0.7, 2.5)           # menutup muka
        hx, hy = sho[0] + s * 0.06, sho[1] - s * 0.13
    elif pose == 'wave':
        wv = math.sin(t * 6) * 0.5
        hip = (x, y - s * 0.44)
        sho = torso(hip, 0.04)
        leg(hip, -0.1, 0.06); leg(hip, 0.16, 0.08)
        arm(sho, 2.7 + wv * 0.4, 0.5 + wv)
        arm(sho, -0.25, 0.5)
        hx, hy = sho[0] + s * 0.03, sho[1] - s * 0.15
    else:  # stand / stare / talk
        hip = (x, y - s * 0.44 + br)
        sho = torso(hip, 0.04)
        leg(hip, -0.11, 0.06); leg(hip, 0.15, 0.07)
        if pose == 'talk':
            g = math.sin(t * 3.0) * 0.25
            arm(sho, 0.8 + g, 1.0); arm(sho, -0.2 - g * 0.5, 0.5)
        elif pose == 'stare':
            arm(sho, 0.15, 0.25); arm(sho, -0.15, 0.25)
        else:
            g = math.sin(t * 2.2) * 0.05
            arm(sho, 0.12 + g, 0.3); arm(sho, -0.12 - g, 0.3)
        hx, hy = sho[0] + s * 0.02, sho[1] - s * 0.15
    hx, hy = int(hx), int(hy)

    r = max(5, s // 9)
    d.ellipse([hx - r, hy - r, hx + r, hy + r], fill=suit)
    if dom == 'SPACE':
        d.ellipse([hx - r + 2, hy - r + 2, hx + r - 1, hy + r - 2], fill=(24, 34, 52))
        d.arc([hx - r, hy - r, hx + r, hy + r], 200, 340, fill=accent, width=2)
    else:
        d.ellipse([hx - r // 2, hy - r // 2, hx + r // 2, hy + r // 2], fill=(34, 50, 66))
    if pose in ('laugh', 'cry', 'wave'):                    # ekspresi wajah
        ec = (235, 244, 252) if dom == 'SPACE' else (46, 34, 22)
        d.ellipse([hx - 4, hy - 3, hx - 2, hy - 1], fill=ec)
        d.ellipse([hx + 1, hy - 3, hx + 3, hy - 1], fill=ec)
        if pose == 'laugh':
            d.arc([hx - 4, hy, hx + 4, hy + 7], 10, 170, fill=ec, width=2)
        elif pose == 'cry':
            d.arc([hx - 4, hy + 5, hx + 4, hy + 11], 190, 350, fill=ec, width=2)
            for k2 in (-3, 3):
                ty = (int(t * 22) + (k2 + 3) * 5) % 10
                d.ellipse([hx + k2 - 1, hy + 2 + ty, hx + k2 + 1, hy + 4 + ty], fill=(140, 200, 230))
        else:
            d.line([(hx - 3, hy + 4), (hx + 3, hy + 4)], fill=ec, width=2)
    else:                                                   # titik pandang: arah perhatian
        ec = (235, 244, 252) if dom == 'SPACE' else (46, 34, 22)
        d.ellipse([hx + face * 2 - 1, hy - 2, hx + face * 2 + 1, hy], fill=ec)
    if headset:                                             # headphone: sedang mendengar
        d.arc([hx - r - 1, hy - r - 1, hx + r + 1, hy + r + 1], 180, 360, fill=(200, 210, 225), width=3)
        d.ellipse([hx - r - 3, hy - 3, hx - r + 1, hy + 4], fill=(200, 210, 225))
        d.ellipse([hx + r - 1, hy - 3, hx + r + 3, hy + 4], fill=(200, 210, 225))
    if pose not in ('lie', 'crawl') and dom == 'SPACE' and \
            pose in ('walk', 'run', 'float', 'carry', 'climb', 'weld', 'seal', 'crank'):
        d.rounded_rectangle([x - s // 4 - 2, y - int(s * 0.40), x - s // 4 + 4, y - s // 8], 3, fill=(126, 134, 148))

def _draw_worker_pose(im, x, y, s, pose, t, dom, accent, alpha, suit=None, face=1, headset=False):
    if alpha <= 0:
        return
    ov = Image.new('RGBA', im.size, (0, 0, 0, 0))
    draw_worker(ImageDraw.Draw(ov), x, y, s, pose, t, dom, accent, suit, face, headset)
    if alpha < 1:
        ov.putalpha(ov.getchannel('A').point(lambda v: int(v * alpha)))
    im.alpha_composite(ov)

def draw_worker_blend(im, x, y, s, poses, t, dom, accent, suit=None, face=1, headset=False):
    """poses = [pA, pB, k] : crossfade pose saat ganti adegan (anti-snap)."""
    if len(poses) == 1:
        draw_worker(ImageDraw.Draw(im), x, y, s, poses[0], t, dom, accent, suit, face, headset)
        return
    pA, pB, k = poses
    _draw_worker_pose(im, x, y, s, pA, t, dom, accent, 1 - k, suit, face, headset)
    _draw_worker_pose(im, x, y, s, pB, t, dom, accent, k, suit, face, headset)

# ================= KAMUS SITUASI — 48 ARKETIPE "UNIVERSE" =================
# keys, poseA, poseB, aksi, makhluk, fx, kamera, shot, properti
SCENES = [
 (['weld', 'torch', 'arc', 'spark'], 'weld', 'lean', 'arc', 'hint', 'spark', 'push', 'medium', ['pipes']),
 (['valve', 'crank', 'torqu', 'pump'], 'crank', 'lean', 'cycle', 'none', 'none', 'push', 'close', ['wheel']),
 (['crawl', 'duct', 'vent'], 'crawl', 'crouch', 'walk', 'hint', 'dust', 'sweep', 'wide', ['duct']),
 (['run', 'sprint', 'flee'], 'run', 'back', 'walk', 'attack', 'none', 'pan', 'wide', ['pipes']),
 (['hid', 'crouch', 'held my breath', 'behind'], 'crouch', 'kneel', 'still', 'watch', 'dip', 'static', 'medium', ['crates']),
 (['seal', 'hatch', 'airlock', 'lock'], 'seal', 'crank', 'cycle', 'approach', 'none', 'static', 'medium', ['hatch', 'gauges']),
 (['gauge', 'needle', 'readout', 'dial'], 'stare', 'lean', 'still', 'none', 'none', 'push', 'close', ['gauges']),
 (['eyes', 'staring', 'watching', 'blink', 'blue light'], 'stare', 'crouch', 'still', 'watch', 'none', 'push', 'close', ['win']),
 (['monitor', 'sensor', 'sonar', 'hydrophone', 'screen', 'scope'], 'sit', 'stare', 'still', 'hint', 'glow', 'push', 'medium', ['desk']),
 (['radio', 'comms', 'channel', 'transmission', 'intercom', 'keyed'], 'radio', 'talk', 'still', 'none', 'hear', 'static', 'close', ['gauges']),
 (['answer', 'voice', 'called', 'whisper'], 'radio', 'stare', 'still', 'hint', 'hear', 'push', 'close', ['gauges']),
 (['door', 'bell', 'opened'], 'lean', 'seal', 'still', 'watch', 'none', 'push', 'medium', ['hatch']),
 (['knock', 'tap', 'thud', 'bang'], 'stare', 'back', 'still', 'watch', 'hear', 'static', 'medium', ['hatch']),
 (['groan', 'creak', 'moan', 'sound', 'noise'], 'stare', 'lean', 'still', 'watch', 'none', 'tilt', 'wide', ['pipes']),
 (['beacon', 'lighthouse', 'lens'], 'wipe', 'reach', 'cycle', 'none', 'beam', 'static', 'wide', ['beacon']),
 (['lamp', 'flashlight', 'blackout', 'killed the lamps'], 'lean', 'walk', 'walk', 'hint', 'lamp', 'sweep', 'wide', ['pipes']),
 (['attack', 'grab', 'lunged', 'seized'], 'back', 'run', 'walk', 'attack', 'none', 'pan', 'wide', ['pipes']),
 (['pull', 'drag', 'caught', 'held'], 'back', 'crouch', 'pull', 'attack', 'none', 'static', 'medium', ['pipes']),
 (['claw', 'bite', 'teeth'], 'back', 'run', 'still', 'attack', 'none', 'push', 'medium', ['win']),
 (['ship', 'station', 'vessel', 'hull', 'deck', 'bridge', 'tug', 'rig', 'platform',
   'submarine', 'boat', 'surface', 'eva', 'tether', 'spacewalk', 'keel'], 'eva', 'stand', 'still', 'approach', 'debris', 'pan', 'estab', ['ext']),
 (['float', 'drift', 'weightless'], 'float', 'stand', 'still', 'hint', 'debris', 'tilt', 'wide', []),
 (['alarm', 'siren', 'klaxon', 'warning'], 'run', 'stare', 'walk', 'approach', 'alarm', 'static', 'medium', ['gauges']),
 (['blood', 'hurt', 'injur'], 'kneel', 'crouch', 'still', 'watch', 'dip', 'push', 'close', ['crates']),
 (['gone', 'missing', 'empty', 'no one'], 'stare', 'lean', 'still', 'watch', 'dip', 'tilt', 'wide', ['crates']),
 (['remains', 'body', 'found'], 'kneel', 'crouch', 'still', 'watch', 'dip', 'push', 'medium', ['crates']),
 (['glass', 'viewport', 'window', 'porthole'], 'stare', 'stare', 'still', 'approach', 'bubble', 'push', 'close', ['win']),
 (['crack', 'fracture', 'leak'], 'seal', 'wipe', 'cycle', 'approach', 'none', 'push', 'close', ['win']),
 (['descend', 'dive', 'descent', 'sink', 'drop'], 'float', 'sit', 'still', 'hint', 'bubble', 'tilt', 'wide', []),
 (['log', 'checklist', 'wrote', 'record', 'manifest'], 'clip', 'sit', 'still', 'none', 'none', 'static', 'medium', ['desk']),
 (['coffee', 'eating', 'meal', 'galley', 'drink'], 'mug', 'sit', 'still', 'none', 'none', 'static', 'medium', ['galley']),
 (['rest', 'sleep', 'slept', 'asleep', 'sleeping', 'bunk', 'nap', 'my bed'], 'sit', 'lie', 'still', 'none', 'none', 'tilt', 'medium', ['galley']),
 (['walk', 'corridor', 'headed', 'made my way'], 'walk', 'carry', 'walk', 'none', 'none', 'pan', 'wide', ['ladder']),
 (['climb', 'ladder'], 'climb', 'walk', 'arc', 'none', 'none', 'tilt', 'medium', ['ladder']),
 (['carry', 'crate', 'toolbox', 'haul', 'brought'], 'carry', 'walk', 'walk', 'none', 'none', 'pan', 'wide', ['crates']),
 (['talk', 'said', 'told', 'asked', 'partner', 'crew'], 'talk', 'stand', 'still', 'none', 'none', 'static', 'medium', ['gauges']),
 (['inspect', 'pipe', 'flange', 'bolt', 'check'], 'lean', 'clip', 'still', 'none', 'none', 'push', 'medium', ['pipes']),
 (['tag', 'label', 'mark'], 'clip', 'lean', 'still', 'none', 'none', 'static', 'close', ['pipes']),
 (['coil', 'cable', 'line', 'rope'], 'crank', 'carry', 'cycle', 'none', 'none', 'static', 'medium', ['spool']),
 (['winch', 'wire', 'reel'], 'crank', 'lean', 'cycle', 'hint', 'none', 'push', 'medium', ['spool']),
 (['locker', 'suit up', 'helmet'], 'stand', 'clip', 'still', 'none', 'none', 'static', 'medium', ['locker']),
 (['ping', 'echo', 'return', 'contact'], 'sit', 'stare', 'still', 'hint', 'glow', 'push', 'close', ['desk']),
 (['bubble', 'bubbles'], 'stare', 'wipe', 'still', 'approach', 'bubble', 'push', 'medium', ['win']),
 (['shadow', 'shape', 'silhouette', 'figure'], 'stare', 'back', 'still', 'approach', 'none', 'push', 'wide', ['win']),
 (['something', 'thing in', 'thing was', 'thing at'], 'stare', 'lean', 'still', 'approach', 'none', 'tilt', 'wide', ['win']),
 (['wait', 'calm', 'shift', 'routine', 'quiet', 'breathing', 'exhale', 'breath'], 'stand', 'sit', 'still', 'none', 'none', 'static', 'medium', ['gauges']),
 (['count', 'rule', 'remember', 'list'], 'clip', 'stand', 'still', 'none', 'none', 'static', 'close', ['gauges']),
 (['pressure', 'hiss', 'steam', 'air'], 'seal', 'lean', 'cycle', 'none', 'dust', 'push', 'medium', ['pipes']),
 (['night', 'alone', 'last', 'everyone'], 'stand', 'lean', 'still', 'watch', 'dip', 'sweep', 'wide', ['gauges']),
 (['follow', 'came', 'behind me'], 'walk', 'back', 'walk', 'approach', 'none', 'pan', 'wide', ['pipes']),
 (['clean', 'scrub', 'mop', 'decontaminate'], 'scrub', 'crouch', 'cycle', 'none', 'dust', 'static', 'medium', ['reactor']),
 (['reactor', 'core', 'coolant', 'fusion'], 'lean', 'scrub', 'still', 'hint', 'glow', 'push', 'medium', ['reactor']),
 (['satellite', 'antenna', 'dish', 'transmitter'], 'reach', 'lean', 'cycle', 'hint', 'spark', 'tilt', 'medium', ['dish']),
 (['cutter', 'plasma', 'slice', 'salvage', 'cutting'], 'cut', 'lean', 'cycle', 'watch', 'spark', 'push', 'medium', ['wreck']),
 (['waste', 'drum', 'barrel', 'radioactive', 'cask'], 'carry', 'lever', 'walk', 'none', 'none', 'pan', 'medium', ['drums']),
 (['cockpit', 'pilot', 'helm', 'steer'], 'sit', 'stare', 'still', 'hint', 'none', 'push', 'close', ['cockpit']),
 (['quarantine', 'sample', 'vial', 'specimen'], 'clip', 'stare', 'still', 'watch', 'glow', 'push', 'close', ['vials']),
 (['drill', 'bore', 'dig', 'excavat'], 'drill', 'lean', 'cycle', 'hint', 'dust', 'push', 'medium', ['rock']),
 (['cryo', 'pod', 'frozen', 'stasis', 'morgue'], 'stare', 'back', 'still', 'watch', 'frost', 'static', 'medium', ['pods']),
 (['fuel', 'refuel', 'nozzle', 'hose'], 'hose', 'lean', 'still', 'none', 'none', 'static', 'medium', ['tank']),
 (['decon', 'sanitize', 'spray', 'shower'], 'spray', 'stand', 'cycle', 'none', 'mist', 'static', 'medium', ['decon']),
 (['crane', 'magnet', 'hoist', 'lift'], 'lever', 'sit', 'cycle', 'hint', 'none', 'tilt', 'medium', ['claw']),
 (['oxygen', 'o2', 'filter', 'airflow'], 'lean', 'scrub', 'still', 'watch', 'mist', 'push', 'close', ['o2']),
 (['splice', 'connect', 'plug', 'joint', 'fiber', 'optic'], 'kneel', 'clip', 'cycle', 'none', 'spark', 'static', 'close', ['spool']),
 (['scoop', 'soil', 'borehole', 'hole in'], 'scoop', 'kneel', 'cycle', 'watch', 'none', 'push', 'medium', ['hole']),
 (['landing gear', 'gear', 'hydraulic'], 'hang', 'lean', 'still', 'watch', 'none', 'tilt', 'medium', ['gear']),
 (['laugh', 'joke', 'smiled', 'grin', 'chuckled'], 'laugh', 'stand', 'still', 'none', 'none', 'static', 'medium', ['gauges']),
 (['cry', 'tears', 'wept', 'sob', 'cried'], 'cry', 'kneel', 'still', 'none', 'none', 'push', 'close', ['crates']),
 (['you hear', 'listen', 'imagine', 'picture this', 'stay with me', 'watch this', 'hear this'], 'wave', 'stand', 'still', 'none', 'none', 'static', 'medium', ['gauges']),
 (['chamber', 'decompression', 'habitat'], 'sit', 'stand', 'still', 'watch', 'none', 'static', 'medium', ['chamber']),
 (['turbine', 'propeller', 'net'], 'crank', 'lean', 'cycle', 'hint', 'none', 'push', 'medium', ['turbine']),
 (['kelp', 'seaweed', 'forest of'], 'stare', 'float', 'still', 'none', 'none', 'sweep', 'wide', ['kelp']),
 (['cave', 'blue hole', 'bluehole', 'tunnel'], 'crawl', 'stare', 'walk', 'watch', 'dip', 'sweep', 'wide', ['cave']),
 (['buoy', 'mooring', 'marker'], 'clip', 'stand', 'still', 'none', 'none', 'static', 'medium', ['buoy']),
 (['whale', 'click', 'pod of'], 'stare', 'float', 'still', 'hint', 'none', 'pan', 'wide', ['whale']),
 (['chain', 'anchor'], 'stare', 'back', 'still', 'watch', 'none', 'tilt', 'wide', ['chain']),
 (['morse', 'glacier', 'ice wall'], 'radio', 'stare', 'still', 'none', 'none', 'static', 'close', ['ice']),
 (['bioluminescen', 'glowing water', 'phosphor'], 'stare', 'lean', 'still', 'none', 'biolum', 'static', 'wide', ['win']),
 (['gate', 'concrete', 'bulkhead'], 'seal', 'stare', 'still', 'watch', 'none', 'push', 'medium', ['gate']),
 (['artifact', 'amphora', 'ancient hull'], 'scoop', 'kneel', 'cycle', 'watch', 'none', 'push', 'medium', ['artifact']),
 (['rig', 'derrick', 'platform'], 'lean', 'walk', 'walk', 'none', 'none', 'pan', 'wide', ['pipes'])]

# ============ ENGINE ADEGAN v2: NARRATION-DRIVEN ============
# Prinsip (riset storyboard): tiap shot MEMERANKAN baris aksi kalimat; adegan harus
# terbaca walau suara dimatikan; lokasi berkesinambungan (sticky) sampai disebut pindah.
SCENES += [
 (['flare', 'ignited', 'blinding'], 'reach', 'stand', 'still', 'attack', 'flare', 'static', 'medium', [], 1),
 (['listen', 'pressed my palm', 'vibration', 'felt for', 'held my breath'], 'listen', 'stand', 'still', 'none', 'none', 'static', 'close', [], 0),
 (['carv', 'etched', 'ridge', 'symbol'], 'stare', 'lean', 'still', 'none', 'none', 'push', 'close', ['carve'], 0),
 (['shed skin', 'shed', 'molting', 'segmented'], 'kneel', 'crouch', 'still', 'none', 'none', 'push', 'close', ['skin'], 0),
 (['kneel', 'knees', 'on my knees', 'collapse', 'fell to', 'found me'], 'kneel', 'crouch', 'still', 'none', 'none', 'static', 'medium', [], 0),
 (['pointed', 'point'], 'reach', 'stand', 'still', 'none', 'none', 'static', 'medium', [], 1),
 (['grabbed my', 'hand on my', 'my arm'], 'stand', 'talk', 'still', 'none', 'none', 'static', 'medium', [], 1),
 (['tablet', 'scrolling', 'schematics', 'records', 'data'], 'clip', 'clip', 'still', 'none', 'none', 'static', 'medium', ['desk'], 1),
 (['swept', 'sweep', 'brushed', 'mop up'], 'scrub', 'stand', 'still', 'none', 'dust', 'static', 'medium', [], 0),
 (['camera', 'footage', 'recording', 'playback'], 'stare', 'clip', 'still', 'none', 'none', 'static', 'medium', ['desk'], 0),
 (['glove', 'gloves', 'drying', 'rack'], 'reach', 'stand', 'still', 'none', 'none', 'static', 'medium', ['locker'], 0),
 (['dust', 'grit', 'particles'], 'lean', 'stand', 'still', 'none', 'dust', 'static', 'medium', [], 0),
 (['piling', 'pilings', 'stake', 'post'], 'stare', 'lean', 'still', 'none', 'none', 'static', 'medium', [], 0),
 (['prints', 'footprint', 'tracks', 'trail'], 'kneel', 'stare', 'still', 'none', 'none', 'static', 'medium', [], 0),
 (['growth', 'coral', 'barnacle', 'crust'], 'lean', 'clip', 'still', 'none', 'none', 'static', 'medium', [], 0),
 (['seam', 'weld line', 'bead'], 'weld', 'lean', 'still', 'none', 'spark', 'static', 'medium', ['pipes'], 0),
 (['borescope', 'probe', 'scoped'], 'lean', 'clip', 'still', 'none', 'none', 'static', 'medium', [], 0),
 (['smiling', 'smile', 'grin'], 'talk', 'stand', 'still', 'none', 'none', 'static', 'medium', [], 0),
 (['stand', 'wait', 'neutral', 'pause'], 'stand', 'stand', 'still', 'none', 'none', 'static', 'medium', [], 0),
]
NEUTRAL_ROW = len(SCENES) - 1
EXT_ROW = next(j for j, sc in enumerate(SCENES) if 'ext' in sc[8])

_ROWS, _LOC = [], [None]

def reset_scene_state():
    global _ROWS, _LOC, _BEATS
    _ROWS = [tuple(list(r) + [0]) if len(r) == 9 else tuple(r) for r in SCENES]
    _LOC = [None]
    _BEATS = []

def get_row(i):
    if not _ROWS:
        reset_scene_state()
    return _ROWS[i]

LOCS = [
 ('lab',      ['lab', 'sample', 'vial', 'specimen', 'geology'],                  ['desk', 'vials']),
 ('locker',   ['locker', 'equipment locker'],                                           ['locker']),
 ('bay',      ['access bay', 'airlock', 'transport dock', 'evac'],               ['hatch', 'gauges']),
 ('control',  ['control deck', 'override', 'terminal', 'bulkhead', 'schematics'], ['desk', 'gauges']),
 ('corridor', ['corridor'],                                                      ['ladder']),
 ('duct',     ['duct', 'lattice', 'junction', 'hatch', 'vent', 'crawl'],         ['duct']),
]
ROOM_EXTRA = ('win', 'vials', 'spool', 'wheel', 'carve', 'skin', 'ext')

CREATURE_CUE = ['creature', 'it came', 'it was', 'it had', "it didn", 'skin', 'carv', 'rasp',
                'click', 'claw', 'shadow', 'shape', 'silhouette', 'monster',
                'head structure', 'sensory', 'recoil', 'shriek', 'lung', 'pursuit']

import re as _re
def _hit(kw, low):
    return _re.search(r'\b' + _re.escape(kw), low) is not None   # awal kata: 'night' != 'overnight'

def plan_scene(text, i, tn=0):
    if not _ROWS:
        reset_scene_state()
    low = ' ' + text.lower() + ' '
    dom = 'SEA' if tn and tn > 500 else 'SPACE'
    for name, kws, pr in LOCS:                       # lokasi sticky: ruangan ikut narasi
        if name == 'duct' and dom == 'SEA':
            kws = ['duct', 'hatch']                  # laut: 'lattice' karang bukan duct besi
        if any(_hit(k, low) for k in kws):
            _LOC[0] = name
    best, bs = NEUTRAL_ROW, 0
    for j, row in enumerate(_ROWS):
        s = sum(len(k) for k in row[0] if _hit(k, low))   # skor berbobot: kw terpanjang menang
        if s > bs:
            best, bs = j, s
    row = _ROWS[best]
    keys, pa, pb, act, cst, fx, cam, shot, props = row[:9]
    buddy = row[9] if len(row) > 9 else 0
    if (text.lstrip().startswith('"') or ' over comm' in low or
            (bs < 6 and (_hit('said', low) or _hit('asked', low) or _hit('voice', low)))):
        if bs < 9 and cst == 'none':
            pa, pb, act = 'radio', 'talk', 'still'   # dialog = bicara via headset
    if cst not in ('none', 'watch') and not any(_hit(c, low) for c in CREATURE_CUE):
        cst = 'none'                                 # monster HANYA saat narasi menyebutnya
    if _LOC[0] and 'ext' not in props:
        lpr = next(pr for name, kws, pr in LOCS if name == _LOC[0])
        props = list(dict.fromkeys(lpr + props))      # r26: properti aksi TIDAK dibuang
    spec = (keys, pa, pb, act, cst, fx, cam, shot, props, buddy)
    for idx, r in enumerate(_ROWS):
        if r == spec:
            return idx
    _ROWS.append(spec)
    return len(_ROWS) - 1

# ================= SUBTITLE 6 GAYA =================
def wrap(d, text, fnt, maxw):
    words, lines, cur = text.split(), [], ''
    for wd in words:
        t2 = (cur + ' ' + wd).strip()
        if d.textlength(t2, font=fnt) > maxw:
            if cur:
                lines.append(cur)
            cur = wd
        else:
            cur = t2
    if cur:
        lines.append(cur)
    return lines

def draw_sub(d, text, t_in, dur, style, accent):
    f = font(26)
    lines = wrap(d, text, f, W - 140)
    if style == 0:
        lines = wrap(d, text, f, 585)   # riset: <=42 karakter/baris
        y0 = H - 34 - len(lines) * 34
        d.rounded_rectangle([70, y0 - 10, W - 70, H - 26], 12, fill=(5, 8, 14))
        for i, ln in enumerate(lines):
            wdt = d.textlength(ln, font=f)
            d.text(((W - wdt) / 2, y0 + i * 34), ln, font=f, fill=(240, 244, 252))
    elif style == 1:
        fm = font(22)
        for i, ln in enumerate(lines):
            d.text((40, H - 60 - (len(lines) - i) * 28), '> ' + ln, font=fm, fill=(120, 255, 170))
    elif style == 2:
        d.rectangle([0, 14, W, 22 + len(lines) * 32], fill=(4, 26, 26))
        for i, ln in enumerate(lines):
            d.text((40, 26 + i * 32), ln, font=f, fill=(127, 232, 255))
    elif style == 3:
        y0 = H - 40 - (len(lines) - 1) * 34
        words = text.split()
        n = max(1, int(t_in / max(0.01, dur) * len(words)))
        xx, li = 60, 0
        for i, wd in enumerate(words):
            wdt = d.textlength(wd + ' ', font=f)
            if xx + wdt > W - 60:
                li += 1; xx = 60
            d.text((xx, y0 + li * 34), wd + ' ', font=f,
                   fill=(255, 180, 61) if i < n else (235, 239, 248))
            xx += wdt
    elif style == 4:
        fb = font(30)
        for i, ln in enumerate(lines):
            wdt = d.textlength(ln, font=fb)
            x0 = (W - wdt) / 2; y1 = H - 46 - (len(lines) - i) * 40
            for ox in (-2, 0, 2):
                for oy in (-2, 0, 2):
                    d.text((x0 + ox, y1 + oy), ln, font=fb, fill=(0, 0, 0))
            d.text((x0, y1), ln, font=fb, fill=(255, 255, 255))
    else:
        nch = max(1, int(t_in / max(0.01, dur) * len(text)))
        for i, ln in enumerate(wrap(d, text[:nch], f, 520)):
            wdt = d.textlength(ln, font=f)
            d.text((W - 60 - wdt, H - 60 - (len(lines) - i) * 32), ln, font=f, fill=(207, 226, 238))

# ================= LINGKUNGAN & PROPERTI =================
def draw_brand(d, tn, dom, props, vx, door=None):
    """Branding TERTANAM presisi: ukur teks, pusatkan, pasang wajar, zona aman jendela."""
    col = (110, 190, 205) if dom == 'SPACE' else (150, 200, 210)
    fnt = font(13)
    txt = 'DEEP WATCH'
    bb = d.textbbox((0, 0), txt, font=fnt)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    w2, h2 = tw + 16, th + 10

    def plate(x, y, hang=False):
        x = int(max(12, min(x, CW - w2 - 12)))
        if hang:                                          # dua penggantung ke langit-langit
            d.line([(x + 10, 90), (x + 10, y)], fill=(66, 86, 100), width=2)
            d.line([(x + w2 - 10, 90), (x + w2 - 10, y)], fill=(66, 86, 100), width=2)
        d.rectangle([x, y, x + w2, y + h2], fill=(16, 24, 36), outline=(66, 86, 100), width=2)
        d.text((x + 8 - bb[0], y + 5 - bb[1]), txt, fill=col, font=fnt)

    bstyle = tn % 4
    placed = False
    if bstyle == 0 and door is not None:                  # plakat nama, center di atas pintu/hatch
        dx, dy, dw = door
        plate(dx + dw // 2 - w2 // 2, dy - h2 - 6)
        placed = True
    if not placed and bstyle == 1 and 'desk' in props:    # header monitor, rata kiri monitor
        d.text((180 - bb[0], 304 - th - bb[1]), txt, fill=col, font=fnt)
        d.line([(180, 314), (300, 314)], fill=(66, 86, 100), width=2)
        placed = True
    if not placed and bstyle == 2 and 'crates' in props:  # stencil, center di muka krat (font menyesuaikan)
        f2, bb2 = fnt, bb
        if tw > 62:
            f2 = font(9)
            bb2 = d.textbbox((0, 0), txt, font=f2)
        d.text((595 + vx - (bb2[2] - bb2[0]) // 2 - bb2[0], 428 - bb2[1]), txt, fill=(205, 185, 145), font=f2)
        placed = True
    if not placed:                                        # palang dinding tergantung, kiri jendela
        xmax = (600 if dom == 'SPACE' else 660) - w2
        plate(min(120 + (tn * 53) % 460, xmax), 100, hang=True)


def _overlay(im, fn):
    ov = Image.new('RGBA', im.size, (0, 0, 0, 0))
    fn(ImageDraw.Draw(ov))
    im.alpha_composite(ov)

def _lamp_cone(im, x, y):
    def fn(od):
        od.polygon([(x, y - 50), (x + 200, y - 92), (x + 200, y + 10)], fill=(96, 90, 62, 30))
        od.polygon([(x, y - 50), (x + 130, y - 70), (x + 130, y - 8)], fill=(120, 112, 74, 40))
    _overlay(im, fn)

def draw_props(d, props, t, pal, dom, vx, xw=300, pose=None, xb=None):
    if 'gauges' in props:
        for i in range(3):
            cx, cy = 180 + vx + i * 110, 300
            d.ellipse([cx - 36, cy - 36, cx + 36, cy + 36], fill=(16, 22, 34), outline=(86, 96, 116), width=3)
            a = -0.6 + math.sin(t * (0.5 + i * 0.17)) * 0.4 + math.sin(t * 7 + i) * 0.015   # jitter halus
            d.line([(cx, cy), (cx + int(math.cos(a - 1.57) * 28), cy + int(math.sin(a - 1.57) * 28))],
                   fill=(255, 96, 96) if i == 1 else pal[2], width=3)
    if 'wheel' in props or 'spool' in props:
        cx, cy = (xw + 60, 438) if 'wheel' in props else (xw + 80 if pose in ('crank', 'kneel') else 880, 430)
        rr = 34 if 'wheel' in props else 52
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=(160, 170, 186), width=6)
        for i in range(3):
            a = t * (1.2 if 'wheel' in props else 0.5) + i * 2.09
            d.line([(cx, cy), (cx + int(math.cos(a) * rr * 0.9), cy + int(math.sin(a) * rr * 0.9))], fill=(160, 170, 186), width=5)
    if 'hatch' in props:
        d.rectangle([430 + vx, 240, 560 + vx, 470], fill=(22, 28, 42), outline=(86, 96, 116), width=5)
        d.ellipse([470 + vx, 330, 520 + vx, 380], outline=(160, 170, 186), width=5)
        d.rectangle([445 + vx, 255, 545 + vx, 270], fill=pal[2] if int(t) % 4 else (40, 46, 62))
    if 'duct' in props:
        d.rectangle([420 + vx, 300, 640 + vx, 440], fill=(4, 6, 10), outline=(70, 80, 100), width=4)
        for i in range(4):
            d.line([(430 + vx + i * 55, 300), (430 + vx + i * 55, 440)], fill=(26, 32, 46), width=3)
    if 'ladder' in props:
        lx = (xb if xb is not None else xw) - 30 if pose == 'climb' else 700 + vx   # panjat = tangga di tujuan
        for xx in (lx, lx + 60):
            d.line([(xx, 120), (xx, 560)], fill=(110, 120, 140), width=5)
        for i in range(8):
            d.line([(lx, 150 + i * 52), (lx + 60, 150 + i * 52)], fill=(110, 120, 140), width=4)
    if 'crates' in props:
        for (bx, by, bs) in ((560 + vx, 470, 70), (640 + vx, 490, 52), (575 + vx, 405, 48)):
            d.rectangle([bx, by - bs, bx + bs, by], fill=(96, 80, 56), outline=(60, 50, 36), width=3)
    if 'desk' in props:
        d.rectangle([140, 380, 430, 400], fill=(30, 38, 56))
        d.rectangle([160, 400, 180, 470], fill=(24, 30, 46)); d.rectangle([390, 400, 410, 470], fill=(24, 30, 46))
        d.rectangle([180, 320, 300, 380], fill=(10, 16, 26), outline=(70, 80, 100), width=3)
        pts = [(190 + i * 11, 352 + int(math.sin(t * 3 + i * 0.8) * (5 + 9 * abs(math.sin(t * 0.7))))) for i in range(10)]
        for i in range(9):                           # gelombang suara di monitor
            d.line([pts[i], pts[i + 1]], fill=pal[2], width=2)
    if 'galley' in props:
        d.rectangle([150, 400, 420, 420], fill=(34, 42, 60))
        d.rectangle([170, 420, 190, 470], fill=(26, 32, 48)); d.rectangle([380, 420, 400, 470], fill=(26, 32, 48))
        d.ellipse([240, 384, 268, 400], fill=(180, 90, 60)); d.ellipse([320, 386, 344, 400], fill=(120, 140, 90))
    if 'locker' in props:
        for i in range(3):
            d.rectangle([140 + i * 90, 240, 210 + i * 90, 470], fill=(26, 34, 50), outline=(70, 80, 100), width=3)
            d.line([(175 + i * 90, 260), (175 + i * 90, 450)], fill=(46, 54, 74), width=4)
    if 'pipes' in props:
        for i in range(4):
            d.line([(0, 130 + i * 26), (int(CW * 0.52), 130 + i * 26)], fill=(36, 44, 62), width=8)
            d.rectangle([int(CW * 0.2) + i * 60, 122 + i * 26, int(CW * 0.2) + 14 + i * 60, 138 + i * 26], fill=(70, 80, 100))
    if 'reactor' in props:
        d.rectangle([180 + vx, 170, 300 + vx, 470], fill=(20, 26, 40), outline=(80, 90, 110), width=4)
        for i in range(4):
            p2 = 0.5 + 0.5 * math.sin(t * 1.1 + i)
            d.rectangle([195 + vx, 210 + i * 62, 285 + vx, 222 + i * 62],
                        fill=tuple(int(c * (0.4 + 0.6 * p2)) for c in (255, 150, 60)) if i == 1 else pal[2])
        for i in range(3):
            d.line([(185 + vx + i * 40, 452), (205 + vx + i * 40, 470)], fill=(200, 170, 60), width=4)
        d.line([(240 + vx, 170), (240 + vx, 120)], fill=(70, 80, 100), width=6)
    if 'dish' in props:
        mx = 760 + vx
        d.line([(mx, 470), (mx, 240)], fill=(110, 120, 140), width=6)
        a2 = math.sin(t * 0.3) * 0.4
        d.arc([mx - 70, 170, mx + 70, 310], 180 + int(a2 * 57), 360 + int(a2 * 57), fill=(150, 160, 180), width=5)
        d.line([(mx, 240), (mx + int(math.sin(a2) * 40), 194)], fill=(150, 160, 180), width=3)
        if int(t) % 2 == 0:
            d.ellipse([mx - 3, 188, mx + 3, 194], fill=(255, 90, 90))
    if 'wreck' in props:
        d.polygon([(640 + vx, 160), (900 + vx, 200), (880 + vx, 300), (760 + vx, 280), (700 + vx, 330), (640 + vx, 300)],
                  fill=(26, 32, 46), outline=(78, 88, 108))
        for i in range(3):
            d.line([(680 + vx + i * 60, 210 + i * 20), (700 + vx + i * 60, 260 + i * 20)], fill=(60, 70, 90), width=3)
    if 'beacon' in props:
        d.rectangle([420 + vx, 300, 560 + vx, 470], fill=(22, 28, 42), outline=(86, 96, 116), width=4)
        d.ellipse([450 + vx, 210, 530 + vx, 290], fill=(14, 20, 30), outline=(120, 130, 150), width=4)
        d.ellipse([478 + vx, 238, 502 + vx, 262], fill=pal[2])
        for i in range(5):
            d.line([(425 + vx + i * 28, 470), (425 + vx + i * 28, 440)], fill=(70, 80, 100), width=3)
    if 'drums' in props:
        for (bx2, by2) in ((600 + vx, 470), (660 + vx, 470), (630 + vx, 410)):
            d.rectangle([bx2, by2 - 56, bx2 + 44, by2], fill=(70, 90, 70), outline=(40, 56, 40), width=3)
            d.ellipse([bx2 + 12, by2 - 40, bx2 + 32, by2 - 20], fill=(220, 200, 60))
            for a3 in (90, 210, 330):
                d.pieslice([bx2 + 15, by2 - 37, bx2 + 29, by2 - 23], a3 - 25, a3 + 25, fill=(30, 30, 10))
    if 'cockpit' in props:
        d.polygon([(140, 160), (560, 160), (620, 320), (80, 320)], fill=(5, 8, 14), outline=(70, 80, 100), width=4)
        for i in range(12):
            d.point((160 + i * 36, 200 + (i * 53) % 90), fill=(210, 216, 228))
        d.arc([250, 300, 350, 400], 200, 340, fill=(160, 170, 186), width=5)
        d.line([(300, 350), (300, 380)], fill=(160, 170, 186), width=5)
        for i in range(6):
            on = (int(t * 1.2) + i) % 4 != 0
            d.ellipse([420 + i * 26, 300, 432 + i * 26, 312], fill=pal[2] if on else (40, 46, 60))
    if 'vials' in props:
        d.rectangle([180 + vx, 340, 420 + vx, 356], fill=(40, 48, 66))
        for i in range(6):
            g = 0.5 + 0.5 * math.sin(t * 1.4 + i * 1.1)
            d.rounded_rectangle([196 + vx + i * 36, 300, 210 + vx + i * 36, 340], 5,
                                fill=tuple(int(c * (0.35 + 0.65 * g)) for c in (110, 240, 170)))
    if 'carve' in props:
        d.rectangle([430 + vx, 220, 700 + vx, 500], fill=(24, 26, 34), outline=(60, 66, 82), width=4)
        for r2 in range(1, 6):
            d.arc([565 + vx - r2 * 22, 360 - r2 * 22, 565 + vx + r2 * 22, 360 + r2 * 22],
                  0, 360, fill=(90, 100, 126), width=3)
    if 'skin' in props:
        d.line([(430 + vx, 492), (700 + vx, 486)], fill=(120, 116, 100), width=10)
        for i2 in range(8):
            xx2 = 440 + vx + i2 * 32
            d.line([(xx2, 486), (xx2 + 8, 498)], fill=(90, 86, 72), width=3)
    if 'rock' in props:
        d.polygon([(0, 470), (200, 430), (420, 470), (700, 440), (CW, 470), (CW, CH), (0, CH)], fill=(30, 34, 44))
        d.ellipse([520 + vx, 430, 620 + vx, 470], fill=(4, 6, 10), outline=(70, 80, 100), width=3)
        for i in range(3):
            d.line([(540 + vx + i * 24, 442 + i * 6), (560 + vx + i * 24, 452 + i * 6)], fill=pal[2], width=2)
    if 'pods' in props:
        for i in range(3):
            px2 = 180 + vx + i * 110
            d.rounded_rectangle([px2, 220, px2 + 70, 470], 26, fill=(18, 26, 40), outline=(120, 200, 220), width=3)
            if i == 1:
                d.line([(px2 + 70, 230), (px2 + 108, 190)], fill=(120, 200, 220), width=4)
                d.rounded_rectangle([px2 + 8, 240, px2 + 62, 450], 20, fill=(6, 8, 12))
            else:
                d.rounded_rectangle([px2 + 12, 250, px2 + 58, 440], 18, fill=(40, 70, 90))
    if 'tank' in props:
        d.rounded_rectangle([640 + vx, 180, 780 + vx, 470], 40, fill=(28, 36, 52), outline=(80, 90, 110), width=4)
        lv = 0.5 + 0.2 * math.sin(t * 0.15)
        d.rectangle([700 + vx, 200, 712 + vx, 450], fill=(10, 14, 22), outline=(70, 80, 100))
        d.rectangle([700 + vx, 200 + int(250 * (1 - lv)), 712 + vx, 450], fill=pal[2])
    if 'decon' in props:
        d.rectangle([430 + vx, 200, 450 + vx, 470], fill=(40, 48, 66)); d.rectangle([640 + vx, 200, 660 + vx, 470], fill=(40, 48, 66))
        d.rectangle([430 + vx, 190, 660 + vx, 210], fill=(40, 48, 66))
        for i in range(6):
            d.line([(455 + vx + i * 34, 210), (455 + vx + i * 34, 240 + (i % 2) * 8)], fill=(120, 200, 220), width=2)
    if 'claw' in props:
        cy2 = 240 + int(60 * (0.5 + 0.5 * math.sin(t * 0.5)))
        d.line([(700 + vx, 90), (700 + vx, cy2)], fill=(150, 160, 175), width=3)
        op2 = 0.5 + 0.5 * math.sin(t * 0.5 + 1.2)
        for sgn in (-1, 0, 1):
            d.line([(700 + vx, cy2), (700 + vx + sgn * int(18 + 14 * op2), cy2 + 40)], fill=(150, 160, 175), width=4)
        d.rectangle([688 + vx, cy2 + 44, 712 + vx, cy2 + 62], fill=(96, 104, 120))
    if 'o2' in props:
        for i in range(2):
            d.rounded_rectangle([180 + vx + i * 46, 260, 214 + vx + i * 46, 470], 16, fill=(60, 80, 100), outline=(90, 110, 130), width=3)
            d.ellipse([188 + vx + i * 46, 240, 206 + vx + i * 46, 258], fill=(90, 110, 130))
        d.arc([214 + vx, 300, 300 + vx, 380], 0, 90, fill=(150, 160, 175), width=3)
    if 'hole' in props:
        d.ellipse([520 + vx, 440, 660 + vx, 480], fill=(4, 6, 10), outline=(70, 80, 100), width=3)
        d.line([(520 + vx, 440), (520 + vx, 410)], fill=(150, 160, 175), width=3)
        d.polygon([(520 + vx, 410), (548 + vx, 418), (520 + vx, 426)], fill=(220, 80, 80))
    if 'gear' in props:
        gx, gy = 700 + vx, 400
        d.ellipse([gx - 60, gy - 60, gx + 60, gy + 60], fill=(20, 26, 38), outline=(120, 130, 150), width=6)
        d.ellipse([gx - 20, gy - 20, gx + 20, gy + 20], outline=(120, 130, 150), width=4)
        d.line([(gx - 60, gy), (gx - 110, gy - 80)], fill=(110, 120, 140), width=8)
        pst = int(math.sin(t * 0.8) * 6)
        d.line([(gx + 30, gy - 40), (gx + 60, gy - 90 + pst)], fill=(160, 170, 186), width=5)
    if 'chamber' in props:                                    # dekompresi chamber
        d.rectangle([160 + vx, 220, 430 + vx, 470], fill=(26, 34, 50), outline=(86, 96, 116), width=4)
        d.ellipse([200 + vx, 280, 260 + vx, 340], outline=(160, 170, 186), width=5)
        d.rectangle([300 + vx, 380, 380 + vx, 410], fill=(40, 48, 66))       # bunk
        d.rectangle([300 + vx, 330, 380 + vx, 360], fill=(40, 48, 66))
        for i in range(3):
            on = (int(t * 1.4) + i) % 3 == 0
            d.ellipse([300 + vx + i * 30, 250, 312 + vx + i * 30, 262], fill=pal[2] if on else (40, 46, 60))
    if 'turbine' in props:
        gx, gy = 720 + vx, 320
        d.ellipse([gx - 80, gy - 80, gx + 80, gy + 80], outline=(120, 132, 150), width=6)
        for i in range(3):
            a = t * 1.5 + i * 2.09
            d.line([(gx, gy), (gx + int(math.cos(a) * 72), gy + int(math.sin(a) * 72))], fill=(120, 132, 150), width=7)
        for i in range(4):                                    # jaring organik membelit
            d.arc([gx - 90 + i * 8, gy - 90 + i * 8, gx + 90 - i * 8, gy + 90 - i * 8], 40 + i * 20, 140 + i * 20,
                  fill=(90, 60, 70), width=3)
    if 'kelp' in props:
        for i in range(6):
            kx = 120 + vx + i * 150
            pts = [(kx, 560)]
            for s2 in range(1, 8):
                pts.append((kx + int(math.sin(t * 0.7 + i + s2 * 0.7) * 14 * s2 / 7), 560 - s2 * 55))
            for s2 in range(7):
                d.line([pts[s2], pts[s2 + 1]], fill=(40, 90, 80), width=max(2, 7 - s2))
    if 'cave' in props:
        d.polygon([(0, 0), (CW, 0), (CW, 140), (760, 90), (520, 160), (300, 80), (120, 150), (0, 110)], fill=(6, 9, 14))
        d.polygon([(0, CH), (0, 420), (200, 470), (480, 430), (760, 480), (CW, 440), (CW, CH)], fill=(6, 9, 14))
        for i in range(5):                                    # ukiran kuno
            d.arc([180 + vx + i * 130, 60, 220 + vx + i * 130, 100], 0, 300, fill=(70, 110, 120), width=2)
    if 'buoy' in props:
        by2 = 200 + int(math.sin(t * 0.9) * 6)
        d.polygon([(680 + vx, by2), (740 + vx, by2), (726 + vx, by2 + 60), (694 + vx, by2 + 60)], fill=(180, 90, 60), outline=(110, 60, 40))
        d.line([(710 + vx, by2), (710 + vx, by2 - 46)], fill=(150, 160, 175), width=3)
        if int(t * 1.2) % 2 == 0:
            d.ellipse([706 + vx, by2 - 54, 714 + vx, by2 - 46], fill=(255, 220, 90))
        d.line([(710 + vx, by2 + 60), (710 + vx, 560)], fill=(90, 100, 120), width=2)
    if 'chain' in props:
        for i in range(6):
            cy2 = 100 + i * 80 + int(math.sin(t * 0.5) * 4)
            d.ellipse([680 + vx - 16, cy2, 680 + vx + 16, cy2 + 52], outline=(110, 120, 140), width=8)
    if 'ice' in props:
        d.polygon([(0, 0), (CW, 0), (CW, 120), (820, 180), (600, 110), (380, 190), (160, 120), (0, 170)], fill=(150, 190, 210))
        for i in range(4):
            d.line([(200 + i * 220, 40), (240 + i * 220, 130)], fill=(110, 150, 175), width=3)
        if int(t * 3) % 5 == 0:                               # ketukan morse
            d.ellipse([500 + vx, 200, 512 + vx, 212], fill=(255, 240, 180))
    if 'gate' in props:
        d.rectangle([430 + vx, 220, 640 + vx, 470], fill=(52, 56, 60), outline=(90, 96, 104), width=6)
        d.rectangle([470 + vx, 260, 600 + vx, 470], fill=(30, 34, 40), outline=(120, 128, 138), width=4)
        for i in range(4):
            d.line([(475 + vx + i * 32, 452), (495 + vx + i * 32, 470)], fill=(200, 170, 60), width=4)
    if 'artifact' in props:
        for i in range(4):                                    # ribs bangkai kapal kayu
            d.arc([520 + vx + i * 50, 330, 600 + vx + i * 50, 470], 180, 360, fill=(96, 76, 52), width=6)
        d.ellipse([470 + vx, 440, 500 + vx, 470], fill=(150, 120, 80), outline=(90, 70, 46), width=3)

def draw_env_space(im, d, t, pal, rng):
    for y in range(0, CH, 4):
        k = y / CH
        d.line([(0, y), (CW, y)], fill=(int(20 + 12 * k), int(24 + 9 * k), int(34 + 11 * k)))
    d.rectangle([0, 0, CW, 90], fill=(24, 29, 42)); d.rectangle([0, CH - 70, CW, CH], fill=(24, 29, 42))
    for i in range(6):
        on = int(t * 0.8 + i * 0.7) % 5 != 0           # lampu berdenyut pelan (secondary)
        d.rectangle([80 + i * 180, 92, 120 + i * 180, 100], fill=(66, 76, 98) if on else (44, 50, 66))
    d.line([(0, 560), (CW, 560)], fill=(46, 54, 74), width=3)

def draw_env_sea(im, d, t, pal, rng):
    for y in range(0, CH, 4):
        k = y / CH
        d.line([(0, y), (CW, y)], fill=(int(14 + 26 * (1 - k)), int(26 + 40 * (1 - k)), int(36 + 46 * (1 - k))))
    for i in range(3):
        x0 = rng.randrange(100, 900)
        sway = math.sin(t * 0.3 + i) * 12               # berkas cahaya berayap pelan
        d.polygon([(x0, 0), (x0 + 110, 0), (x0 + 260 + sway, CH), (x0 + 80 + sway, CH)], fill=(26, 52, 64))
    d.rectangle([0, CH - 90, CW, CH], fill=(14, 20, 28))
    d.line([(0, 560), (CW, 560)], fill=(50, 64, 82), width=3)

def _win_space(im, d, t, pal, rng, creature_draw):
    wx0, wy0, wx1, wy1 = int(CW * 0.55), 110, int(CW * 0.95), 330
    win = Image.new('RGB', (wx1 - wx0, wy1 - wy0), (4, 6, 12))
    wd = ImageDraw.Draw(win)
    for _ in range(40):
        wd.point((rng.randrange(4, win.width - 4), rng.randrange(4, win.height - 4)), fill=(210, 216, 228))
    px, py = rng.randrange(60, win.width - 40), rng.randrange(90, win.height + 40)
    wd.ellipse([px - 90, py - 60, px + 90, py + 120], fill=pal[1])
    wd.arc([px - 90, py - 60, px + 90, py + 120], 190, 340, fill=pal[2], width=3)
    if creature_draw:
        creature_draw(wd, win)
    im.paste(win, (wx0, wy0))
    d.rectangle([wx0, wy0, wx1, wy1], outline=(56, 66, 88), width=6)
    d.line([(wx0 + (wx1 - wx0) // 2, wy0), (wx0 + (wx1 - wx0) // 2, wy1)], fill=(40, 48, 68), width=4)

def _win_sea(im, d, t, pal, rng, creature_draw):
    px0, py0, px1, py1 = int(CW * 0.6), 120, int(CW * 0.95), 400
    win = Image.new('RGB', (px1 - px0, py1 - py0), (6, 14, 22))
    wd = ImageDraw.Draw(win)
    for _ in range(26):
        wd.point((rng.randrange(4, win.width - 4), rng.randrange(4, win.height - 4)), fill=(150, 190, 210))
    if creature_draw:
        creature_draw(wd, win)
    mask = Image.new('L', win.size, 0)
    ImageDraw.Draw(mask).ellipse([0, 0, win.width, win.height], fill=255)
    im.paste(win, (px0, py0), mask)
    d.ellipse([px0, py0, px1, py1], outline=(58, 72, 92), width=10)

# ================= KAPAL / STASIUN (bentuk unik per episode) =================
_SHIP = {}

def ship_params(tn, dom):
    key = (tn, dom)
    if key in _SHIP:
        return _SHIP[key]
    rng = random.Random(tn * 911 + (7 if dom == 'SPACE' else 13))
    if dom == 'SPACE':
        P = dict(L=rng.randrange(560, 820), H=rng.randrange(64, 96),
                 mods=rng.randrange(2, 5), ring=rng.random() < 0.5,
                 mast=rng.randrange(1, 4), winn=rng.randrange(7, 13),
                 eng=rng.randrange(2, 5))
    else:
        P = dict(L=rng.randrange(520, 760), H=rng.randrange(70, 105),
                 sail=rng.uniform(0.30, 0.55), sailh=rng.randrange(50, 85),
                 winn=rng.randrange(3, 6))
    _SHIP[key] = P
    return P

def _hull_pts(x0, L, yc, H, mods, tail=0.8):
    pts, N = [], 24
    for k in range(N + 1):
        s = k / N
        hh = H / 2 * math.sin(math.pi * min(1.0, 0.10 + s * 0.94)) ** 0.7
        for m in range(mods):
            c = (m + 1) / (mods + 1)
            hh += 9 * math.exp(-((s - c) * 9) ** 2)
        pts.append((x0 + s * L, yc - hh))
    for k in range(N, -1, -1):
        s = k / N
        hh = H / 2 * tail * math.sin(math.pi * min(1.0, 0.10 + s * 0.94)) ** 0.7
        pts.append((x0 + s * L, yc + hh + 4))
    return pts

def draw_ext_space(im, d, t, pal, rng, tn, Pc, appear):
    P = ship_params(tn, 'SPACE')
    accent = pal[2]
    x0 = CW // 2 - P['L'] // 2 + int(math.sin(t * 0.11) * 10)
    yc = 300 + int(math.sin(t * 0.2) * 6)
    d.polygon(_hull_pts(x0, P['L'], yc, P['H'], P['mods']), fill=(30, 36, 50), outline=(78, 88, 108))
    hb = d.textbbox((0, 0), 'DSV DEEP WATCH', font=font(12))
    d.text((x0 + P['L'] // 2 - (hb[2] - hb[0]) // 2, yc + 8), 'DSV DEEP WATCH',
           fill=(150, 170, 195), font=font(12))                      # nama lambung, center
    d.line([(x0 + P['L'] - 34, yc), (x0 + P['L'], yc)], fill=accent, width=3)
    for i in range(P['winn']):
        wx = x0 + int(P['L'] * 0.18) + i * int(P['L'] * 0.55 / P['winn'])
        on = (int(t * 0.6) + i) % 9 != 0
        d.rectangle([wx, yc - 4, wx + 10, yc + 4], fill=accent if on else (40, 46, 60))
    for e in range(P['eng']):
        ey = yc - 14 + e * int(28 / max(1, P['eng'] - 1)) if P['eng'] > 1 else yc
        fl = 0.7 + 0.3 * math.sin(t * 6 + e)
        d.ellipse([x0 - 26 - int(6 * fl), ey - 6, x0 - 2, ey + 6],
                  fill=(int(60 * fl) + 30, int(40 * fl) + 20, 20))
    if P['ring']:
        rx = x0 + int(P['L'] * 0.72)
        d.ellipse([rx - 10, yc - 70, rx + 10, yc + 70], outline=(90, 100, 120), width=4)
    for m in range(P['mast']):
        mx = x0 + int(P['L'] * (0.25 + 0.2 * m))
        d.line([(mx, yc - P['H'] // 2), (mx, yc - P['H'] // 2 - 34)], fill=(110, 120, 140), width=3)
        if int(t * 0.8 + m) % 3 == 0:
            d.ellipse([mx - 3, yc - P['H'] // 2 - 40, mx + 3, yc - P['H'] // 2 - 34], fill=(255, 90, 90))
    wx2, wy2 = x0 + int(P['L'] * 0.42), yc - P['H'] // 2 - 46      # EVA kecil + tether
    d.line([(wx2, wy2 + 20), (wx2 + 24, yc - P['H'] // 2 + 4)], fill=(150, 160, 175), width=2)
    draw_worker(d, wx2, wy2, 58, 'float', t, 'SPACE', accent)
    if appear > 0.05:
        draw_creature(d, CW - 120 - int(50 * appear), 130, Pc, t, 0.08 + 0.10 * appear, accent)

def draw_ext_sea(im, d, t, pal, rng, tn, Pc, appear):
    P = ship_params(tn, 'SEA')
    accent = pal[2]
    x0 = CW // 2 - P['L'] // 2 + int(math.sin(t * 0.1) * 8)
    yc = 330 + int(math.sin(t * 0.25) * 5)
    d.polygon(_hull_pts(x0, P['L'], yc, P['H'], 0, tail=0.7), fill=(24, 34, 46), outline=(70, 86, 104))
    hb = d.textbbox((0, 0), 'DSV DEEP WATCH', font=font(12))
    d.text((x0 + P['L'] // 2 - (hb[2] - hb[0]) // 2, yc + 6), 'DSV DEEP WATCH',
           fill=(150, 180, 200), font=font(12))                           # nama lambung, center
    sx = x0 + int(P['L'] * P['sail'])
    d.rectangle([sx, yc - P['H'] // 2 - P['sailh'], sx + 64, yc - P['H'] // 2 + 6],
                fill=(24, 34, 46), outline=(70, 86, 104), width=3)
    d.line([(sx + 32, yc - P['H'] // 2 - P['sailh']), (sx + 32, yc - P['H'] // 2 - P['sailh'] - 26)],
           fill=(110, 120, 140), width=3)
    if int(t * 0.8) % 3 == 0:
        d.ellipse([sx + 29, yc - P['H'] // 2 - P['sailh'] - 32, sx + 35, yc - P['H'] // 2 - P['sailh'] - 26],
                  fill=(255, 90, 90))
    bx = x0 - 6
    for i in range(3):
        a = t * 4 + i * 2.09
        d.line([(bx, yc), (bx - int(math.cos(a) * 16), yc + int(math.sin(a) * 16))], fill=(120, 132, 150), width=4)
    for i in range(5):
        by = (rng.randrange(200, 500) - int(t * 30)) % 400 + 120
        d.ellipse([x0 - 30 + (i * 13) % 26, by, x0 - 26 + (i * 13) % 26, by + 5], outline=(150, 190, 210))
    for i in range(P['winn']):
        px = x0 + int(P['L'] * 0.2) + i * int(P['L'] * 0.5 / P['winn'])
        d.ellipse([px - 9, yc - 9, px + 9, yc + 9], fill=(196, 176, 120), outline=(70, 86, 104), width=2)
        if i == 1:                                                # siluet kecil di porthole: "itu aku"
            d.line([(px - 2, yc - 4), (px - 2, yc + 3)], fill=(30, 26, 18), width=2)
            d.ellipse([px - 4, yc - 8, px, yc - 4], fill=(30, 26, 18))
            d.line([(px - 2, yc + 3), (px - 5, yc + 7)], fill=(30, 26, 18), width=2)
            d.line([(px - 2, yc + 3), (px + 1, yc + 7)], fill=(30, 26, 18), width=2)
    for i in range(3):                                            # gelang sonar dari haluan
        r = (int(t * 30) + i * 80) % 260
        c = max(20, 90 - r // 3)
        d.ellipse([x0 + P['L'] - r, yc - r, x0 + P['L'] + r, yc + r], outline=(c // 2, c, c + 20), width=2)
    if appear > 0.05:
        draw_creature(d, 140 + int(40 * appear), 140, Pc, t, 0.08 + 0.10 * appear, accent)

# ================= KAMERA (shot grammar + ease) =================
def cam_crop(shot, cam, t, sub_t, rng, xw=None):
    zT = {'wide': 1.06, 'medium': 1.22, 'close': 1.5, 'estab': 1.02}.get(shot, 1.14)
    z = 1.0 + (zT - 1.0) * ease_out_cubic(min(1.0, sub_t / 1.2))   # zoom ease, tanpa snap
    cw, ch = int(CW / z), int(CH / z)
    if xw is not None and shot in ('close', 'medium'):              # kamera mengikuti karakter
        cx = xw + 40; cy = 396 if shot == 'close' else 420
    else:
        cx = CW / 2 + rng.randrange(-40, 40); cy = CH / 2 + rng.randrange(-20, 20)
        if cam in ('pan', 'sweep'):
            cx += math.sin(t * 0.25) * CW * 0.03                    # drift pelan, bukan guncangan
        elif cam == 'tilt':
            cy += math.sin(t * 0.3) * CH * 0.04
    x0 = max(0, min(CW - cw, int(cx) - cw // 2)); y0 = max(0, min(CH - ch, int(cy) - ch // 2))
    return x0, y0, cw, ch

# ================= CROSSFADE ANTAR ADEGAN =================
_XF = {'scene': -1, 'frame': None}
XFADE = 0.9

def reset_xfade():
    _XF['scene'] = -1
    _XF['frame'] = None            # _ROWS/_LOC sudah di-reset via reset_scene_state()
    hworld.world_reset()

# ============ KANVAS MARATHON v4: satu take panjang, dunia ditarik ke kiri ============
# Tiap kalimat = satu panel ruangan di kanvas panjang; kamera meluncur antar panel
# (lewat pintu bulkhead) -> transisi spasial, TANPA lompatan frame.
_BEATS = []

def set_beats(beats):
    global _BEATS
    _BEATS = beats

def get_loc():
    return _LOC[0]

def _beat_at(t):
    for i, bt in enumerate(_BEATS):
        if t < bt['b']:
            return i
    return max(0, len(_BEATS) - 1)

def _cam_x(t):
    i = _beat_at(t)
    bt = _BEATS[i]
    row = get_row(bt['row'])
    travel = row[3] == 'walk' or row[1] in ('walk', 'run', 'crawl')
    fr = 0.8 if travel else 0.45                    # porsi meluncur di dalam beat
    dur = max(0.01, bt['b'] - bt['a'])
    k = min(1.0, max(0.0, (t - bt['a']) / (dur * fr)))
    prev = (i - 1) * CW if i > 0 else 0.0
    return prev + (i * CW - prev) * ease_io_sine(k)

def _room_img(j, tn, dom, pal, t, seed):
    bt = _BEATS[j]
    row = get_row(bt['row'])
    keys, poseA, poseB, act, cst, fx, cam, shot, props = row[:9]
    var = (tn * 13 + j * 7) % 24
    rng = random.Random(seed + j * 97 + var * 13)
    im = Image.new('RGBA', (CW, CH))
    d = ImageDraw.Draw(im)
    (draw_env_space if dom == 'SPACE' else draw_env_sea)(im, d, t, pal, rng)
    vx = rng.randrange(-30, 46)
    if fx == 'glow':
        d.ellipse([150, 280, 330, 400], fill=(20, 30, 44))
    draw_props(d, props, t, pal, dom, vx, 360, poseA, 430)
    def nocreat(wd, win):
        pass
    if dom == 'SPACE':
        _win_space(im, d, t, pal, rng, nocreat)
    else:
        _win_sea(im, d, t, pal, rng, nocreat)
    draw_brand(d, tn, dom, props, vx, None)
    for ex in (0, CW - 26):                          # pintu bulkhead = sambungan antar ruangan
        d.rectangle([ex, 96, ex + 26, CH], fill=(14, 18, 28), outline=(70, 80, 100), width=3)
        d.rectangle([ex + 8, 300, ex + 18, 500], fill=(26, 34, 50))
    return im

# ---- r26: lapisan properti naratif -- benda yang DISEBUT narasi ikut tergambar ----
def _narr_props(im, d, low, xw, t, pal):
    if 'checklist' in low or 'clipboard' in low or 'manifest' in low or 'log says' in low:
        d.rectangle([xw - 14, 372, xw + 6, 398], fill=(210, 214, 220), outline=(90, 96, 110))
        for yy in range(3):
            d.line([(xw - 10, 378 + yy * 6), (xw + 2, 378 + yy * 6)], fill=(70, 76, 92), width=1)
    if 'borescope' in low or 'multitool' in low or 'probe' in low:
        d.line([(xw + 16, 396), (xw + 46, 388)], fill=(160, 170, 185), width=3)
        d.ellipse([xw + 44, 382, xw + 56, 394], outline=(190, 200, 215), width=2)
    if 'bagged' in low or 'sample' in low or 'vial' in low:
        d.rectangle([xw + 20, 402, xw + 34, 420], fill=(180, 200, 210), outline=(150, 170, 185))
    if 'glove' in low:
        d.line([(xw + 138, 298), (xw + 196, 298)], fill=(90, 96, 110), width=3)
        for k in range(2):
            gx = xw + 150 + k * 22
            d.line([(gx, 300), (gx, 322)], fill=(190, 196, 208), width=5)
            d.ellipse([gx - 4, 320, gx + 4, 330], fill=(190, 196, 208))
    if 'camera' in low or 'footage' in low:
        d.rectangle([xw + 170, 208, xw + 194, 224], fill=(30, 36, 50), outline=(90, 100, 120), width=2)
        d.ellipse([xw + 188, 212, xw + 193, 217], fill=(255, 90, 90) if math.sin(t * 2.0) > 0.4 else (90, 40, 40))
    if 'panel' in low:
        d.rectangle([xw + 140, 258, xw + 190, 292], fill=(22, 28, 42), outline=(86, 96, 116), width=2)
        for k in range(3):
            d.ellipse([xw + 148 + k * 14, 268, xw + 154 + k * 14, 274], fill=pal[2] if k != 1 else (255, 200, 90))
    if 'dust' in low:
        for k in range(10):
            dx = (xw - 120 + k * 37 + int(t * 6)) % 900 + 30
            dy = 180 + (k * 53) % 220 + int(math.sin(t + k) * 4)
            d.point((dx, dy), fill=(170, 178, 190))
    if 'prints' in low or 'footprint' in low:
        for k in range(4):
            px = xw - 60 - k * 46
            d.ellipse([px, 466, px + 16, 472], fill=(60, 66, 80))
            d.ellipse([px + 5, 474, px + 15, 478], fill=(52, 58, 72))
    if 'piling' in low:
        d.rectangle([xw + 210, 120, xw + 238, 470], fill=(40, 46, 60), outline=(70, 78, 96), width=2)
        d.line([(xw + 210, 200), (xw + 238, 210)], fill=(70, 78, 96), width=2)
    if 'growth' in low or 'coral' in low:
        for k in range(5):
            gx = xw + 190 + (k % 3) * 16
            gy = 430 - (k // 3) * 14
            d.ellipse([gx, gy, gx + 14, gy + 12], fill=(70, 90, 100), outline=(110, 140, 150))
    if 'seam' in low:
        d.line([(xw + 150, 386), (xw + 260, 386)], fill=(255, 150, 80), width=2)
        d.line([(xw + 150, 388), (xw + 260, 388)], fill=(120, 60, 40), width=1)

def _scene_frame(tn, dom, pal, sil, t, scene_i, seed, var, sub_t, sub_dur):
    i = _beat_at(min(t, _BEATS[-1]['b'] - 0.001)) if _BEATS else scene_i
    bt = _BEATS[i] if _BEATS else {'a': 0, 'b': 9, 'row': scene_i}
    row = get_row(bt['row'])
    keys, poseA, poseB, act, cst, fx, cam, shot, props = row[:9]
    buddy = row[9] if len(row) > 9 else 0
    rng = random.Random(seed + i * 97 + var * 13)
    P = creature_params(tn * 31 + var, sil)
    accent = pal[2]
    im = Image.new('RGBA', (CW, CH))

    if 'ext' in props:                               # establishing shot tetap tersendiri
        d = ImageDraw.Draw(im)
        ap = ease_out_cubic(min(1.0, sub_t / 1.2))
        (draw_ext_space if dom == 'SPACE' else draw_ext_sea)(im, d, t, pal, rng, tn, P, ap)
        x0c, y0c, cw, ch = cam_crop(shot, cam, t, sub_t, rng)
        return im.crop((x0c, y0c, x0c + cw, y0c + ch)).resize((W, H), Image.Resampling.LANCZOS)

    cx = _cam_x(t)                                   # kanvas panjang ditarik ke kiri
    j0 = int(math.floor(cx / CW))
    for j in (j0, j0 + 1):
        if 0 <= j < len(_BEATS):
            im.paste(_room_img(j, tn, dom, pal, t, seed), (j * CW - int(cx), 0))
    d = ImageDraw.Draw(im)
    xw = 360                                         # karakter selalu di depan, dunia lewat
    appear = ease_out_cubic(min(1.0, sub_t / 1.2))

    if fx == 'lamp':
        _lamp_cone(im, xw + 30, 430)
    if poseA == 'crawl' and 'duct' in props:
        _lamp_cone(im, xw + 44, 452)

    face = -1 if ('desk' in props or ('gauges' in props and xw > 420)) else 1
    headset = poseA == 'radio' or (poseA == 'sit' and 'desk' in props)
    if sub_t < 0.35:
        poses = [poseA, poseB, ease_io_sine(sub_t / 0.35)]
    else:
        poses = [poseA]
    draw_worker_blend(im, xw, 470, 120, poses, t, dom, accent, face=face, headset=headset)
    if poseA == 'sit':
        d.rectangle([xw - 20, 474, xw + 16, 482], fill=(40, 48, 66))
        d.line([(xw - 16, 482), (xw - 16, 512)], fill=(40, 48, 66), width=4)
        d.line([(xw + 12, 482), (xw + 12, 512)], fill=(40, 48, 66), width=4)
    elif poseA == 'lie':
        d.rectangle([xw - 70, 476, xw + 80, 486], fill=(40, 48, 66))
        d.line([(xw - 62, 486), (xw - 62, 512)], fill=(40, 48, 66), width=4)
        d.line([(xw + 70, 486), (xw + 70, 512)], fill=(40, 48, 66), width=4)
    elif poseA == 'lever':
        d.rectangle([xw + 26, 430, xw + 66, 510], fill=(30, 38, 56), outline=(70, 80, 100), width=3)
    if poseA == 'talk':
        draw_worker(ImageDraw.Draw(im), xw + 170, 470, 116, 'stand', t + 1.3, dom, accent,
                    suit=(160, 170, 186) if dom == 'SPACE' else (150, 160, 120))
    if buddy and poseA != 'talk':
        draw_worker(ImageDraw.Draw(im), min(xw + 190, 760), 470, 116, 'talk', t + 0.7, dom, accent,
                    suit=(160, 170, 186) if dom == 'SPACE' else (150, 160, 120), face=-1)
    if poseA == 'run':
        for i2 in range(4):
            ly = 402 + i2 * 22
            d.line([(xw - 55 - i2 * 16, ly), (xw - 115 - i2 * 16, ly)], fill=(88, 96, 116), width=2)
    if cst in ('approach', 'attack'):                # makhluk menyusul dari kanan kanvas
        sc_ = 0.22 + 0.30 * appear
        draw_creature(d, CW - 80 - int(70 * appear), 390, P, t, sc_, accent)
    if cst == 'watch':
        ex0, ey0 = (int(CW * 0.72), 210) if dom == 'SPACE' else (int(CW * 0.75), 240)
        bw = P['eyes'] * 26 + 46
        d.ellipse([ex0 - 26, ey0 - 30, ex0 - 26 + bw, ey0 + 44], fill=(16, 22, 34), outline=(52, 62, 82), width=2)
        if int(t * 0.5) % 7 != 5:
            _overlay(im, lambda od: od.ellipse([ex0 - 40, ey0 - 44, ex0 - 40 + bw + 28, ey0 + 58],
                                               fill=(40, 110, 170, 46)))
            for k2 in range(P['eyes']):
                d.ellipse([ex0 + k2 * 26, ey0 + (k2 % 2) * 14, ex0 + k2 * 26 + 6, ey0 + (k2 % 2) * 14 + 6],
                          fill=(120, 205, 245))

    if fx == 'dip':
        _overlay(im, lambda od: od.rectangle([0, 0, CW, CH], fill=(8, 10, 16, 120)))
    elif fx == 'alarm':
        p = (math.sin(t * 1.2) + 1) / 2
        d.rectangle([0, 0, CW, CH], fill=(int(24 * p), 4, 8))
    elif fx == 'flare':
        fxp, fyp = min(xw + 210, 780), 428
        def fl(od):
            for rr2, al in ((40, 40), (24, 80), (11, 160)):
                od.ellipse([fxp - rr2, fyp - rr2, fxp + rr2, fyp + rr2], fill=(255, 240, 200, al))
            for a6 in range(6):
                aa = a6 * 1.047 + t * 0.4
                od.line([(fxp, fyp), (fxp + int(math.cos(aa) * 52), fyp + int(math.sin(aa) * 52))],
                        fill=(255, 236, 190, 90), width=2)
        _overlay(im, fl)
    elif fx == 'spark':
        n_sp = max(2, int(10 * (0.5 + 0.5 * math.sin(t * 3))))
        for _ in range(n_sp):
            d.line([(xw + 60, 420), (xw + 60 + rng.randrange(-20, 26), 420 + rng.randrange(-14, 12))],
                   fill=(255, rng.randrange(150, 220), 70), width=1)
    elif fx == 'dust':
        for k2 in range(24):
            dx = (rng.randrange(CW) + int(t * 8 * (1 + k2 % 3))) % CW
            dy = (rng.randrange(CH) + int(t * 3)) % CH
            d.point((dx, dy), fill=(180, 190, 205))
    elif fx == 'bubble':
        for k2 in range(7):
            bx = CW - 190 + (k2 % 2) * 3
            by = CH + 20 - ((int(t * 30) + k2 * 62) % (CH - 40))
            d.ellipse([bx, by, bx + 6, by + 6], outline=(170, 210, 230))
    elif fx == 'hear':
        sx2, sy2 = (xw + 140, 355) if 'hatch' in props else (int(CW * 0.8), 240)
        for k2 in range(3):
            r2 = (int(t * 40) + k2 * 30) % 90
            c2 = max(30, 110 - r2)
            d.arc([sx2 - r2, sy2 - r2, sx2 + r2, sy2 + r2], -50, 50, fill=(c2, c2 + 30, c2 + 40), width=2)

    if bt.get('txt'):                                  # r26: benda yang disebut narasi ikut tergambar
        _narr_props(im, d, ' ' + bt['txt'].lower() + ' ', xw, t, pal)

    # r25: framing TETAP satu layar penuh -- tanpa zoom-in, tanpa kamera nge-jump ke karakter.
    # Marathon tetap jalan sebagai efek latar (dunia meluncur pelan), kamera diam & kalem.
    return im.resize((W, H), Image.Resampling.LANCZOS)


# ================= FRAME UTAMA =================
def render_frame(tn, dom, pal, sil, t, scene_i, sub_text, sub_t, sub_dur, sub_style, seed):
    wd = hworld.parse_world((sub_text or '').lower(), dom) if sub_text else None
    if wd:                                                 # WORLD LAYER v2: latar mengikuti narasi
        cur = hworld.render_world(tn, dom, pal, sil, t, wd, seed, sub_t, sub_text)
        im = cur.convert('RGB').resize((W, H), Image.Resampling.LANCZOS)   # simpan ukuran FINAL (seragam dgn mesin lama)
        if (_XF['scene'] != scene_i and _XF['frame'] is not None and sub_t < XFADE
                and _XF['frame'].size == im.size):
            im = Image.blend(_XF['frame'].convert('RGB'), im, ease_io_sine(sub_t / XFADE))
        _XF['scene'] = scene_i
        _XF['frame'] = im.copy()
        if (not wd['bubble'] or wd.get('band')) and sub_text:   # band bawah utk aksi & narasi convo
            draw_sub(ImageDraw.Draw(im), sub_text, sub_t, sub_dur, 0, pal[2])
        return im
    var = (tn * 13 + scene_i * 7) % 24                    # 24 varian per arketipe
    cur = _scene_frame(tn, dom, pal, sil, t, scene_i, seed, var, sub_t, sub_dur)
    if not _BEATS and _XF['scene'] != scene_i and _XF['frame'] is not None and sub_t < XFADE:
        im = Image.blend(_XF['frame'].convert('RGB'), cur.convert('RGB'), ease_io_sine(sub_t / XFADE))
    else:
        im = cur.convert('RGB')
    _XF['scene'] = scene_i
    _XF['frame'] = cur.copy()                             # tanpa subtitle -> bebas bayangan teks
    d2 = ImageDraw.Draw(im)
    if sub_text:
        draw_sub(d2, sub_text, sub_t, sub_dur, sub_style, pal[2])
    return im
