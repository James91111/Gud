# -*- coding: utf-8 -*-
"""
horrorstudio.py — DEEP WATCH story engine (port 8809)
Satu halaman: Ide -> Prompt + Template (1000 setting anti-repetitif).
Jalankan: bash studio-deepwatch.sh   ->  http://localhost:8809
"""
import os, sys, re, json, time, random

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import hdeck as hd

DRIVE = os.path.join(BASE, 'drive')
os.makedirs(DRIVE, exist_ok=True)
LOG = os.path.join(DRIVE, 'hlog.json')

from flask import Flask, request, jsonify, send_file, Response
app = Flask(__name__)

def load_log():
    try:
        return json.load(open(LOG, encoding='utf-8'))
    except Exception:
        return {}

def save_log(l):
    json.dump(l, open(LOG, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

def load_base(dom):
    p = os.path.join(BASE, 'Aprompt_deepspace.txt' if dom == 'SPACE' else 'Aprompt_deepsea.txt')
    return open(p, encoding='utf-8').read().strip()

def parse_ideas(text):
    out = []
    for l in text.replace('\r', '').splitlines():
        l = l.strip()
        if not l:
            continue
        l = re.sub(r'^(?:[#>\-*\d.)\s]+)', '', l).strip()
        if l:
            out.append(l)
    return out

def build_prompt(dom, idea, tn, openings):
    base = load_base(dom)
    t = hd.get_template(tn)
    L = ['\n=== INPUT EPISODE INI (WAJIB DIPAKAI, override slot INPUT di atas) ===',
         '[IDE] = %s' % idea,
         '[LOKASI] = %s' % t['worksite'],
         '[GAYA PEMBUKA] = %s' % t['opening'][0],
         '[TIPE ENTITAS] = %s' % t['creature'].split('|')[0],
         '[RULE] = %d' % t['rules'],
         '[JUMLAH BAGIAN] = 4']
    L += ['', hd.concept_block(tn), '', hd.visual_block(tn)]
    L += ['', '=== MYSTERY-FIRST RULES (prioritas tertinggi, menang atas semua default) ===',
          'M1. NEVER fully explain the entity. Show sensory fragments only (a sound, a shadow,',
          '    a wrong number on a gauge); the audience assembles the threat themselves.',
          'M2. Delay every reveal: each Part may answer at most ONE small question and must open',
          '    at least two new ones; the full picture stays incomplete until Part 4.',
          'M3. Plant 3 tiny anomalies in Part 1 (object shifted, sound repeated, count off by one),',
          '    dismissed casually by the narrator; never acknowledged again.',
          'M4. Include two details that subtly contradict each other (log vs memory, gauge vs ear);',
          '    the text never notices the contradiction - readers will.',
          'M5. The narrator doubts their own senses exactly ONCE; never confirm whether the threat',
          '    is supernatural or psychological. Preserve both readings.',
          'M6. Ending: close on an emotional echo plus ONE permanently unanswered question.',
          '    No summary, no moral, no creature explanation. Mystery outlives the video.']
    L += ['', '=== ATURAN ANTI-REPETISI (menang atas default) ===',
          'R1. Do NOT start with any of these previous episode first lines:']
    L += ['    - %s' % o for o in openings[-5:]] if openings else ['    (episode pertama)']
    L += ['R2. Do NOT reuse creature hunting logic or twist from previous episodes;',
          '     the EPISODE SETTINGS above are unique to this episode.',
          'R3. If [IDE] already names its own job or location, keep the idea\'s job/location;',
          '     borrow ONLY creature, hunting logic, stakes, rules, twist and ending cost',
          '     from the EPISODE SETTINGS above.']
    return base + '\n' + '\n'.join(L) + '\n'

@app.get('/')
def index():
    return Response(HTML, mimetype='text/html')

@app.get('/prev/<int:tn>.png')
def prev(tn):
    tn = ((tn - 1) % hd.N_TEMPLATES) + 1
    p = os.path.join(BASE, 'work', 'prev_%04d.png' % tn)     # cache kecil, bukan galeri
    if not os.path.exists(p):
        os.makedirs(os.path.dirname(p), exist_ok=True)
        hd.render_bg(tn).save(p)                             # digambar script, bukan file bawaan
    return send_file(p, mimetype='image/png')

SOUND_EXT = ('.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac')

@app.get('/api/sounds')
def api_sounds():
    sd = os.path.join(BASE, 'sound')
    os.makedirs(sd, exist_ok=True)
    files = sorted(f for f in os.listdir(sd) if f.lower().endswith(SOUND_EXT))
    return jsonify({'files': files})

@app.get('/api/template/<int:tn>')
def api_t(tn):
    t = hd.get_template(tn)
    t['visual_block'] = hd.visual_block(tn)
    t['concept_block'] = hd.concept_block(tn)
    return jsonify(t)

import re as _re
_SEA_W = r'\b(sea|ocean|trench|dive|diver|sub|submersible|depth|sonar|cable|reef|abyss|underwater|fathom|winch|bell|kelp|whale|buoy|manifold|seafloor|hydrophone|aleutian|bermuda|mariana|passage|saturation|decompression|ballast|umbilical|sirena|talvera|mona)\b'
_SPACE_W = r'\b(space|orbit|station|reactor|mars|lunar|saturn|asteroid|vacuum|cradle|beacon|duct|airlock|ship|sector|relay|helium|ceres|crane|ore|foundry|gantry|drydock|kuiper|phobos|enceladus|regolith|greenhouse|scram|tug|hydroponics|dome)\b'

def detect_dom(idea):
    low = idea.lower()
    if _re.search(_SEA_W, low):
        return 'SEA'
    if _re.search(_SPACE_W, low):
        return 'SPACE'
    return None

@app.post('/api/gen')
def gen():
    d = request.get_json(force=True)
    ideas = parse_ideas(d.get('ideas', ''))
    if not ideas:
        return jsonify({'error': 'Tempel minimal 1 ide (satu baris satu ide).'}), 400
    dom = d.get('domain', 'AUTO')
    log = load_log()
    openings = log.get('openings', [])
    used = set(log.get('used', []))
    if len(used) >= hd.N_TEMPLATES:      # satu siklus 1000 habis -> mulai baru
        used = set()
    def next_tn(eff):
        key = 'last_' + eff.lower()
        while True:
            log[key] = log.get(key, 0) + 1
            tn = hd.order(log[key], eff)
            if tn not in used:
                break
        used.add(tn)
        return tn
    eps = []
    for i, idea in enumerate(ideas):
        eff = dom if dom != 'AUTO' else (detect_dom(idea) or 'AUTO')
        tn = next_tn(eff)
        t = hd.get_template(tn)
        eps.append({'no': i + 1, 'tn': tn, 'domain': t['domain'], 'title': idea[:80],
                    'prompt': build_prompt(t['domain'], idea, tn, openings)})
    (d.get('openings') or '').strip() and log.setdefault('openings', [])
    for o in (d.get('openings') or '').splitlines():
        o = o.strip()
        if o and o not in log.get('openings', []):
            log.setdefault('openings', []).append(o)
    log['openings'] = log.get('openings', [])[-20:]
    log['used'] = sorted(used)
    save_log(log)
    return jsonify({'episodes': eps})

import threading
import hvideo

RST = {'busy': False, 'msg': '', 'out': '', 't0': 0, 'el': 0}

@app.post('/api/render')
def api_render():
    if RST['busy']:
        return jsonify({'error': 'Masih ada render berjalan.'}), 400
    d = request.get_json(force=True)
    txt = (d.get('text') or '').strip()
    if not txt:
        return jsonify({'error': 'Tempel naskah narasi dulu.'}), 400
    raw_tn = str(d.get('tn', 'auto')).strip()
    dunia = (d.get('dunia') or 'AUTO').upper()
    log = load_log()
    used = set(log.get('used', []))
    if raw_tn in ('auto', '', '0'):                     # AUTO: nomor berurutan yg belum dipakai
        lo, hi = (1, 500) if dunia == 'SPACE' else (501, 1000) if dunia == 'SEA' else (1, hd.N_TEMPLATES)
        tn = next((n for n in range(lo, hi + 1) if n not in used), None)
        if tn is None:                                  # satu siklus penuh habis -> ngulang dari awal
            used = set(n for n in used if not (lo <= n <= hi))
            tn = lo
    else:
        tn = ((int(raw_tn) - 1) % hd.N_TEMPLATES) + 1
    used.add(tn)
    log['used'] = sorted(used)
    save_log(log)
    sound_name = (d.get('sound') or '').strip()
    try:
        vol = max(0.0, min(1.0, float(d.get('vol', 0.35))))
    except Exception:
        vol = 0.35
    sound = os.path.join(BASE, 'sound', os.path.basename(sound_name)) if sound_name else None
    RST.update(busy=True, msg='TTS + render dimulai...', out='', t0=time.time(), el=0)
    def job():
        try:
            out = hvideo.render_video(txt, tn, sound=sound, vol=vol)
            RST['out'] = os.path.basename(out)
            RST['msg'] = 'SELESAI'
        except Exception as e:
            RST['msg'] = 'ERROR: %s' % e
        RST['el'] = int(time.time() - RST['t0'])
        RST['busy'] = False
    threading.Thread(target=job, daemon=True).start()
    return jsonify({'ok': True, 'tn': tn, 'domain': hd.get_template(tn)['domain']})

@app.get('/api/render/status')
def api_rstat():
    import glob as _g
    _segs = len([f for f in _g.glob(os.path.join(hvideo.BASE, 'work', 'seg_*.mp4')) if os.path.getsize(f) > 4000])
    return jsonify({'busy': RST['busy'], 'msg': RST['msg'], 'segs': _segs,
                    'out': RST['out'], 'prog': hvideo.PROG, 'pct': hvideo.PCT,
                    'log': hvideo.TRACE[-40:],
                    'el': int(time.time() - RST['t0']) if RST['busy'] else RST['el']})

@app.get('/hasil/<name>')
def hasil(name):
    return send_file(os.path.join(BASE, 'hasil', name))

def _dir_size(p):
    tot = 0
    if os.path.isdir(p):
        for root, _, fs in os.walk(p):
            for f in fs:
                try:
                    tot += os.path.getsize(os.path.join(root, f))
                except Exception:
                    pass
    return tot

@app.get('/api/disk')
def api_disk():
    h = os.path.join(BASE, 'hasil'); w = os.path.join(BASE, 'work')
    nvid = len([f for f in os.listdir(h) if f.endswith('.mp4')]) if os.path.isdir(h) else 0
    return jsonify({'hasil': _dir_size(h), 'work': _dir_size(w), 'nvid': nvid})

@app.post('/api/clean')
def api_clean():
    d = request.get_json(force=True)
    what = d.get('what', 'all')
    def rm(p):
        if os.path.isdir(p):
            for f in os.listdir(p):
                fp = os.path.join(p, f)
                if os.path.isfile(fp):
                    try:
                        os.remove(fp)
                    except Exception:
                        pass
    h = os.path.join(BASE, 'hasil'); w = os.path.join(BASE, 'work')
    if what in ('hasil', 'all'):
        rm(h)
    if what in ('work', 'all'):
        rm(w)
    return jsonify({'ok': True})

HTML = r"""<!DOCTYPE html><html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DEEP WATCH — Story Engine</title>
<style>
:root{--bg:#05080F;--card:#0C1220;--ink:#E8EEF9;--dim:#8FA1BF;--acc:#2EE6C8;--red:#FF4D5E;--amber:#FFB43D}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 'Segoe UI',system-ui,Arial}
header{padding:18px 22px;background:linear-gradient(135deg,#0A1020,#05080F);border-bottom:1px solid #1B2740}
h1{margin:0;font-size:22px;letter-spacing:1px}h1 b{color:var(--acc)}
header p{margin:4px 0 0;color:var(--dim);font-size:13px}
main{max-width:980px;margin:20px auto;padding:0 14px}
.card{background:var(--card);border:1px solid #1B2740;border-radius:14px;padding:18px;margin-bottom:16px}
h2{margin:0 0 6px;font-size:17px}.sub{color:var(--dim);font-size:13px;margin-bottom:12px}
textarea,select{width:100%;background:#0A0F1B;color:var(--ink);border:1.5px solid #243352;border-radius:10px;padding:11px;font:inherit}
textarea{min-height:110px;resize:vertical}
.row{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;align-items:center}
.bar{height:10px;background:#101a2c;border-radius:6px;overflow:hidden;margin:8px 0}
#r_bar{height:100%;width:0%;background:linear-gradient(90deg,var(--acc),#7ef0dd);transition:width .6s}
#r_log{background:#070b14;border:1px solid #1B2740;border-radius:10px;padding:10px;height:160px;overflow:auto;font:12px/1.6 Consolas,monospace;color:var(--dim);white-space:pre-wrap;margin:0}
.spin{display:inline-block;width:13px;height:13px;border:2px solid var(--acc);border-top-color:transparent;border-radius:50%;animation:sp 1s linear infinite;vertical-align:-2px}
@keyframes sp{to{transform:rotate(360deg)}}
button{border:none;border-radius:10px;padding:11px 18px;font-weight:800;font-size:14px;cursor:pointer;background:var(--acc);color:#04222B}
button.ghost{background:#16203A;color:var(--ink);border:1px solid #2A3B60}
.chip{background:#16203A;border:1px solid #2A3B60;border-radius:20px;padding:6px 12px;font-size:12.5px;cursor:pointer}
.chip.on{background:var(--amber);color:#241503;border-color:var(--amber);font-weight:800}
img.prev{width:100%;border-radius:10px;border:1px solid #243352}
label{font-size:12.5px;color:var(--dim)}
#q_info{font-size:13px;color:var(--acc)}
</style></head><body>
<header><h1>DEEP <b>WATCH</b> — STORY ENGINE <span style="font-size:11px;color:#2EE6C8;border:1px solid #2EE6C8;border-radius:4px;padding:2px 7px;vertical-align:middle;letter-spacing:1px">ENGINE v2.1 — WORLD LAYER</span></h1>
<p>1000 setting anti-repetitif · 500 deep space + 500 deep sea · prompt asli Anda tetap utuh</p></header>
<main>
<div class="card">
 <h2>1 · Ide → Prompt + Setting</h2>
 <div class="sub">Satu baris = satu ide episode ("welder on cradle 17, something knocks on the hull").
  Sistem memilih setting unik: dunia, profesi, makhluk, stakes, rules, twist, pemeran, dan latar visual.</div>
 <label>Domain</label>
 <select id="dom"><option value="AUTO">AUTO (space & sea bergantian)</option>
  <option value="SPACE">DEEP SPACE saja</option><option value="SEA">DEEP SEA saja</option></select>
 <div class="row"><label style="flex:1">Ide episode (boleh beberapa baris)</label></div>
 <textarea id="idea" placeholder="I'm a reactor duct tech in Sector Nine. Something in the ducts learned my voice."></textarea>
 <div class="row"><label style="flex:1">Kalimat pembuka episode sebelumnya (opsional, jadi daftar larangan)</label></div>
 <textarea id="opens" style="min-height:56px" placeholder="The hum was always half a tone lower at junction nine..."></textarea>
 <div class="row"><button onclick="goGen()">&#10024; Buat Prompt + Setting</button><span id="q_info"></span></div>
 <div id="box" style="display:none">
  <div class="row" id="chips"></div>
  <div class="row">
   <div style="flex:0 0 300px"><img id="prev" class="prev" alt="preview">
    <div class="row"><button class="ghost" onclick="show(QI-1)">&#9664;</button>
     <button class="ghost" onclick="show(QI+1)">&#9654;</button>
     <span id="vt" class="sub" style="margin:0"></span></div></div>
   <div style="flex:1;min-width:260px"><textarea id="pr" style="min-height:260px" readonly></textarea>
    <div class="row"><button onclick="copyP()">&#128203; Salin Prompt</button>
     <button class="ghost" onclick="copyC()">&#127916; Salin Setting+Visual</button></div></div>
  </div>
 </div>
</div>
<div class="card">
 <h2>2 · Render Video Animasi</h2>
 <div class="sub">Tempel naskah jadi (atau uji dengan 2-3 kalimat). Sistem: TTS suara US → subtitle otomatis
  (gaya beda per episode) → scene stickman + monster matematika dipilih dari kata kunci narasi → MP4.</div>
 <label>Naskah narasi</label>
 <textarea id="nsk" placeholder="The hum was half a tone lower at junction nine..."></textarea>
 <div class="row">
  <label class="ghost" style="cursor:pointer;border:1px solid #2A3B60;border-radius:10px;padding:9px 14px;background:#16203A;color:var(--ink)">&#128193; Upload naskah (.txt)
   <input type="file" id="up" accept=".txt,text/plain" style="display:none" onchange="upNsk(this)"></label>
  <span id="up_info" class="sub" style="margin:0"></span>
 </div>
 <div class="row">
  <label style="flex:0 0 160px">Backsound (folder sound/)</label>
  <select id="snd" style="flex:1"><option value="">(tanpa backsound)</option></select>
  <label style="flex:0 0 60px">Volume</label>
  <input id="vol" type="range" min="0" max="100" value="35" style="width:150px" oninput="$('volv').textContent=this.value+'%'">
  <span id="volv" style="color:var(--acc);width:44px">35%</span>
 </div>
 <div class="row"><label style="flex:0 0 160px">Dunia</label>
  <select id="dunia" style="width:100px"><option>AUTO</option><option>SPACE</option><option>SEA</option></select>
  <label style="flex:0 0 130px">Template dunia</label>
  <select id="tno" style="width:270px"><option value="auto">AUTO — lanjut nomor belum dipakai</option></select>
  <button onclick="goRender()">&#127916; Render MP4</button>
   <button class="ghost" onclick="goRender(true)" title="Lanjut dari checkpoint segmen terakhir">&#9203; Lanjutkan checkpoint</button>
   <span id="r_info"></span></div>
 <div id="r_box" style="display:none" class="row"><a id="r_link" href="#" style="color:var(--acc)"></a></div>
 <div id="r_panel" style="display:none" class="row"><div style="flex:1 1 100%">
  <div id="r_stage" style="font-size:13px;color:var(--acc)"></div>
  <div class="bar"><div id="r_bar"></div></div>
  <pre id="r_log"></pre>
 </div></div>
</div>
<div class="card">
 <h2>3 · Penyimpanan & pembersih</h2>
 <div class="sub" id="disk">memuat...</div>
 <div class="row">
  <button class="ghost" onclick="clean('hasil')">&#128465; Hapus video lama (hasil/)</button>
  <button class="ghost" onclick="clean('work')">&#128465; Hapus berkas kerja (work/)</button>
  <button class="ghost" onclick="clean('all')">&#9888; Bersihkan keduanya</button>
 </div>
</div>
<div class="card"><div class="sub">Alur lengkap: Langkah 1 salin prompt → tempel ke chat AI → kirim 2/3/4 →
 naskah 12.000 kata → Langkah 2 render (atau upload .txt). Template berikutnya otomatis berbeda di SEMUA dimensi.</div></div>
</main>
<script>
const $=id=>document.getElementById(id);
let Q=[],QI=0;
(function(){const s=$('tno');const g1=document.createElement('optgroup');g1.label='SPACE (1-500)';
 const g2=document.createElement('optgroup');g2.label='SEA (501-1000)';
 for(let i=1;i<=1000;i++){const o=document.createElement('option');o.value=i;
  o.textContent='HD-'+String(i).padStart(4,'0')+(i<=500?' · space':' · sea');(i<=500?g1:g2).appendChild(o);}
 s.appendChild(g1);s.appendChild(g2);
 s.onchange=()=>{if(s.value!=='auto'&&$('prev'))$('prev').src='/prev/'+s.value+'.png?_='+Date.now();};})();
async function goGen(){
 const ideas=$('idea').value.trim();
 if(!ideas){alert('Tempel minimal satu ide dulu.');return;}
 const r=await fetch('/api/gen',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({ideas:ideas,domain:$('dom').value,openings:$('opens').value})});
 const j=await r.json();
 if(j.error){alert(j.error);return;}
 Q=j.episodes;QI=0;
 $('chips').innerHTML=Q.map((e,i)=>'<span class="chip'+(i==0?' on':'')+'" onclick="show('+i+')">Ep '+e.no+' · '+e.domain+' · HD-'+String(e.tn).padStart(4,'0')+'</span>').join('');
 $('box').style.display='block';
 $('q_info').innerHTML='&#10004; '+Q.length+' prompt siap.';
 show(0);
}
function show(i){
 if(!Q.length)return;QI=Math.max(0,Math.min(Q.length-1,i));
 document.querySelectorAll('.chip').forEach((c,k)=>c.classList.toggle('on',k==QI));
 const e=Q[QI];
 $('pr').value=e.prompt;
 $('prev').src='/prev/'+e.tn+'.png?_='+Date.now();
 $('vt').textContent='HD-'+String(e.tn).padStart(4,'0')+' · '+e.domain;
}
function copyP(){$('pr').select();document.execCommand('copy');$('q_info').innerHTML='&#10004; prompt tersalin.';}
let RT=null;
function upNsk(inp){
 const f=inp.files[0]; if(!f)return;
 const r=new FileReader();
 r.onload=e=>{$('nsk').value=e.target.result;
  $('up_info').innerHTML='&#10004; '+f.name+' ('+Math.round(f.size/1024)+' KB) dimuat — siap render.';};
 r.readAsText(f);
}
function fmtMB(b){return b>1048576?(b/1048576).toFixed(1)+' MB':Math.round(b/1024)+' KB';}
function loadDisk(){fetch('/api/disk').then(r=>r.json()).then(j=>{
 $('disk').innerHTML='Video tersimpan: <b>'+j.nvid+'</b> file ('+fmtMB(j.hasil)+') · berkas kerja: '+fmtMB(j.work);});}
function clean(w){
 const msg={hasil:'hapus semua video di hasil/?',work:'hapus berkas kerja (cache TTS)?',all:'hapus video + berkas kerja?'}[w];
 if(!confirm(msg))return;
 fetch('/api/clean',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({what:w})})
  .then(()=>{loadDisk();});
}
loadDisk();
fetch('/api/sounds').then(r=>r.json()).then(j=>{
 $('snd').innerHTML='<option value="">(tanpa backsound)</option>'+j.files.map(f=>'<option>'+f+'</option>').join('');
});
async function goRender(){
 const text=$('nsk').value.trim();
 if(!text){alert('Tempel naskah dulu.');return;}
 const r=await fetch('/api/render',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({text:text,tn:$('tno').value,dunia:$('dunia').value,
   sound:$('snd').value,vol:(+$('vol').value)/100})});
 const j=await r.json();
 if(j.error){alert(j.error);return;}
 $('r_info').innerHTML='&#9203; '+(resume?'melanjutkan checkpoint · ':'')+'rendering HD-'+String(j.tn).padStart(4,'0')+' · '+j.domain+'...';
 $('r_box').style.display='none';
 $('r_panel').style.display='flex';$('r_log').textContent='';$('r_bar').style.width='0%';
 RT=setInterval(async()=>{
  const s=await (await fetch('/api/render/status')).json();
  $('r_stage').innerHTML='<span class="spin"></span> '+(s.prog||s.msg)+' &nbsp;·&nbsp; berjalan '+fmtT(s.el)+(s.segs?' &nbsp;·&nbsp; &#10004; '+s.segs+' seg checkpoint tersimpan':'');
  $('r_bar').style.width=(s.pct||0)+'%';
  $('r_log').textContent=(s.log||[]).join('\n');
  $('r_log').scrollTop=$('r_log').scrollHeight;
  if(!s.busy){clearInterval(RT);loadDisk();
   $('r_bar').style.width='100%';
   if(s.out){$('r_info').innerHTML='&#10004; selesai';$('tno').value='auto';
    $('r_stage').innerHTML='&#10004; selesai dalam '+fmtT(s.el);
    $('r_box').style.display='flex';
    $('r_link').href='/hasil/'+s.out;$('r_link').textContent='&#9654; buka '+s.out;}
   else $('r_info').innerHTML=s.msg;}
 },1000);
}
function fmtT(s){s=s||0;return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function copyC(){const e=Q[QI];fetch('/api/template/'+e.tn).then(r=>r.json()).then(t=>{
 const ta=document.createElement('textarea');ta.value=t.concept_block+'\n\n'+t.visual_block;
 document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();
 $('q_info').innerHTML='&#10004; setting+visual tersalin.';});}
</script></body></html>"""

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8809)
    a = ap.parse_args()
    print('DEEP WATCH engine -> http://localhost:%d' % a.port)
    app.run(host='0.0.0.0', port=a.port, debug=False)
