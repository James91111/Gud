#!/bin/bash
# DEEP WATCH story engine — launcher (auto-pasang komponen, sekali saja)
# http://localhost:8809
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONUNBUFFERED=1
python3 -c "import flask, edge_tts, imageio_ffmpeg, PIL" 2>/dev/null || {
  echo "  Komponen belum lengkap — dipasang OTOMATIS (sekali saja, butuh internet):"
  python3 -m pip install -q flask edge-tts imageio-ffmpeg pillow
}
exec python3 "$DIR/horrorstudio.py"
