# -*- coding: utf-8 -*-
"""audit_dw.py — cross-check anti-repetitif 1000 setting Deep Watch.
Jalankan: python3 audit_dw.py  (exit 0 = LULUS)"""
import hashlib, os, sys
BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE); sys.path.insert(0, BASE)
import hdeck as hd
from PIL import Image

H = []
def catat(n, ok, d):
    H.append(ok)
    print(('  [LULUS] ' if ok else '  [GAGAL] ') + n + ' — ' + d)

print('=== 1000 SETTING ===')
sig, vb, cb, dup = set(), set(), set(), 0
for n in range(1, hd.N_TEMPLATES + 1):
    t = hd.get_template(n)
    k = (t['domain'], t['worksite'], t['role'])
    if k in sig: dup += 1
    sig.add(k)
    vb.add(hashlib.md5(hd.visual_block(n).encode()).hexdigest())
    cb.add(hashlib.md5(hd.concept_block(n).encode()).hexdigest())
catat('1000 (domain, dunia, profesi) unik', len(sig) == 1000 and dup == 0, '%d unik' % len(sig))
catat('1000 blok VISUAL unik', len(vb) == 1000, '%d unik' % len(vb))
catat('1000 blok SETTING (makhluk/stakes/twist/rules) unik', len(cb) == 1000, '%d unik' % len(cb))

space = [n for n in range(1, 1001) if hd.get_template(n)['domain'] == 'SPACE']
sea = [n for n in range(1, 1001) if hd.get_template(n)['domain'] == 'SEA']
catat('pembagian 500 space + 500 sea', len(space) == 500 and len(sea) == 500,
      '%d + %d' % (len(space), len(sea)))

# tetangga berurutan beda dimensi
bad = 0
seq = [hd.order(k, 'AUTO') for k in range(1, 1001)]
for i in range(999):
    a, b = hd.get_template(seq[i]), hd.get_template(seq[i + 1])
    if a['domain'] == b['domain']:
        for d in ('worksite', 'role', 'creature', 'stake', 'twist', 'hardware'):
            if a[d] == b[d]: bad += 1
catat('episode berurutan beda dimensi (kolom sama sesedikit mungkin)', bad < 400,
      '%d kecocokan satuan dari 5.994 pasangan' % bad)

print('=== BUKTI PIKSEL (digambar script, tanpa file PNG) ===')
sampel = [1, 2, 250, 500, 501, 502, 750, 1000]
imgs = {n: hd.render_bg(n).convert('L').resize((8, 8)) for n in sampel}
def ph(im):
    px = list(im.getdata()); r = sum(px) / 64.0
    return ''.join('1' if v > r else '0' for v in px)
hs = {ph(imgs[n]) for n in sampel}
catat('perceptual hash latar semua berbeda', len(hs) == len(sampel), '%d/%d unik' % (len(hs), len(sampel)))

print('=== PROMPT ASLI UTUH ===')
import horrorstudio as hs2
base = hs2.load_base('SPACE')
out = hs2.build_prompt('SPACE', 'test welder', 7, [])
baris = [l.strip() for l in base.splitlines() if l.strip()]
hilang = [l for l in baris if l not in out]
catat('prompt DEEP SPACE asli utuh di hasil', len(hilang) == 0,
      '%d/%d baris' % (len(baris) - len(hilang), len(baris)))
base2 = hs2.load_base('SEA')
out2 = hs2.build_prompt('SEA', 'test diver', 507, [])
baris2 = [l.strip() for l in base2.splitlines() if l.strip()]
hilang2 = [l for l in baris2 if l not in out2]
catat('prompt DEEP SEA asli utuh di hasil', len(hilang2) == 0,
      '%d/%d baris' % (len(baris2) - len(hilang2), len(baris2)))

print('=' * 50)
if all(H):
    print('PUTUSAN: LULUS %d/%d ✔' % (len(H), len(H)))
    sys.exit(0)
print('PUTUSAN: GAGAL %d pemeriksaan' % H.count(False))
sys.exit(1)
